#ifndef RUNANYWHERE_LLAMACPP_BACKEND_H
#define RUNANYWHERE_LLAMACPP_BACKEND_H

/**
 * LlamaCPP Backend - Text Generation via llama.cpp
 *
 * This backend uses llama.cpp for on-device LLM inference with GGUF/GGML models.
 *
 * Supported Capabilities:
 * - TEXT_GENERATION: Via llama.cpp with streaming support
 */

#include <llama.h>

#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

#include "capabilities/backend.h"
#include "capabilities/types.h"

namespace runanywhere {

// =============================================================================
// FORWARD DECLARATIONS
// =============================================================================

class LlamaCppTextGeneration;

// =============================================================================
// LLAMACPP BACKEND
// =============================================================================

class LlamaCppBackend : public Backend {
   public:
    LlamaCppBackend();
    ~LlamaCppBackend() override;

    // Backend interface
    BackendInfo get_info() const override;
    bool initialize(const nlohmann::json& config = {}) override;
    bool is_initialized() const override;
    void cleanup() override;

    ra_device_type get_device_type() const override;
    size_t get_memory_usage() const override;

    // Get number of threads to use
    int get_num_threads() const { return num_threads_; }

   private:
    void create_capabilities();

    bool initialized_ = false;
    nlohmann::json config_;
    int num_threads_ = 0;
    mutable std::mutex mutex_;
};

// =============================================================================
// TEXT GENERATION CAPABILITY
// =============================================================================

class LlamaCppTextGeneration : public ITextGeneration {
   public:
    explicit LlamaCppTextGeneration(LlamaCppBackend* backend);
    ~LlamaCppTextGeneration() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;

    TextGenerationResult generate(const TextGenerationRequest& request) override;
    bool generate_stream(const TextGenerationRequest& request,
                         TextStreamCallback callback) override {
        // Default implementation without prompt token output
        return generate_stream(request, callback, nullptr);
    }
    bool generate_stream(const TextGenerationRequest& request, TextStreamCallback callback,
                         int* out_prompt_tokens);
    void cancel() override;
    nlohmann::json get_model_info() const override;

   private:
    // Internal unload without locking (caller must hold mutex_)
    bool unload_model_internal();

    // Internal helper to build prompt from messages
    std::string build_prompt(const TextGenerationRequest& request);

    // Apply chat template if available
    std::string
    apply_chat_template(const std::vector<std::pair<std::string, std::string>>& messages,
                        const std::string& system_prompt, bool add_assistant_token);

    LlamaCppBackend* backend_;
    llama_model* model_ = nullptr;
    llama_context* context_ = nullptr;
    llama_sampler* sampler_ = nullptr;

    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};

    std::string model_path_;
    nlohmann::json model_config_;

    // Model parameters
    // Note: context_size_ is dynamically determined after model load:
    // 1. If user provides "context_size" in config, use min(user_provided, model_training_ctx)
    // 2. Otherwise, use model's training context (capped at max_default_context_)
    int context_size_ = 0;            // 0 = auto-detect from model
    int max_default_context_ = 8192;  // Cap for auto-detected context to avoid OOM

    // Sampling parameters (matched to LLM.swift defaults for quality)
    float temperature_ = 0.8f;  // LLM.swift default (was 0.7)
    float top_p_ = 0.95f;       // Nucleus sampling (LLM.swift default)
    float min_p_ = 0.05f;       // Minimum probability threshold
    int top_k_ = 40;            // Top-K sampling

    mutable std::mutex mutex_;
};

// =============================================================================
// BACKEND FACTORY & REGISTRATION
// =============================================================================

// Export macro for shared library builds (needed for Android)
#if defined(_WIN32)
#define RA_LLAMACPP_EXPORT __declspec(dllexport)
#elif defined(__GNUC__) || defined(__clang__)
#define RA_LLAMACPP_EXPORT __attribute__((visibility("default")))
#else
#define RA_LLAMACPP_EXPORT
#endif

/**
 * Creates a new LlamaCPP backend instance.
 *
 * This factory function is called by the bridge to create backend instances.
 * The registration is done by the bridge itself to avoid singleton issues
 * across shared libraries.
 */
RA_LLAMACPP_EXPORT std::unique_ptr<Backend> create_llamacpp_backend();

/**
 * Explicitly registers the LlamaCPP backend with the BackendRegistry.
 *
 * NOTE: For shared library builds (Android), prefer calling create_llamacpp_backend()
 * from the bridge and letting the bridge register it. This function calls
 * BackendRegistry::instance() which may create a separate singleton in each .so.
 *
 * For static library builds (iOS), this function works correctly.
 */
RA_LLAMACPP_EXPORT void register_llamacpp_backend();

}  // namespace runanywhere

// =============================================================================
// C-LINKAGE API (for runanywhere-commons)
// =============================================================================

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Opaque handle types for C API
 */
typedef struct ra_llamacpp_handle_t* ra_llamacpp_handle;

/**
 * LlamaCpp configuration for model loading
 */
typedef struct ra_llamacpp_config {
    int context_size;   // 0 = auto-detect from model
    int num_threads;    // 0 = auto-detect
    int gpu_layers;     // Number of layers to offload to GPU (Metal on iOS/macOS)
    int batch_size;     // Batch size for prompt processing
    float temperature;  // Sampling temperature (default: 0.8)
    float top_p;        // Nucleus sampling threshold (default: 0.95)
    float min_p;        // Minimum probability threshold (default: 0.05)
    int top_k;          // Top-K sampling (default: 40)
} ra_llamacpp_config_t;

/**
 * Generation options for a single request
 */
typedef struct ra_llamacpp_generate_options {
    int max_tokens;             // Maximum tokens to generate
    float temperature;          // Override model default (0 = use model default)
    float top_p;                // Override model default (0 = use model default)
    int top_k;                  // Override model default (0 = use model default)
    const char* stop_sequence;  // Optional stop sequence
} ra_llamacpp_generate_options_t;

/**
 * Streaming callback for token generation
 */
typedef void (*ra_llamacpp_stream_callback)(const char* token, int is_final, void* user_data);

/**
 * Creates a new LlamaCpp service instance.
 * @param model_path Path to the GGUF model file
 * @param config Configuration options (can be NULL for defaults)
 * @param out_handle Output handle on success
 * @return 0 on success, negative error code on failure
 */
RA_LLAMACPP_EXPORT int ra_llamacpp_create(const char* model_path,
                                          const ra_llamacpp_config_t* config,
                                          ra_llamacpp_handle* out_handle);

/**
 * Destroys a LlamaCpp service instance and frees all resources.
 * @param handle Handle to destroy
 */
RA_LLAMACPP_EXPORT void ra_llamacpp_destroy(ra_llamacpp_handle handle);

/**
 * Generates text completion (blocking, non-streaming).
 * @param handle Service handle
 * @param prompt Input prompt text
 * @param options Generation options
 * @param out_text Output buffer for generated text (caller must free with ra_llamacpp_free_string)
 * @param out_tokens_generated Number of tokens generated (completion tokens)
 * @param out_prompt_tokens Number of prompt tokens (can be NULL)
 * @return 0 on success, negative error code on failure
 */
RA_LLAMACPP_EXPORT int ra_llamacpp_generate(ra_llamacpp_handle handle, const char* prompt,
                                            const ra_llamacpp_generate_options_t* options,
                                            char** out_text, int* out_tokens_generated,
                                            int* out_prompt_tokens);

/**
 * Generates text completion with streaming callback.
 * @param handle Service handle
 * @param prompt Input prompt text
 * @param options Generation options
 * @param callback Function called for each generated token
 * @param user_data User data passed to callback
 * @return 0 on success, negative error code on failure
 */
RA_LLAMACPP_EXPORT int ra_llamacpp_generate_stream(ra_llamacpp_handle handle, const char* prompt,
                                                   const ra_llamacpp_generate_options_t* options,
                                                   ra_llamacpp_stream_callback callback,
                                                   void* user_data);

/**
 * Cancels an ongoing generation.
 * @param handle Service handle
 */
RA_LLAMACPP_EXPORT void ra_llamacpp_cancel(ra_llamacpp_handle handle);

/**
 * Checks if the model is loaded and ready.
 * @param handle Service handle
 * @return 1 if ready, 0 otherwise
 */
RA_LLAMACPP_EXPORT int ra_llamacpp_is_ready(ra_llamacpp_handle handle);

/**
 * Gets model information as JSON string.
 * @param handle Service handle
 * @return JSON string (caller must free with ra_llamacpp_free_string) or NULL on error
 */
RA_LLAMACPP_EXPORT char* ra_llamacpp_get_model_info(ra_llamacpp_handle handle);

/**
 * Frees a string allocated by LlamaCpp functions.
 * @param str String to free
 */
RA_LLAMACPP_EXPORT void ra_llamacpp_free_string(char* str);

/**
 * Returns the default configuration values.
 * @param out_config Output configuration structure
 */
RA_LLAMACPP_EXPORT void ra_llamacpp_get_default_config(ra_llamacpp_config_t* out_config);

/**
 * Returns the default generation options.
 * @param out_options Output options structure
 */
RA_LLAMACPP_EXPORT void
ra_llamacpp_get_default_options(ra_llamacpp_generate_options_t* out_options);

#ifdef __cplusplus
}
#endif

#endif  // RUNANYWHERE_LLAMACPP_BACKEND_H
