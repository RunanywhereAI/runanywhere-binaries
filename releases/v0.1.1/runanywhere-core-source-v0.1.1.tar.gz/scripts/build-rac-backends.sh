#!/bin/bash
# =============================================================================
# RunAnywhere Core - Build RAC Backend Release Artifacts
# =============================================================================
#
# Builds RAC backend release artifacts for iOS and Android:
#
# iOS (XCFrameworks):
#   - RABackendLlamaCPP.xcframework
#   - RABackendONNX.xcframework
#   - RABackendWhisperCPP.xcframework
#
# Android (JNI Libraries per ABI):
#   - librac_backend_llamacpp.so + librac_backend_llamacpp_jni.so
#   - librac_backend_onnx.so + librac_backend_onnx_jni.so
#   - librac_backend_whispercpp.so + librac_backend_whispercpp_jni.so
#
# Usage:
#   ./scripts/build-rac-backends.sh [options]
#
# Options:
#   --ios              Build iOS xcframeworks only
#   --android          Build Android libraries only
#   --all              Build for all platforms (default)
#   --llamacpp         Build LlamaCPP backend only
#   --onnx             Build ONNX backend only  
#   --whispercpp       Build WhisperCPP backend only
#   --backends-all     Build all backends (default)
#   --clean            Clean build directories first
#   --release          Release build (default)
#   --debug            Debug build
#   --abi ABI          Android: specific ABI (arm64-v8a, armeabi-v7a, x86_64)
#   --help             Show this help
#
# Prerequisites:
#   iOS:
#     - Xcode with iOS SDK
#     - ONNX Runtime: third_party/onnxruntime-ios/
#     - Sherpa-ONNX (optional): third_party/sherpa-onnx-ios/
#
#   Android:
#     - ANDROID_NDK_HOME or ANDROID_NDK set
#     - ONNX Runtime: third_party/onnxruntime-android/
#     - Sherpa-ONNX (optional): third_party/sherpa-onnx-android/
#
# Examples:
#   ./scripts/build-rac-backends.sh --ios --llamacpp
#   ./scripts/build-rac-backends.sh --android --onnx --abi arm64-v8a
#   ./scripts/build-rac-backends.sh --all --backends-all --clean
#
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"
DIST_DIR="${ROOT_DIR}/dist"

# Load versions
source "${SCRIPT_DIR}/load-versions.sh"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_header() { echo -e "\n${BLUE}═══════════════════════════════════════════${NC}"; echo -e "${BLUE} $1${NC}"; echo -e "${BLUE}═══════════════════════════════════════════${NC}"; }
log_step()   { echo -e "${YELLOW}-> $1${NC}"; }
log_info()   { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
log_error()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# =============================================================================
# Parse Arguments
# =============================================================================

BUILD_IOS=false
BUILD_ANDROID=false
BUILD_PLATFORMS_ALL=true
BUILD_LLAMACPP=false
BUILD_ONNX=false
BUILD_WHISPERCPP=false
BUILD_BACKENDS_ALL=true
CLEAN_BUILD=false
BUILD_TYPE="Release"
ANDROID_ABIS=("arm64-v8a" "armeabi-v7a" "x86_64")

show_help() {
    head -45 "$0" | tail -40
    exit 0
}

while [[ $# -gt 0 ]]; do
    case $1 in
        --ios)
            BUILD_IOS=true
            BUILD_PLATFORMS_ALL=false
            shift
            ;;
        --android)
            BUILD_ANDROID=true
            BUILD_PLATFORMS_ALL=false
            shift
            ;;
        --all)
            BUILD_PLATFORMS_ALL=true
            shift
            ;;
        --llamacpp)
            BUILD_LLAMACPP=true
            BUILD_BACKENDS_ALL=false
            shift
            ;;
        --onnx)
            BUILD_ONNX=true
            BUILD_BACKENDS_ALL=false
            shift
            ;;
        --whispercpp)
            BUILD_WHISPERCPP=true
            BUILD_BACKENDS_ALL=false
            shift
            ;;
        --backends-all)
            BUILD_BACKENDS_ALL=true
            shift
            ;;
        --clean)
            CLEAN_BUILD=true
            shift
            ;;
        --release)
            BUILD_TYPE="Release"
            shift
            ;;
        --debug)
            BUILD_TYPE="Debug"
            shift
            ;;
        --abi)
            ANDROID_ABIS=("$2")
            shift 2
            ;;
        --help|-h)
            show_help
            ;;
        *)
            log_error "Unknown option: $1"
            ;;
    esac
done

# Apply defaults
if [ "$BUILD_PLATFORMS_ALL" = true ]; then
    BUILD_IOS=true
    BUILD_ANDROID=true
fi

if [ "$BUILD_BACKENDS_ALL" = true ]; then
    BUILD_LLAMACPP=true
    BUILD_ONNX=true
    BUILD_WHISPERCPP=true
fi

# =============================================================================
# Configuration
# =============================================================================

IOS_DEPLOYMENT_TARGET="${IOS_DEPLOYMENT_TARGET:-13.0}"
ANDROID_MIN_SDK="${ANDROID_MIN_SDK:-24}"
ANDROID_NDK="${ANDROID_NDK_HOME:-$ANDROID_NDK}"

# RAC headers from runanywhere-commons
RAC_COMMONS_DIR="${ROOT_DIR}/../sdks/sdk/runanywhere-commons"
if [ ! -d "${RAC_COMMONS_DIR}/include" ]; then
    # Try alternative paths
    if [ -d "${ROOT_DIR}/third_party/runanywhere-commons/include" ]; then
        RAC_COMMONS_DIR="${ROOT_DIR}/third_party/runanywhere-commons"
    else
        log_warn "runanywhere-commons not found, RAC headers may be missing"
    fi
fi

log_header "RAC Backends Build Configuration"
echo "Build type:     ${BUILD_TYPE}"
echo "Build iOS:      ${BUILD_IOS}"
echo "Build Android:  ${BUILD_ANDROID}"
echo ""
echo "Backends:"
echo "  LlamaCPP:     ${BUILD_LLAMACPP}"
echo "  ONNX:         ${BUILD_ONNX}"
echo "  WhisperCPP:   ${BUILD_WHISPERCPP}"
echo ""
if [ "$BUILD_IOS" = true ]; then
    echo "iOS target:     ${IOS_DEPLOYMENT_TARGET}"
fi
if [ "$BUILD_ANDROID" = true ]; then
    echo "Android SDK:    ${ANDROID_MIN_SDK}"
    echo "Android ABIs:   ${ANDROID_ABIS[*]}"
    echo "NDK path:       ${ANDROID_NDK:-NOT SET}"
fi
echo "RAC headers:    ${RAC_COMMONS_DIR}/include"
echo ""

# =============================================================================
# Clean
# =============================================================================

if [ "$CLEAN_BUILD" = true ]; then
    log_step "Cleaning previous build..."
    [ "$BUILD_IOS" = true ] && rm -rf "${BUILD_DIR}/ios-rac-backends"
    [ "$BUILD_ANDROID" = true ] && rm -rf "${BUILD_DIR}/android-rac-backends"
fi

mkdir -p "${DIST_DIR}"

# =============================================================================
# iOS Build Functions
# =============================================================================

build_ios_backend() {
    local BACKEND=$1
    local FRAMEWORK_NAME=$2
    local BUILD_FLAG=$3
    
    log_header "Building ${FRAMEWORK_NAME} for iOS"
    
    local IOS_BUILD="${BUILD_DIR}/ios-rac-backends/${BACKEND}"
    mkdir -p "${IOS_BUILD}"
    
    # CMake flags
    local CMAKE_BACKEND_FLAGS="-DRA_BUILD_LLAMACPP=OFF -DRA_BUILD_ONNX=OFF -DRA_BUILD_WHISPERCPP=OFF"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -D${BUILD_FLAG}=ON"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_MODULAR=ON"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRUNANYWHERE_COMMONS_DIR=${RAC_COMMONS_DIR}"
    
    # Build for each platform
    for PLATFORM in "OS" "SIMULATORARM64" "SIMULATOR"; do
        log_step "Building ${BACKEND} for ${PLATFORM}..."
        
        local PLATFORM_DIR="${IOS_BUILD}/${PLATFORM}"
        mkdir -p "${PLATFORM_DIR}"
        cd "${PLATFORM_DIR}"
        
        cmake "${ROOT_DIR}" \
            -G Xcode \
            -DCMAKE_SYSTEM_NAME=iOS \
            -DCMAKE_OSX_ARCHITECTURES=$([ "$PLATFORM" = "OS" ] && echo "arm64" || ([ "$PLATFORM" = "SIMULATOR" ] && echo "x86_64" || echo "arm64")) \
            -DCMAKE_OSX_SYSROOT=$([ "$PLATFORM" = "OS" ] && echo "iphoneos" || echo "iphonesimulator") \
            -DCMAKE_OSX_DEPLOYMENT_TARGET="${IOS_DEPLOYMENT_TARGET}" \
            -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" \
            ${CMAKE_BACKEND_FLAGS} \
            -DRA_BUILD_TESTS=OFF \
            -DRA_BUILD_SHARED=OFF
        
        cmake --build . --config "${BUILD_TYPE}" -- -quiet CODE_SIGNING_ALLOWED=NO
        
        cd "${ROOT_DIR}"
    done
    
    # Combine libraries and create framework
    create_ios_rac_framework "${BACKEND}" "${FRAMEWORK_NAME}" "${IOS_BUILD}"
}

create_ios_rac_framework() {
    local BACKEND=$1
    local FRAMEWORK_NAME=$2
    local BUILD_BASE=$3
    
    log_step "Creating ${FRAMEWORK_NAME}.xcframework..."
    
    for PLATFORM in "OS" "SIMULATORARM64" "SIMULATOR"; do
        local PLATFORM_DIR="${BUILD_BASE}/${PLATFORM}"
        local FRAMEWORK_DIR="${PLATFORM_DIR}/${FRAMEWORK_NAME}.framework"
        local PLATFORM_SUFFIX=$([ "$PLATFORM" = "OS" ] && echo "iphoneos" || echo "iphonesimulator")
        
        mkdir -p "${FRAMEWORK_DIR}/Headers"
        mkdir -p "${FRAMEWORK_DIR}/Modules"
        
        # Collect all libraries to combine
        local LIBS=()
        
        # Main RAC backend library
        local RAC_LIB="${PLATFORM_DIR}/src/backends/${BACKEND}/${BUILD_TYPE}-${PLATFORM_SUFFIX}/librac_backend_${BACKEND}.a"
        [ -f "${RAC_LIB}" ] && LIBS+=("${RAC_LIB}")
        
        # Core backend library
        local CORE_LIB="${PLATFORM_DIR}/src/backends/${BACKEND}/${BUILD_TYPE}-${PLATFORM_SUFFIX}/librunanywhere_${BACKEND}.a"
        [ -f "${CORE_LIB}" ] && LIBS+=("${CORE_LIB}")
        
        # Bridge library
        local BRIDGE_LIB="${PLATFORM_DIR}/${BUILD_TYPE}-${PLATFORM_SUFFIX}/librunanywhere_bridge.a"
        [ -f "${BRIDGE_LIB}" ] && LIBS+=("${BRIDGE_LIB}")
        
        # Backend-specific dependencies
        if [ "$BACKEND" = "llamacpp" ]; then
            # llama.cpp libraries
            local LLAMA_BASE="${PLATFORM_DIR}/_deps/llamacpp-build"
            [ -f "${LLAMA_BASE}/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libllama.a" ] && \
                LIBS+=("${LLAMA_BASE}/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libllama.a")
            [ -f "${LLAMA_BASE}/common/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libcommon.a" ] && \
                LIBS+=("${LLAMA_BASE}/common/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libcommon.a")
            
            # GGML libraries
            for lib in ggml ggml-base ggml-cpu; do
                [ -f "${LLAMA_BASE}/ggml/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/lib${lib}.a" ] && \
                    LIBS+=("${LLAMA_BASE}/ggml/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/lib${lib}.a")
            done
            [ -f "${LLAMA_BASE}/ggml/src/ggml-metal/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-metal.a" ] && \
                LIBS+=("${LLAMA_BASE}/ggml/src/ggml-metal/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-metal.a")
            [ -f "${LLAMA_BASE}/ggml/src/ggml-blas/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-blas.a" ] && \
                LIBS+=("${LLAMA_BASE}/ggml/src/ggml-blas/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-blas.a")
        fi
        
        if [ "$BACKEND" = "onnx" ]; then
            # ONNX Runtime
            local ONNX_XCFW="${ROOT_DIR}/third_party/onnxruntime-ios/onnxruntime.xcframework"
            local ONNX_LIB=""
            if [ "$PLATFORM" = "OS" ]; then
                ONNX_LIB="${ONNX_XCFW}/ios-arm64/onnxruntime.framework/onnxruntime"
            else
                ONNX_LIB="${ONNX_XCFW}/ios-arm64_x86_64-simulator/onnxruntime.framework/onnxruntime"
            fi
            [ -f "${ONNX_LIB}" ] && LIBS+=("${ONNX_LIB}")
            
            # Sherpa-ONNX
            local SHERPA_XCFW="${ROOT_DIR}/third_party/sherpa-onnx-ios/sherpa-onnx.xcframework"
            local SHERPA_LIB=""
            if [ "$PLATFORM" = "OS" ]; then
                SHERPA_LIB="${SHERPA_XCFW}/ios-arm64/libsherpa-onnx.a"
            else
                SHERPA_LIB="${SHERPA_XCFW}/ios-arm64_x86_64-simulator/libsherpa-onnx.a"
            fi
            [ -f "${SHERPA_LIB}" ] && LIBS+=("${SHERPA_LIB}")
        fi
        
        if [ "$BACKEND" = "whispercpp" ]; then
            # whisper.cpp libraries
            local WHISPER_BASE="${PLATFORM_DIR}/_deps/whispercpp-build"
            [ -f "${WHISPER_BASE}/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libwhisper.a" ] && \
                LIBS+=("${WHISPER_BASE}/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libwhisper.a")
            
            # GGML (if not from llamacpp)
            for lib in ggml ggml-base ggml-cpu; do
                [ -f "${WHISPER_BASE}/ggml/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/lib${lib}.a" ] && \
                    LIBS+=("${WHISPER_BASE}/ggml/src/${BUILD_TYPE}-${PLATFORM_SUFFIX}/lib${lib}.a")
            done
            [ -f "${WHISPER_BASE}/ggml/src/ggml-metal/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-metal.a" ] && \
                LIBS+=("${WHISPER_BASE}/ggml/src/ggml-metal/${BUILD_TYPE}-${PLATFORM_SUFFIX}/libggml-metal.a")
        fi
        
        # Combine libraries
        if [ ${#LIBS[@]} -gt 0 ]; then
            libtool -static -o "${FRAMEWORK_DIR}/${FRAMEWORK_NAME}" "${LIBS[@]}"
            log_info "${PLATFORM}: Combined ${#LIBS[@]} libraries"
        else
            log_warn "${PLATFORM}: No libraries found to combine"
            continue
        fi
        
        # Copy RAC headers
        for header in "${ROOT_DIR}/include/rac_"*"_${BACKEND}"*.h "${ROOT_DIR}/include/rac_${BACKEND}"*.h; do
            [ -f "$header" ] && cp "$header" "${FRAMEWORK_DIR}/Headers/"
        done
        
        # Create module map
        cat > "${FRAMEWORK_DIR}/Modules/module.modulemap" << EOF
framework module ${FRAMEWORK_NAME} {
    umbrella header "${FRAMEWORK_NAME}.h"
    export *
    module * { export * }
}
EOF
        
        # Umbrella header
        cat > "${FRAMEWORK_DIR}/Headers/${FRAMEWORK_NAME}.h" << EOF
#ifndef ${FRAMEWORK_NAME}_h
#define ${FRAMEWORK_NAME}_h
EOF
        for h in "${FRAMEWORK_DIR}/Headers/"*.h; do
            [ "$(basename "$h")" != "${FRAMEWORK_NAME}.h" ] && \
                echo "#include \"$(basename "$h")\"" >> "${FRAMEWORK_DIR}/Headers/${FRAMEWORK_NAME}.h"
        done
        echo -e "\n#endif" >> "${FRAMEWORK_DIR}/Headers/${FRAMEWORK_NAME}.h"
        
        # Info.plist
        cat > "${FRAMEWORK_DIR}/Info.plist" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key><string>${FRAMEWORK_NAME}</string>
    <key>CFBundleIdentifier</key><string>ai.runanywhere.${FRAMEWORK_NAME}</string>
    <key>CFBundlePackageType</key><string>FMWK</string>
    <key>MinimumOSVersion</key><string>${IOS_DEPLOYMENT_TARGET}</string>
</dict>
</plist>
EOF
    done
    
    # Create xcframework
    local XCFW_PATH="${DIST_DIR}/${FRAMEWORK_NAME}.xcframework"
    rm -rf "${XCFW_PATH}"
    
    # Fat simulator binary
    local SIM_FAT="${BUILD_BASE}/SIMULATOR_FAT"
    mkdir -p "${SIM_FAT}"
    cp -R "${BUILD_BASE}/SIMULATORARM64/${FRAMEWORK_NAME}.framework" "${SIM_FAT}/"
    
    if [ -f "${BUILD_BASE}/SIMULATOR/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}" ]; then
        lipo -create \
            "${BUILD_BASE}/SIMULATORARM64/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}" \
            "${BUILD_BASE}/SIMULATOR/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}" \
            -output "${SIM_FAT}/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}" 2>/dev/null || \
        cp "${BUILD_BASE}/SIMULATORARM64/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}" \
            "${SIM_FAT}/${FRAMEWORK_NAME}.framework/${FRAMEWORK_NAME}"
    fi
    
    xcodebuild -create-xcframework \
        -framework "${BUILD_BASE}/OS/${FRAMEWORK_NAME}.framework" \
        -framework "${SIM_FAT}/${FRAMEWORK_NAME}.framework" \
        -output "${XCFW_PATH}"
    
    log_info "Created: ${XCFW_PATH}"
    echo "  Size: $(du -sh "${XCFW_PATH}" | cut -f1)"
}

# =============================================================================
# Android Build Functions
# =============================================================================

build_android_backend() {
    local BACKEND=$1
    local LIB_NAME=$2
    local BUILD_FLAG=$3
    
    log_header "Building ${LIB_NAME} for Android"
    
    # Validate NDK
    if [ -z "${ANDROID_NDK}" ] || [ ! -d "${ANDROID_NDK}" ]; then
        log_error "ANDROID_NDK not set or not found"
    fi
    
    local ANDROID_BUILD="${BUILD_DIR}/android-rac-backends/${BACKEND}"
    local ANDROID_DIST="${DIST_DIR}/android/rac-backends-${BACKEND}"
    mkdir -p "${ANDROID_BUILD}"
    mkdir -p "${ANDROID_DIST}"
    
    # CMake flags
    local CMAKE_BACKEND_FLAGS="-DRA_BUILD_LLAMACPP=OFF -DRA_BUILD_ONNX=OFF -DRA_BUILD_WHISPERCPP=OFF"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -D${BUILD_FLAG}=ON"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_MODULAR=ON"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRAC_BUILD_JNI=ON"
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRUNANYWHERE_COMMONS_DIR=${RAC_COMMONS_DIR}"
    
    for ABI in "${ANDROID_ABIS[@]}"; do
        log_step "Building ${BACKEND} for ${ABI}..."
        
        local ABI_BUILD="${ANDROID_BUILD}/${ABI}"
        mkdir -p "${ABI_BUILD}"
        cd "${ABI_BUILD}"
        
        cmake "${ROOT_DIR}" \
            -DCMAKE_TOOLCHAIN_FILE="${ANDROID_NDK}/build/cmake/android.toolchain.cmake" \
            -DANDROID_ABI="${ABI}" \
            -DANDROID_PLATFORM="android-${ANDROID_MIN_SDK}" \
            -DANDROID_STL="c++_shared" \
            -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" \
            ${CMAKE_BACKEND_FLAGS} \
            -DRA_BUILD_TESTS=OFF \
            -DRA_BUILD_SHARED=ON
        
        cmake --build . --config "${BUILD_TYPE}" -j$(nproc 2>/dev/null || sysctl -n hw.ncpu)
        
        # Copy outputs
        local ABI_DIST="${ANDROID_DIST}/jniLibs/${ABI}"
        mkdir -p "${ABI_DIST}"
        
        # Copy shared libraries
        find "${ABI_BUILD}" -name "*.so" -type f | while read -r lib; do
            local libname=$(basename "$lib")
            if [[ "$libname" == *"${BACKEND}"* ]] || [[ "$libname" == *"runanywhere"* ]]; then
                cp "$lib" "${ABI_DIST}/"
                echo "    Copied: ${libname}"
            fi
        done
        
        # Copy STL
        local STL_LIB="${ANDROID_NDK}/toolchains/llvm/prebuilt/*/sysroot/usr/lib/${ABI}/libc++_shared.so"
        for stl in $STL_LIB; do
            [ -f "$stl" ] && cp "$stl" "${ABI_DIST}/"
            break
        done
        
        cd "${ROOT_DIR}"
        log_info "Built ${ABI}"
    done
    
    # Copy headers
    log_step "Copying headers..."
    local HEADERS_DIST="${ANDROID_DIST}/include"
    mkdir -p "${HEADERS_DIST}"
    cp "${ROOT_DIR}/include/rac_"*"${BACKEND}"*.h "${HEADERS_DIST}/" 2>/dev/null || true
    
    log_info "Android ${BACKEND} build complete: ${ANDROID_DIST}"
}

# =============================================================================
# Main Build
# =============================================================================

# iOS Builds
if [ "$BUILD_IOS" = true ]; then
    [ "$BUILD_LLAMACPP" = true ] && build_ios_backend "llamacpp" "RABackendLlamaCPP" "RA_BUILD_LLAMACPP"
    [ "$BUILD_ONNX" = true ] && build_ios_backend "onnx" "RABackendONNX" "RA_BUILD_ONNX"
    [ "$BUILD_WHISPERCPP" = true ] && build_ios_backend "whispercpp" "RABackendWhisperCPP" "RA_BUILD_WHISPERCPP"
fi

# Android Builds
if [ "$BUILD_ANDROID" = true ]; then
    [ "$BUILD_LLAMACPP" = true ] && build_android_backend "llamacpp" "rac_backend_llamacpp" "RA_BUILD_LLAMACPP"
    [ "$BUILD_ONNX" = true ] && build_android_backend "onnx" "rac_backend_onnx" "RA_BUILD_ONNX"
    [ "$BUILD_WHISPERCPP" = true ] && build_android_backend "whispercpp" "rac_backend_whispercpp" "RA_BUILD_WHISPERCPP"
fi

# =============================================================================
# Summary
# =============================================================================

log_header "Build Complete!"

echo "Output directory: ${DIST_DIR}"
echo ""

if [ "$BUILD_IOS" = true ]; then
    echo "iOS XCFrameworks:"
    for xcfw in "${DIST_DIR}"/*.xcframework; do
        [ -d "$xcfw" ] && echo "  $(du -sh "$xcfw" | cut -f1)  $(basename "$xcfw")"
    done
    echo ""
fi

if [ "$BUILD_ANDROID" = true ]; then
    echo "Android Libraries:"
    for backend_dir in "${DIST_DIR}/android/rac-backends-"*/; do
        [ -d "$backend_dir" ] && {
            echo "  $(basename "$backend_dir"):"
            for abi_dir in "${backend_dir}jniLibs/"*/; do
                [ -d "$abi_dir" ] && echo "    $(basename "$abi_dir"): $(ls "$abi_dir"/*.so 2>/dev/null | wc -l | tr -d ' ') libraries"
            done
        }
    done
    echo ""
fi

echo "Usage in Swift:"
echo '  import RABackendLlamaCPP  // or RABackendONNX, RABackendWhisperCPP'
echo ""
echo "Usage in Kotlin:"
echo '  System.loadLibrary("rac_backend_llamacpp_jni")  // etc.'

