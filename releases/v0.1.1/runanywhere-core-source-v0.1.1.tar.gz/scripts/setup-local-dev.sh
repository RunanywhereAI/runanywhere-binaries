#!/bin/bash
# =============================================================================
# RunAnywhere - Local Development Setup
# =============================================================================
#
# Sets up local development environment for the full stack:
#   - runanywhere-core (C++ backends with RAC APIs)
#   - runanywhere-commons (RAC types and services)
#   - runanywhere-swift (Swift SDK)
#
# Usage:
#   ./scripts/setup-local-dev.sh [options]
#
# Options:
#   --download-deps    Download all dependencies (ONNX Runtime, Sherpa-ONNX)
#   --build-commons    Build RACommons artifacts
#   --build-backends   Build RAC backend artifacts
#   --build-all        Build everything
#   --ios              Target iOS only
#   --android          Target Android only
#   --install-swift    Install artifacts to Swift SDK Binaries/
#   --clean            Clean all build directories first
#   --help             Show this help
#
# Examples:
#   # First time setup - download deps and build for iOS
#   ./scripts/setup-local-dev.sh --download-deps --build-all --ios --install-swift
#
#   # Quick rebuild after code changes
#   ./scripts/setup-local-dev.sh --build-backends --ios --install-swift
#
#   # Full Android setup
#   ./scripts/setup-local-dev.sh --download-deps --build-all --android
#
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
WORKSPACE_ROOT="$(cd "${CORE_DIR}/.." && pwd)"

# Paths
COMMONS_DIR="${WORKSPACE_ROOT}/sdks/sdk/runanywhere-commons"
SWIFT_DIR="${WORKSPACE_ROOT}/sdks/sdk/runanywhere-swift"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_header() { echo -e "\n${BLUE}═══════════════════════════════════════════${NC}"; echo -e "${BLUE} $1${NC}"; echo -e "${BLUE}═══════════════════════════════════════════${NC}\n"; }
log_step()   { echo -e "${YELLOW}-> $1${NC}"; }
log_info()   { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
log_error()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# =============================================================================
# Parse Arguments
# =============================================================================

DOWNLOAD_DEPS=false
BUILD_COMMONS=false
BUILD_BACKENDS=false
BUILD_ALL=false
TARGET_IOS=false
TARGET_ANDROID=false
TARGET_ALL=true
INSTALL_SWIFT=false
CLEAN_BUILD=false

show_help() {
    head -35 "$0" | tail -30
    exit 0
}

while [[ $# -gt 0 ]]; do
    case $1 in
        --download-deps) DOWNLOAD_DEPS=true; shift ;;
        --build-commons) BUILD_COMMONS=true; shift ;;
        --build-backends) BUILD_BACKENDS=true; shift ;;
        --build-all) BUILD_ALL=true; shift ;;
        --ios) TARGET_IOS=true; TARGET_ALL=false; shift ;;
        --android) TARGET_ANDROID=true; TARGET_ALL=false; shift ;;
        --install-swift) INSTALL_SWIFT=true; shift ;;
        --clean) CLEAN_BUILD=true; shift ;;
        --help|-h) show_help ;;
        *) log_error "Unknown option: $1" ;;
    esac
done

# Apply defaults
[ "$TARGET_ALL" = true ] && { TARGET_IOS=true; TARGET_ANDROID=true; }
[ "$BUILD_ALL" = true ] && { BUILD_COMMONS=true; BUILD_BACKENDS=true; }

# =============================================================================
# Validation
# =============================================================================

log_header "RunAnywhere Local Development Setup"

echo "Configuration:"
echo "  Core:        ${CORE_DIR}"
echo "  Commons:     ${COMMONS_DIR}"
echo "  Swift SDK:   ${SWIFT_DIR}"
echo ""
echo "Actions:"
echo "  Download deps:  ${DOWNLOAD_DEPS}"
echo "  Build commons:  ${BUILD_COMMONS}"
echo "  Build backends: ${BUILD_BACKENDS}"
echo "  Install Swift:  ${INSTALL_SWIFT}"
echo ""
echo "Targets:"
echo "  iOS:     ${TARGET_IOS}"
echo "  Android: ${TARGET_ANDROID}"
echo ""

# Validate paths
[ ! -d "${COMMONS_DIR}" ] && log_error "Commons not found: ${COMMONS_DIR}"
[ "$INSTALL_SWIFT" = true ] && [ ! -d "${SWIFT_DIR}" ] && log_error "Swift SDK not found: ${SWIFT_DIR}"

# =============================================================================
# Clean
# =============================================================================

if [ "$CLEAN_BUILD" = true ]; then
    log_header "Cleaning Build Directories"
    
    log_step "Cleaning core..."
    rm -rf "${CORE_DIR}/build" "${CORE_DIR}/dist"
    
    log_step "Cleaning commons..."
    rm -rf "${COMMONS_DIR}/build" "${COMMONS_DIR}/dist"
    
    log_info "Clean complete"
fi

# =============================================================================
# Download Dependencies
# =============================================================================

if [ "$DOWNLOAD_DEPS" = true ]; then
    log_header "Downloading Dependencies"
    
    if [ "$TARGET_IOS" = true ]; then
        log_step "Downloading iOS dependencies..."
        
        # ONNX Runtime
        if [ ! -d "${CORE_DIR}/third_party/onnxruntime-ios" ]; then
            log_step "Downloading ONNX Runtime for iOS..."
            if [ -f "${CORE_DIR}/scripts/ios/download-onnx.sh" ]; then
                "${CORE_DIR}/scripts/ios/download-onnx.sh"
            else
                log_warn "ONNX download script not found, skipping"
            fi
        else
            log_info "ONNX Runtime already present"
        fi
        
        # Sherpa-ONNX
        if [ ! -d "${CORE_DIR}/third_party/sherpa-onnx-ios" ]; then
            log_step "Downloading Sherpa-ONNX for iOS..."
            if [ -f "${CORE_DIR}/scripts/ios/download-sherpa-onnx.sh" ]; then
                "${CORE_DIR}/scripts/ios/download-sherpa-onnx.sh"
            else
                log_warn "Sherpa-ONNX download script not found, skipping"
            fi
        else
            log_info "Sherpa-ONNX already present"
        fi
    fi
    
    if [ "$TARGET_ANDROID" = true ]; then
        log_step "Downloading Android dependencies..."
        
        # ONNX Runtime for Android
        if [ ! -d "${CORE_DIR}/third_party/onnxruntime-android" ]; then
            log_step "Downloading ONNX Runtime for Android..."
            if [ -f "${CORE_DIR}/scripts/android/download-onnx.sh" ]; then
                "${CORE_DIR}/scripts/android/download-onnx.sh"
            else
                log_warn "Android ONNX download script not found"
            fi
        else
            log_info "ONNX Runtime (Android) already present"
        fi
        
        # Sherpa-ONNX for Android
        if [ ! -d "${CORE_DIR}/third_party/sherpa-onnx-android" ]; then
            if [ -f "${CORE_DIR}/scripts/android/download-sherpa-onnx.sh" ]; then
                "${CORE_DIR}/scripts/android/download-sherpa-onnx.sh"
            else
                log_warn "Android Sherpa-ONNX download script not found"
            fi
        else
            log_info "Sherpa-ONNX (Android) already present"
        fi
    fi
    
    log_info "Dependencies downloaded"
fi

# =============================================================================
# Build Commons
# =============================================================================

if [ "$BUILD_COMMONS" = true ]; then
    log_header "Building RACommons"
    
    cd "${COMMONS_DIR}"
    
    local PLATFORM_FLAGS=""
    [ "$TARGET_IOS" = true ] && [ "$TARGET_ANDROID" = false ] && PLATFORM_FLAGS="--ios"
    [ "$TARGET_ANDROID" = true ] && [ "$TARGET_IOS" = false ] && PLATFORM_FLAGS="--android"
    [ "$TARGET_IOS" = true ] && [ "$TARGET_ANDROID" = true ] && PLATFORM_FLAGS="--all"
    
    if [ -f "scripts/build-rac-commons.sh" ]; then
        ./scripts/build-rac-commons.sh ${PLATFORM_FLAGS} --release
    else
        log_warn "build-rac-commons.sh not found, using legacy build-ios.sh"
        [ "$TARGET_IOS" = true ] && ./scripts/build-ios.sh
    fi
    
    cd "${CORE_DIR}"
    log_info "RACommons built"
fi

# =============================================================================
# Build RAC Backends
# =============================================================================

if [ "$BUILD_BACKENDS" = true ]; then
    log_header "Building RAC Backends"
    
    cd "${CORE_DIR}"
    
    local PLATFORM_FLAGS=""
    [ "$TARGET_IOS" = true ] && [ "$TARGET_ANDROID" = false ] && PLATFORM_FLAGS="--ios"
    [ "$TARGET_ANDROID" = true ] && [ "$TARGET_IOS" = false ] && PLATFORM_FLAGS="--android"
    [ "$TARGET_IOS" = true ] && [ "$TARGET_ANDROID" = true ] && PLATFORM_FLAGS="--all"
    
    if [ -f "scripts/build-rac-backends.sh" ]; then
        ./scripts/build-rac-backends.sh ${PLATFORM_FLAGS} --backends-all --release
    else
        log_warn "build-rac-backends.sh not found, using legacy ios/build.sh"
        [ "$TARGET_IOS" = true ] && ./scripts/ios/build.sh --all
    fi
    
    log_info "RAC Backends built"
fi

# =============================================================================
# Install to Swift SDK
# =============================================================================

if [ "$INSTALL_SWIFT" = true ] && [ "$TARGET_IOS" = true ]; then
    log_header "Installing to Swift SDK"
    
    BINARIES_DIR="${SWIFT_DIR}/Binaries"
    mkdir -p "${BINARIES_DIR}"
    
    # Install RACommons from commons
    if [ -d "${COMMONS_DIR}/dist/RACommons.xcframework" ]; then
        log_step "Installing RACommons.xcframework..."
        rm -rf "${BINARIES_DIR}/RACommons.xcframework"
        cp -R "${COMMONS_DIR}/dist/RACommons.xcframework" "${BINARIES_DIR}/"
        log_info "Installed RACommons.xcframework"
    fi
    
    # Install backend xcframeworks from core
    for xcfw in "${CORE_DIR}/dist/"RABackend*.xcframework; do
        if [ -d "$xcfw" ]; then
            local name=$(basename "$xcfw")
            log_step "Installing ${name}..."
            rm -rf "${BINARIES_DIR}/${name}"
            cp -R "$xcfw" "${BINARIES_DIR}/"
            log_info "Installed ${name}"
        fi
    done
    
    # Install ONNX Runtime
    local ONNX_XCFW="${CORE_DIR}/third_party/onnxruntime-ios/onnxruntime.xcframework"
    if [ -d "$ONNX_XCFW" ]; then
        log_step "Installing onnxruntime.xcframework..."
        rm -rf "${BINARIES_DIR}/onnxruntime.xcframework"
        cp -R "$ONNX_XCFW" "${BINARIES_DIR}/"
        log_info "Installed onnxruntime.xcframework"
    fi
    
    # Sync headers to CRACommons
    log_step "Syncing headers to Swift SDK..."
    local HEADERS_DIR="${SWIFT_DIR}/Sources/CRACommons/include"
    mkdir -p "${HEADERS_DIR}"
    
    # From commons
    if [ -d "${COMMONS_DIR}/include/rac" ]; then
        find "${COMMONS_DIR}/include/rac" -name "*.h" | while read -r header; do
            local filename=$(basename "$header")
            sed 's|#include "rac/.*/\([^/"]*\)"|#include "\1"|g' "$header" > "${HEADERS_DIR}/${filename}"
        done
    fi
    
    # From core (RAC backend headers)
    for header in "${CORE_DIR}/include/rac_"*.h; do
        [ -f "$header" ] && {
            local filename=$(basename "$header")
            sed 's|#include "rac/.*/\([^/"]*\)"|#include "\1"|g' "$header" > "${HEADERS_DIR}/${filename}"
        }
    done
    
    log_info "Headers synced"
    
    # Show installed frameworks
    echo ""
    echo "Installed to ${BINARIES_DIR}:"
    ls -la "${BINARIES_DIR}"/*.xcframework 2>/dev/null | while read -r line; do
        echo "  $line"
    done
fi

# =============================================================================
# Summary
# =============================================================================

log_header "Setup Complete!"

echo "Artifacts:"
echo ""

if [ "$BUILD_COMMONS" = true ]; then
    echo "Commons (${COMMONS_DIR}/dist):"
    [ -d "${COMMONS_DIR}/dist" ] && ls -la "${COMMONS_DIR}/dist"/*.xcframework 2>/dev/null | \
        while read -r line; do echo "  $line"; done
    echo ""
fi

if [ "$BUILD_BACKENDS" = true ]; then
    echo "Core Backends (${CORE_DIR}/dist):"
    [ -d "${CORE_DIR}/dist" ] && ls -la "${CORE_DIR}/dist"/*.xcframework 2>/dev/null | \
        while read -r line; do echo "  $line"; done
    echo ""
fi

if [ "$INSTALL_SWIFT" = true ]; then
    echo "Swift SDK (${SWIFT_DIR}/Binaries):"
    [ -d "${SWIFT_DIR}/Binaries" ] && ls "${SWIFT_DIR}/Binaries"/*.xcframework 2>/dev/null | \
        while read -r line; do echo "  $(basename "$line")"; done
    echo ""
fi

echo "Next steps:"
echo "  1. Open Xcode: open ${SWIFT_DIR}/Package.swift"
echo "  2. Build and run tests"
echo ""
echo "For quick rebuild after changes:"
echo "  ./scripts/setup-local-dev.sh --build-backends --ios --install-swift"

