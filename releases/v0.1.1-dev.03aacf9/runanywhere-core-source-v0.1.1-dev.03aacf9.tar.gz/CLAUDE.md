# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Core Principles

- Focus on **SIMPLICITY**, following Clean SOLID principles. Reusability, clean architecture, clear separation of concerns.
- Do NOT write ANY MOCK IMPLEMENTATION unless specified otherwise.
- DO NOT PLAN or WRITE any unit tests unless specified otherwise.
- Always use **structured types**, never use strings directly for consistency and scalability.
- When fixing issues focus on **SIMPLICITY** - do not add complicated logic unless necessary.
- Don't over plan it, always think **MVP**.

## C++ Specific Rules

- C++17 standard required
- Google C++ Style Guide with project customizations (see `.clang-format`)
- Run `./scripts/lint-cpp.sh` before committing
- Use `./scripts/lint-cpp.sh --fix` to auto-fix formatting issues
- Position-independent code enabled for all builds

## Overview

RunAnywhere Core is a C++17 library providing unified ML inference across multiple backends (ONNX Runtime, LlamaCPP, CoreML, TensorFlow Lite). It exposes a C API for binding to Swift, Kotlin, and other languages. The library uses a capability-based architecture where backends implement modular capabilities (STT, TTS, LLM, VAD, etc.).

## Build Commands

### iOS XCFramework (Primary)
```bash
# First-time setup: download ONNX Runtime dependency
./scripts/download-onnx-ios.sh

# Build XCFramework for iOS device + simulator
./scripts/build-ios.sh
```
Output: `dist/RunAnywhere.xcframework`

### Local macOS/Linux Build
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DRA_BUILD_ONNX=ON
make -j$(sysctl -n hw.ncpu)  # macOS
make -j$(nproc)              # Linux
```

### Build with Tests
```bash
cmake .. -DBUILD_TESTS=ON -DRA_BUILD_TESTS=ON
make && ctest --output-on-failure
```

### Clean Build
```bash
rm -rf build/ dist/
./scripts/build-ios.sh
```

## Architecture

### Capability-Based Design

The codebase follows a capability-based architecture with three layers:

1. **Bridge Layer** (`src/bridge/`) - C API for FFI bindings
   - `runanywhere_bridge.h` - Public C API header (ships with XCFramework)
   - `runanywhere_bridge.cpp` - Delegates to registered backends

2. **Capabilities Layer** (`src/capabilities/`) - Abstract interfaces
   - `capability.h` - Base `ICapability` interface
   - `backend.h` - `Backend` base class with capability registration
   - `stt.h`, `tts.h`, `vad.h`, etc. - Capability-specific interfaces

3. **Backend Layer** (`src/backends/`) - Concrete implementations
   - `onnx/` - ONNX Runtime backend (currently primary)

### Key Patterns

**Backend Registration**: Backends must call `register_onnx_backend()` explicitly before use (due to iOS static library linking behavior). Do not rely on `REGISTER_BACKEND` macro.

**Capability Types** (defined in `capability.h`):
- `TEXT_GENERATION` - LLM inference
- `EMBEDDINGS` - Vector embeddings
- `STT` - Speech-to-text
- `TTS` - Text-to-speech
- `VAD` - Voice activity detection
- `DIARIZATION` - Speaker identification

**C API Conventions** (in `runanywhere_bridge.h`):
- Functions prefixed with `ra_`
- Handles are opaque `void*` pointers
- Strings returned must be freed with `ra_free_string()`
- JSON used for configuration and results
- Callbacks return `bool` to continue/cancel

## Key Files

| File | Purpose |
|------|---------|
| `CMakeLists.txt` | Root build config with platform detection and backend options |
| `src/bridge/runanywhere_bridge.h` | Public C API - the main interface for SDK bindings |
| `src/capabilities/backend.h` | Backend base class and `BackendRegistry` |
| `src/capabilities/types.h` | Shared types (`ra_result_code`, `ra_device_type`) |
| `src/backends/onnx/onnx_backend.h` | ONNX backend with all capability implementations |
| `scripts/build-ios.sh` | iOS XCFramework build script |

## CMake Options

```cmake
-DRA_BUILD_ONNX=ON      # Build ONNX Runtime backend (default)
-DRA_BUILD_LLAMACPP=OFF # Build LlamaCpp backend
-DRA_BUILD_COREML=OFF   # Build CoreML backend (Apple only)
-DRA_BUILD_TFLITE=OFF   # Build TensorFlow Lite backend
-DRA_BUILD_TESTS=OFF    # Build unit tests
```

## Dependencies

- **ONNX Runtime**: Downloaded via `scripts/download-onnx-ios.sh` to `third_party/onnxruntime-ios/`
- **nlohmann/json**: Fetched automatically via CMake FetchContent
- **Sherpa-ONNX** (optional): For streaming STT/TTS/VAD at `third_party/sherpa-onnx-ios/`
- **libarchive**: System library used for archive extraction (optional)

## Platform Notes

- iOS minimum deployment target: 14.0
- Required frameworks for iOS apps: Foundation, CoreML, Accelerate
- Simulator builds include both arm64 and x86_64 architectures
- C++17 standard required, position-independent code enabled
