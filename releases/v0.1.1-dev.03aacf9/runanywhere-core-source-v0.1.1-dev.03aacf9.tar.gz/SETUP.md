# RunAnywhere Core - Setup Guide

This guide will help you set up the RunAnywhere Core repository and build your first XCFramework.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Initial Setup](#initial-setup)
- [Building ONNX Runtime Backend](#building-onnx-runtime-backend)
- [Integration with SDKs](#integration-with-sdks)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### Required Tools

- **macOS** 12.0 or later (for iOS builds)
- **Xcode** 14.0 or later
- **CMake** 3.22 or later
- **Git** with submodule support

### Installation

```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install CMake
brew install cmake

# Install Xcode Command Line Tools
xcode-select --install
```

## Initial Setup

### 1. Clone the Repository

```bash
cd /path/to/your/workspace
git clone https://github.com/RunanywhereAI/runanywhere-core.git
cd runanywhere-core
```

### 2. Initialize Submodules

```bash
git submodule update --init --recursive
```

This will download the `third_party/json` submodule (nlohmann/json library).

### 3. Download ONNX Runtime (iOS Only)

For iOS builds, you need to download the ONNX Runtime framework:

```bash
./scripts/download-onnx-ios.sh
```

**What this does:**
- Downloads ONNX Runtime 1.16.3 iOS xcframework from Microsoft's CDN
- Extracts it to `third_party/onnxruntime-ios/`
- Total size: ~189MB

**Alternative - Manual Download:**

If the script fails, you can download manually:

```bash
# Create directory
mkdir -p third_party/onnxruntime-ios
cd third_party/onnxruntime-ios

# Download
curl -L -o onnxruntime-c-1.16.3.zip \
  "https://download.onnxruntime.ai/pod-archive-onnxruntime-c-1.16.3.zip"

# Extract
unzip onnxruntime-c-1.16.3.zip
rm onnxruntime-c-1.16.3.zip

# Go back to root
cd ../..
```

## Building ONNX Runtime Backend

### Build for iOS

The following command builds the ONNX Runtime backend as an XCFramework for iOS:

```bash
./scripts/build-ios-onnx.sh
```

**What this does:**
1. Configures CMake for iOS device (arm64) and simulator (arm64 + x86_64)
2. Builds RunAnywhere ONNX backend C++ code
3. Combines with ONNX Runtime static library
4. Creates `dist/RunAnywhereONNX.xcframework`
5. Total build time: ~2-5 minutes

**Output:**
```
dist/RunAnywhereONNX.xcframework/
├── ios-arm64/                          # Device architecture
│   ├── Headers/                        # C API headers
│   └── librunanywhere_onnx_combined.a  # Static library (~95MB)
├── ios-arm64_x86_64-simulator/         # Simulator architectures
│   ├── Headers/
│   └── librunanywhere_onnx_combined.a  # Static library (~95MB)
└── Info.plist
```

### Verify the Build

```bash
# Check XCFramework exists
ls -lh dist/RunAnywhereONNX.xcframework

# Verify ONNX Runtime symbols are included
nm -g dist/RunAnywhereONNX.xcframework/ios-arm64/librunanywhere_onnx_combined.a | grep OrtGetApiBase
# Should see: 0000000000003c28 T _OrtGetApiBase
```

### Clean Build (if needed)

```bash
# Remove all build artifacts
rm -rf build/ dist/

# Rebuild from scratch
./scripts/build-ios-onnx.sh
```

## Integration with SDKs

### Swift SDK Integration

Copy the built XCFramework to the Swift SDK:

```bash
# Path to your Swift SDK
SWIFT_SDK="/path/to/runanywhere-swift"

# Copy XCFramework
cp -r dist/RunAnywhereONNX.xcframework \
  "${SWIFT_SDK}/XCFrameworks/"

echo "✅ XCFramework copied to Swift SDK"
```

### Verify Integration

In your Swift SDK, the ONNXRuntime module should now import successfully:

```swift
import ONNXRuntime  // Should work without errors

// Use the ONNX backend
await ONNXServiceProvider.register()
```

## Troubleshooting

### Common Issues

#### 1. "ONNX Runtime xcframework not found"

**Problem:** CMake can't find the ONNX Runtime dependency.

**Solution:**
```bash
# Ensure ONNX Runtime is downloaded
ls third_party/onnxruntime-ios/onnxruntime.xcframework

# If missing, download it
./scripts/download-onnx-ios.sh
```

#### 2. "Undefined symbol: _OrtGetApiBase"

**Problem:** ONNX Runtime library not linked properly.

**Solution:**
```bash
# Clean and rebuild
rm -rf build/ dist/
./scripts/download-onnx-ios.sh
./scripts/build-ios-onnx.sh

# Verify symbols
nm -g dist/RunAnywhereONNX.xcframework/ios-arm64/librunanywhere_onnx_combined.a | grep OrtGetApiBase
```

#### 3. "CMake version too old"

**Problem:** CMake 3.22+ required.

**Solution:**
```bash
# Update CMake
brew upgrade cmake

# Verify version
cmake --version  # Should be 3.22 or later
```

#### 4. "Xcode build tools not found"

**Problem:** Xcode Command Line Tools not installed.

**Solution:**
```bash
# Install Command Line Tools
xcode-select --install

# Verify installation
xcode-select -p  # Should print path to Xcode
```

#### 5. "Module 'RunAnywhereONNX' not found" in Swift

**Problem:** XCFramework not copied to Swift SDK, or module.modulemap conflicts.

**Solution:**
```bash
# Ensure XCFramework is in the right location
ls /path/to/runanywhere-swift/XCFrameworks/RunAnywhereONNX.xcframework

# Ensure no module.modulemap files exist (they cause conflicts)
find /path/to/runanywhere-swift/XCFrameworks/RunAnywhereONNX.xcframework -name "module.modulemap"
# Should return nothing

# In Xcode, clean build folder
# Product → Clean Build Folder (⌘ + Shift + K)

# Reset package caches
# File → Packages → Reset Package Caches
```

### Getting Help

1. Check the [documentation](docs/)
2. Review [build logs](#build-logs) for errors
3. See [ONNX Runtime Setup Guide](docs/ONNX_RUNTIME_SETUP.md) for detailed troubleshooting

### Build Logs

Build logs are saved to `/tmp/onnx_build.log`:

```bash
# View build log
less /tmp/onnx_build.log

# Search for errors
grep -i error /tmp/onnx_build.log
```

## Next Steps

- Read the [Architecture Documentation](plans/private-core-architecture.md)
- Review [Implementation Status](IMPLEMENTATION_STATUS.md)
- Check [API Documentation](MODALITY_SUPPORT.md)
- Build for other platforms (Android, Linux, macOS)

---

**Need help?** Contact the RunAnywhere team or check the documentation in `docs/`.
