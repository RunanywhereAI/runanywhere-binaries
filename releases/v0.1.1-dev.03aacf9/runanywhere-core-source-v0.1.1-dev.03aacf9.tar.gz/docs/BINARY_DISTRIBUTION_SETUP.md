# Binary Distribution Setup Guide

This guide explains how to set up the binary distribution pipeline that builds XCFrameworks in the private `runanywhere-core` repo and publishes them to a public `runanywhere-binaries` repo.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     PRIVATE: runanywhere-core                            │
│                                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                   │
│  │ ONNX Backend │  │ CoreML       │  │ TFLite       │                   │
│  │              │  │ Backend      │  │ Backend      │                   │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘                   │
│         │                 │                 │                            │
│         └────────────────┬┴─────────────────┘                            │
│                          │                                               │
│                          ▼                                               │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │              GitHub Actions: release-binaries.yml                 │   │
│  │  - Builds XCFrameworks for each backend                          │   │
│  │  - Generates checksums (SHA-256)                                 │   │
│  │  - Generates Package.swift & podspec                             │   │
│  │  - Pushes to public repo                                         │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼ Publishes to
┌─────────────────────────────────────────────────────────────────────────┐
│                    PUBLIC: runanywhere-binaries                          │
│                                                                          │
│  ├── Package.swift              # SPM manifest (auto-generated)          │
│  ├── *.podspec                  # CocoaPods specs (auto-generated)       │
│  ├── versions.json              # Android manifest with checksums        │
│  └── LICENSE                    # MIT License                            │
│                                                                          │
│  GitHub Releases:                                                        │
│  └── v1.0.0                                                             │
│      ├── RunAnywhereCore.xcframework.zip      # iOS unified framework   │
│      ├── RunAnywhereONNX-android.zip          # Android ONNX backend    │
│      ├── RunAnywhereLlamaCPP-android.zip      # Android LlamaCPP        │
│      └── checksums.txt                                                  │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼ Consumed by
┌─────────────────────────────────────────────────────────────────────────┐
│                         Consumer Apps                                    │
│                                                                          │
│  Swift Package Manager:                                                  │
│  .package(url: "https://github.com/YourOrg/runanywhere-binaries", ...)  │
│                                                                          │
│  CocoaPods:                                                              │
│  pod 'RunAnywhere/ONNX'                                                  │
└─────────────────────────────────────────────────────────────────────────┘
```

## Setup Steps

### Step 1: Create the Public Binaries Repository

1. Create a new **public** repository named `runanywhere-binaries` in your GitHub organization.

2. Initialize it with minimal files (the release workflow generates everything else):

```bash
# Create the public repo directory
mkdir runanywhere-binaries && cd runanywhere-binaries

# Create minimal files
echo "# RunAnywhere Binaries" > README.md
echo "MIT License" > LICENSE
git init
git add .
git commit -m "Initial setup"
git remote add origin https://github.com/YourOrg/runanywhere-binaries.git
git push -u origin main
```

> **Note:** The `generate-spm-package.sh` script automatically generates `Package.swift` and `*.podspec` files during the release workflow. No templates needed.

### Step 2: Create a Personal Access Token (PAT)

The private repo needs permission to push to the public repo. Create a PAT:

1. Go to GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens
2. Click "Generate new token"
3. Configure:
   - **Name**: `runanywhere-binary-release`
   - **Repository access**: Select `runanywhere-binaries` (public repo only)
   - **Permissions**:
     - Contents: Read and write
     - Metadata: Read-only
4. Copy the generated token

### Step 3: Add Repository Secret

Add the PAT as a secret in the **private** `runanywhere-core` repo:

1. Go to `runanywhere-core` → Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Name: `BINARY_REPO_PAT`
4. Value: Paste the PAT from Step 2
5. Click "Add secret"

### Step 4: Configure the Workflow

Edit `.github/workflows/release-binaries.yml` to match your organization:

```yaml
env:
  # Update these to match your GitHub organization
  PUBLIC_REPO_OWNER: 'YourOrg'
  PUBLIC_REPO_NAME: 'runanywhere-binaries'
```

### Step 5: Test the Pipeline

#### Manual Test (Dry Run)

```bash
# Trigger workflow manually without publishing
gh workflow run release-binaries.yml \
  -f version=0.0.1-test \
  -f backends=onnx \
  -f dry_run=true
```

#### Full Release Test

```bash
# Create and push a test tag
git tag v0.0.1-test
git push origin v0.0.1-test
```

Monitor the Actions tab to see the workflow run.

## Usage

### Creating a Release

1. **Tag the release** in `runanywhere-core`:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

2. **Automatic workflow** will:
   - Build XCFrameworks for all configured backends
   - Generate checksums
   - Generate `Package.swift` and `RunAnywhere.podspec`
   - Push to `runanywhere-binaries`
   - Create a GitHub Release with all assets

3. **Consumers** can now use:
   ```swift
   // SPM
   .package(url: "https://github.com/YourOrg/runanywhere-binaries.git", from: "1.0.0")
   ```
   ```ruby
   # CocoaPods
   pod 'RunAnywhere', '~> 1.0.0'
   ```

### Manual Trigger

For building specific backends or testing:

```bash
# Build only ONNX for iOS
gh workflow run release-binaries.yml \
  -f version=1.0.0 \
  -f backends=onnx \
  -f platforms=ios

# Build all backends
gh workflow run release-binaries.yml \
  -f version=1.0.0 \
  -f backends=all \
  -f platforms=ios
```

## Files Overview

### In runanywhere-core (Private)

| File | Purpose |
|------|---------|
| `.github/workflows/release-binaries.yml` | Main CI/CD workflow |
| `scripts/ios/build.sh` | Builds iOS XCFrameworks |
| `scripts/ios/generate-spm-package.sh` | Generates Package.swift & podspec |
| `scripts/android/build.sh` | Builds Android native libraries |
| `scripts/android/generate-maven-package.sh` | Generates versions.json manifest |

### In runanywhere-binaries (Public)

| File | Purpose |
|------|---------|
| `Package.swift` | SPM manifest with binary targets (auto-generated) |
| `*.podspec` | CocoaPods specifications (auto-generated) |
| `versions.json` | Android version manifest with checksums |
| `checksums-android.txt` | Android checksum file |
| GitHub Releases | XCFrameworks and Android zips with checksums |

## Troubleshooting

### Workflow fails with "Resource not accessible"

- Ensure `BINARY_REPO_PAT` secret is set correctly
- Verify the PAT has write access to the public repo
- Check the PAT hasn't expired

### Checksum mismatch errors in SPM

- Re-run the release workflow
- Verify artifacts weren't modified after checksum generation
- Check for download corruption

### Build fails for specific backend

- Check if the backend's dependencies are available (e.g., ONNX Runtime)
- Run the build script locally: `./scripts/build-ios-backend.sh onnx`
- Check CMakeLists.txt for backend-specific configuration

### CocoaPods lint fails

- Validate locally: `pod spec lint RunAnywhere.podspec --verbose`
- Ensure all XCFramework URLs are accessible
- Check checksum values match actual files

## Versioning Strategy

Follow semantic versioning (SemVer):

- **MAJOR**: Breaking API changes
- **MINOR**: New features, backward compatible
- **PATCH**: Bug fixes, backward compatible

Pre-release versions:
```bash
git tag v1.0.0-beta.1
git tag v1.0.0-rc.1
```

## Security Considerations

1. **PAT Scope**: Only grant minimum required permissions
2. **Binary Verification**: Always verify checksums before use
3. **Code Signing**: Consider adding code signing for production releases
4. **Audit Trail**: All releases are traceable via git tags and commit SHAs

## Support

- Issues: https://github.com/YourOrg/runanywhere/issues
- Documentation: https://runanywhere.ai/docs
