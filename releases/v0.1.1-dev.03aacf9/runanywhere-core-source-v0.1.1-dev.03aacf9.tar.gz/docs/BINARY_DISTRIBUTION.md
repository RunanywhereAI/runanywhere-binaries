# RunAnywhere Binary Distribution Guide

This document describes how to publicly release and consume native binaries (XCFrameworks, AARs, Flutter plugins) for the RunAnywhere multi-backend architecture.

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [Distribution Options](#distribution-options)
- [iOS: XCFramework Distribution](#ios-xcframework-distribution)
- [Android: AAR Distribution](#android-aar-distribution)
- [Flutter: Plugin Distribution](#flutter-plugin-distribution)
- [CI/CD Automation](#cicd-automation)
- [Versioning Strategy](#versioning-strategy)
- [Recommended Approach](#recommended-approach)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     PRIVATE: runanywhere-core                            │
│                                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ ONNX Backend │  │ CoreML       │  │ TFLite       │  │ LlamaCpp     │ │
│  │              │  │ Backend      │  │ Backend      │  │ Backend      │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                 │                 │                 │          │
│         ▼                 ▼                 ▼                 ▼          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                    CI/CD Build Pipeline                          │   │
│  │  - Builds XCFrameworks (iOS/macOS)                               │   │
│  │  - Builds AARs (Android)                                         │   │
│  │  - Packages Flutter plugins                                      │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼ Publishes to
┌─────────────────────────────────────────────────────────────────────────┐
│                    PUBLIC: Binary Distribution                           │
│                                                                          │
│  Option A: GitHub Releases    Option B: Package Registries              │
│  ├── RunAnywhereONNX.xcframework.zip                                    │
│  ├── RunAnywhereCoreML.xcframework.zip     - CocoaPods Trunk            │
│  ├── runanywhere-onnx.aar                  - Maven Central              │
│  └── runanywhere-tflite.aar                - pub.dev                    │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼ Consumed by
┌─────────────────────────────────────────────────────────────────────────┐
│                    PUBLIC: runanywhere-sdks                              │
│                                                                          │
│  iOS (SPM)              Android (Gradle)         Flutter (pub.dev)      │
│  ├── RunAnywhereCore    ├── :core                ├── runanywhere_core   │
│  ├── RunAnywhereVoice   ├── :voice               ├── runanywhere_voice  │
│  ├── RunAnywhereVision  ├── :vision              ├── runanywhere_vision │
│  └── RunAnywhereChat    └── :chat                └── runanywhere_chat   │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Distribution Options

### Option 1: GitHub Releases (Recommended for simplicity)

| Pros | Cons |
|------|------|
| Free hosting | Manual checksum management |
| Works with SPM binary targets | Requires public repo for releases |
| Simple CI/CD integration | No dependency resolution |
| Supports versioned releases | |

### Option 2: Dedicated Binary Repository

| Pros | Cons |
|------|------|
| Clean separation of source/binaries | Extra repo to maintain |
| Can include Package.swift/podspec | Requires Git LFS for large files |
| Works as SPM package directly | |

### Option 3: Package Registries

| Platform | Registry | Pros | Cons |
|----------|----------|------|------|
| iOS | CocoaPods Trunk | Wide adoption, dependency management | Requires account, review process |
| iOS | Swift Package Index | Discovery, documentation | Just an index, not hosting |
| Android | Maven Central | Standard, trusted | Complex publishing process |
| Android | GitHub Packages | Easy CI/CD | Requires auth for consumers |
| Flutter | pub.dev | Official, discovery | Public only, review process |

### Option 4: Cloud Storage (S3/GCS/Azure)

| Pros | Cons |
|------|------|
| Full control | Hosting costs |
| CDN integration | More infrastructure to manage |
| Private + public options | Manual URL management |

---

## iOS: XCFramework Distribution

### Structure: Multi-Backend XCFrameworks

```
runanywhere-apple-binaries/          # Public repo or release assets
├── releases/
│   └── v1.0.0/
│       ├── RunAnywhereONNX.xcframework.zip
│       ├── RunAnywhereONNX.xcframework.zip.sha256
│       ├── RunAnywhereCoreML.xcframework.zip
│       ├── RunAnywhereCoreML.xcframework.zip.sha256
│       ├── RunAnywhereTFLite.xcframework.zip
│       └── RunAnywhereTFLite.xcframework.zip.sha256
├── Package.swift                    # SPM manifest
└── RunAnywhere.podspec              # CocoaPods spec
```

### Method 1: Swift Package Manager (SPM) with Binary Targets

```swift
// Package.swift
import PackageDescription

let version = "1.0.0"
let baseURL = "https://github.com/YourOrg/runanywhere-apple-binaries/releases/download/v\(version)"

let package = Package(
    name: "RunAnywhere",
    platforms: [
        .iOS(.v15),
        .macOS(.v12)
    ],
    products: [
        // Individual backend libraries - consumers choose which to use
        .library(name: "RunAnywhereONNX", targets: ["RunAnywhereONNX", "RunAnywhereONNXBinary"]),
        .library(name: "RunAnywhereCoreML", targets: ["RunAnywhereCoreML", "RunAnywhereCoreMLBinary"]),
        .library(name: "RunAnywhereTFLite", targets: ["RunAnywhereTFLite", "RunAnywhereTFLiteBinary"]),

        // Umbrella library that includes all backends
        .library(name: "RunAnywhereAll", targets: ["RunAnywhereAll"]),
    ],
    targets: [
        // =====================================================================
        // ONNX Backend
        // =====================================================================
        .binaryTarget(
            name: "RunAnywhereONNXBinary",
            url: "\(baseURL)/RunAnywhereONNX.xcframework.zip",
            checksum: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        ),
        .target(
            name: "RunAnywhereONNX",
            dependencies: ["RunAnywhereONNXBinary"],
            path: "Sources/ONNX"
        ),

        // =====================================================================
        // CoreML Backend (Apple-only)
        // =====================================================================
        .binaryTarget(
            name: "RunAnywhereCoreMLBinary",
            url: "\(baseURL)/RunAnywhereCoreML.xcframework.zip",
            checksum: "a1b2c3d4e5f6..."
        ),
        .target(
            name: "RunAnywhereCoreML",
            dependencies: ["RunAnywhereCoreMLBinary"],
            path: "Sources/CoreML"
        ),

        // =====================================================================
        // TFLite Backend
        // =====================================================================
        .binaryTarget(
            name: "RunAnywhereTFLiteBinary",
            url: "\(baseURL)/RunAnywhereTFLite.xcframework.zip",
            checksum: "f6e5d4c3b2a1..."
        ),
        .target(
            name: "RunAnywhereTFLite",
            dependencies: ["RunAnywhereTFLiteBinary"],
            path: "Sources/TFLite"
        ),

        // =====================================================================
        // Umbrella target (all backends)
        // =====================================================================
        .target(
            name: "RunAnywhereAll",
            dependencies: [
                "RunAnywhereONNX",
                "RunAnywhereCoreML",
                "RunAnywhereTFLite"
            ],
            path: "Sources/All"
        ),
    ]
)
```

### Consumer Usage (SPM)

```swift
// Consumer's Package.swift - choose specific backends
dependencies: [
    .package(url: "https://github.com/YourOrg/runanywhere-apple-binaries.git", from: "1.0.0")
],
targets: [
    .target(
        name: "MyApp",
        dependencies: [
            // Only include ONNX backend (smaller binary size)
            .product(name: "RunAnywhereONNX", package: "runanywhere-apple-binaries"),
        ]
    )
]

// Or include all backends
dependencies: [
    .product(name: "RunAnywhereAll", package: "runanywhere-apple-binaries"),
]
```

### Method 2: CocoaPods with Subspecs

```ruby
# RunAnywhere.podspec
Pod::Spec.new do |s|
  s.name         = 'RunAnywhere'
  s.version      = '1.0.0'
  s.summary      = 'On-device ML inference framework'
  s.homepage     = 'https://github.com/YourOrg/runanywhere'
  s.license      = { :type => 'MIT' }
  s.author       = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source       = { :http => 'https://github.com/YourOrg/runanywhere-apple-binaries/releases/download/v#{s.version}/RunAnywhere-#{s.version}.zip' }

  s.ios.deployment_target = '15.0'
  s.osx.deployment_target = '12.0'

  # Default subspec
  s.default_subspecs = 'ONNX'

  # ONNX Backend
  s.subspec 'ONNX' do |onnx|
    onnx.vendored_frameworks = 'Frameworks/RunAnywhereONNX.xcframework'
    onnx.source_files = 'Sources/ONNX/**/*.swift'
  end

  # CoreML Backend
  s.subspec 'CoreML' do |coreml|
    coreml.vendored_frameworks = 'Frameworks/RunAnywhereCoreML.xcframework'
    coreml.source_files = 'Sources/CoreML/**/*.swift'
    coreml.frameworks = 'CoreML', 'Accelerate'
  end

  # TFLite Backend
  s.subspec 'TFLite' do |tflite|
    tflite.vendored_frameworks = 'Frameworks/RunAnywhereTFLite.xcframework'
    tflite.source_files = 'Sources/TFLite/**/*.swift'
  end

  # All backends
  s.subspec 'All' do |all|
    all.dependency 'RunAnywhere/ONNX'
    all.dependency 'RunAnywhere/CoreML'
    all.dependency 'RunAnywhere/TFLite'
  end
end
```

### Consumer Usage (CocoaPods)

```ruby
# Podfile - choose specific backends
pod 'RunAnywhere/ONNX'
pod 'RunAnywhere/CoreML'

# Or all backends
pod 'RunAnywhere/All'
```

---

## Android: AAR Distribution

### Structure: Multi-Backend AARs

```
runanywhere-android/                 # Public repo
├── core/                            # Shared interfaces
│   └── build.gradle
├── backend-onnx/                    # ONNX backend
│   └── build.gradle
├── backend-tflite/                  # TFLite backend
│   └── build.gradle
├── backend-nnapi/                   # NNAPI backend
│   └── build.gradle
└── settings.gradle
```

### Method 1: Maven Central (Recommended for public libraries)

```groovy
// backend-onnx/build.gradle
plugins {
    id 'com.android.library'
    id 'maven-publish'
    id 'signing'
}

android {
    namespace 'com.runanywhere.backend.onnx'
    compileSdk 34

    defaultConfig {
        minSdk 24

        ndk {
            abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
        }

        externalNativeBuild {
            cmake {
                cppFlags '-std=c++17'
            }
        }
    }

    externalNativeBuild {
        cmake {
            path 'src/main/cpp/CMakeLists.txt'
        }
    }
}

dependencies {
    api project(':core')
    implementation 'com.microsoft.onnxruntime:onnxruntime-android:1.16.3'
}

publishing {
    publications {
        release(MavenPublication) {
            groupId = 'com.runanywhere'
            artifactId = 'backend-onnx'
            version = '1.0.0'

            afterEvaluate {
                from components.release
            }

            pom {
                name = 'RunAnywhere ONNX Backend'
                description = 'ONNX Runtime backend for RunAnywhere ML framework'
                url = 'https://github.com/YourOrg/runanywhere-android'

                licenses {
                    license {
                        name = 'MIT License'
                        url = 'https://opensource.org/licenses/MIT'
                    }
                }

                developers {
                    developer {
                        id = 'runanywhere'
                        name = 'RunAnywhere Team'
                    }
                }

                scm {
                    connection = 'scm:git:github.com/YourOrg/runanywhere-android.git'
                    url = 'https://github.com/YourOrg/runanywhere-android'
                }
            }
        }
    }

    repositories {
        maven {
            name = "MavenCentral"
            url = "https://s01.oss.sonatype.org/service/local/staging/deploy/maven2/"
            credentials {
                username = System.getenv("MAVEN_USERNAME")
                password = System.getenv("MAVEN_PASSWORD")
            }
        }
    }
}

signing {
    sign publishing.publications.release
}
```

### Method 2: GitHub Packages (Easier setup, requires auth)

```groovy
// backend-onnx/build.gradle
publishing {
    repositories {
        maven {
            name = "GitHubPackages"
            url = uri("https://maven.pkg.github.com/YourOrg/runanywhere-android")
            credentials {
                username = System.getenv("GITHUB_ACTOR")
                password = System.getenv("GITHUB_TOKEN")
            }
        }
    }
}
```

### Consumer Usage (Gradle)

```groovy
// settings.gradle (for GitHub Packages)
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        // Only needed for GitHub Packages
        maven {
            url = uri("https://maven.pkg.github.com/YourOrg/runanywhere-android")
            credentials {
                username = System.getenv("GITHUB_ACTOR") ?: ""
                password = System.getenv("GITHUB_TOKEN") ?: ""
            }
        }
    }
}

// app/build.gradle - choose specific backends
dependencies {
    // Core (required)
    implementation 'com.runanywhere:core:1.0.0'

    // Choose backend(s)
    implementation 'com.runanywhere:backend-onnx:1.0.0'
    // implementation 'com.runanywhere:backend-tflite:1.0.0'
    // implementation 'com.runanywhere:backend-nnapi:1.0.0'
}
```

### Method 3: Pre-built AAR via GitHub Releases

```groovy
// If not using Maven, download AAR from releases
// build.gradle
repositories {
    flatDir {
        dirs 'libs'
    }
}

dependencies {
    implementation(name: 'runanywhere-onnx-1.0.0', ext: 'aar')
}
```

---

## Flutter: Plugin Distribution

### Structure: Multi-Backend Flutter Plugins

```
runanywhere_flutter/
├── runanywhere_core/                # Core plugin with native binaries
│   ├── pubspec.yaml
│   ├── lib/
│   │   └── runanywhere_core.dart
│   ├── ios/
│   │   ├── Classes/
│   │   └── runanywhere_core.podspec
│   └── android/
│       └── build.gradle
│
├── runanywhere_onnx/                # ONNX backend plugin
│   ├── pubspec.yaml
│   ├── lib/
│   │   └── runanywhere_onnx.dart
│   ├── ios/
│   │   └── runanywhere_onnx.podspec
│   └── android/
│       └── build.gradle
│
├── runanywhere_tflite/              # TFLite backend plugin
│   └── ...
│
├── runanywhere_voice/               # Voice capability (uses backends)
│   ├── pubspec.yaml
│   └── lib/
│       └── runanywhere_voice.dart
│
└── runanywhere/                     # Umbrella plugin
    └── pubspec.yaml
```

### Core Plugin Setup

```yaml
# runanywhere_core/pubspec.yaml
name: runanywhere_core
description: Core interfaces for RunAnywhere ML framework
version: 1.0.0
homepage: https://github.com/YourOrg/runanywhere-flutter

environment:
  sdk: '>=3.0.0 <4.0.0'
  flutter: '>=3.10.0'

flutter:
  plugin:
    platforms:
      android:
        package: com.runanywhere.core
        pluginClass: RunAnywhereCorePlugin
      ios:
        pluginClass: RunAnywhereCorePlugin
```

### Backend Plugin Setup (ONNX Example)

```yaml
# runanywhere_onnx/pubspec.yaml
name: runanywhere_onnx
description: ONNX Runtime backend for RunAnywhere
version: 1.0.0

environment:
  sdk: '>=3.0.0 <4.0.0'
  flutter: '>=3.10.0'

dependencies:
  flutter:
    sdk: flutter
  runanywhere_core: ^1.0.0

flutter:
  plugin:
    platforms:
      android:
        package: com.runanywhere.backend.onnx
        pluginClass: RunAnywhereOnnxPlugin
      ios:
        pluginClass: RunAnywhereOnnxPlugin
```

```ruby
# runanywhere_onnx/ios/runanywhere_onnx.podspec
Pod::Spec.new do |s|
  s.name             = 'runanywhere_onnx'
  s.version          = '1.0.0'
  s.summary          = 'ONNX backend for RunAnywhere Flutter plugin'
  s.homepage         = 'https://github.com/YourOrg/runanywhere-flutter'
  s.license          = { :type => 'MIT' }
  s.author           = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source           = { :path => '.' }
  s.source_files     = 'Classes/**/*'

  s.platform         = :ios, '15.0'
  s.swift_version    = '5.0'

  s.dependency 'Flutter'

  # Pull XCFramework from GitHub Releases
  s.prepare_command = <<-CMD
    mkdir -p Frameworks
    curl -L "https://github.com/YourOrg/runanywhere-apple-binaries/releases/download/v1.0.0/RunAnywhereONNX.xcframework.zip" -o onnx.zip
    unzip -o onnx.zip -d Frameworks/
    rm onnx.zip
  CMD

  s.vendored_frameworks = 'Frameworks/RunAnywhereONNX.xcframework'

  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
```

```groovy
// runanywhere_onnx/android/build.gradle
plugins {
    id 'com.android.library'
}

android {
    namespace 'com.runanywhere.backend.onnx'
    compileSdk 34

    defaultConfig {
        minSdk 24
    }
}

dependencies {
    implementation 'com.runanywhere:backend-onnx:1.0.0'  // From Maven
}
```

### Consumer Usage (Flutter)

```yaml
# Consumer's pubspec.yaml
dependencies:
  flutter:
    sdk: flutter

  # Core + specific backend
  runanywhere_core: ^1.0.0
  runanywhere_onnx: ^1.0.0

  # Higher-level capabilities (auto-pulls core)
  runanywhere_voice: ^1.0.0
```

```dart
// main.dart
import 'package:runanywhere_core/runanywhere_core.dart';
import 'package:runanywhere_onnx/runanywhere_onnx.dart';
import 'package:runanywhere_voice/runanywhere_voice.dart';

void main() async {
  // Register ONNX backend
  RunAnywhere.registerBackend(OnnxBackend());

  // Use voice capabilities
  final voice = RunAnywhereVoice();
  await voice.initialize();

  final result = await voice.transcribe(audioData);
  print(result.text);
}
```

---

## CI/CD Automation

### GitHub Actions: Build and Release All Platforms

```yaml
# .github/workflows/release.yml
name: Build and Release Binaries

on:
  push:
    tags:
      - 'v*'

env:
  VERSION: ${{ github.ref_name }}

jobs:
  # ===========================================================================
  # iOS XCFrameworks
  # ===========================================================================
  build-ios:
    runs-on: macos-14
    strategy:
      matrix:
        backend: [onnx, coreml, tflite]

    steps:
      - uses: actions/checkout@v4
        with:
          submodules: recursive

      - name: Setup Xcode
        uses: maxim-lobanov/setup-xcode@v1
        with:
          xcode-version: latest-stable

      - name: Build XCFramework
        run: ./scripts/build-ios-${{ matrix.backend }}.sh

      - name: Package
        run: |
          cd dist
          zip -r RunAnywhere${{ matrix.backend }}.xcframework.zip RunAnywhere${{ matrix.backend }}.xcframework
          shasum -a 256 RunAnywhere${{ matrix.backend }}.xcframework.zip > RunAnywhere${{ matrix.backend }}.xcframework.zip.sha256

      - name: Upload Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ios-${{ matrix.backend }}
          path: |
            dist/*.zip
            dist/*.sha256

  # ===========================================================================
  # Android AARs
  # ===========================================================================
  build-android:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        backend: [onnx, tflite, nnapi]

    steps:
      - uses: actions/checkout@v4
        with:
          submodules: recursive

      - name: Setup JDK
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Build AAR
        run: |
          cd android
          ./gradlew :backend-${{ matrix.backend }}:assembleRelease

      - name: Upload Artifact
        uses: actions/upload-artifact@v4
        with:
          name: android-${{ matrix.backend }}
          path: android/backend-${{ matrix.backend }}/build/outputs/aar/*.aar

  # ===========================================================================
  # Create Release
  # ===========================================================================
  release:
    needs: [build-ios, build-android]
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Download All Artifacts
        uses: actions/download-artifact@v4
        with:
          path: artifacts

      - name: Generate Checksums
        run: |
          cd artifacts
          find . -name "*.zip" -o -name "*.aar" | while read f; do
            sha256sum "$f" >> checksums.txt
          done

      - name: Update Package.swift Checksums
        run: |
          # Script to update checksums in Package.swift
          ./scripts/update-spm-checksums.sh artifacts/checksums.txt

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
        with:
          files: |
            artifacts/**/*.zip
            artifacts/**/*.sha256
            artifacts/**/*.aar
            artifacts/checksums.txt
          body: |
            ## RunAnywhere ${{ env.VERSION }}

            ### iOS (XCFrameworks)
            - `RunAnywhereONNX.xcframework.zip`
            - `RunAnywhereCoreML.xcframework.zip`
            - `RunAnywhereTFLite.xcframework.zip`

            ### Android (AARs)
            - `backend-onnx-release.aar`
            - `backend-tflite-release.aar`
            - `backend-nnapi-release.aar`

            See checksums.txt for SHA256 verification.
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      # Optionally publish to Maven Central
      - name: Publish to Maven Central
        if: startsWith(github.ref, 'refs/tags/v')
        run: |
          cd android
          ./gradlew publishAllPublicationsToMavenCentralRepository
        env:
          MAVEN_USERNAME: ${{ secrets.MAVEN_USERNAME }}
          MAVEN_PASSWORD: ${{ secrets.MAVEN_PASSWORD }}
          GPG_PRIVATE_KEY: ${{ secrets.GPG_PRIVATE_KEY }}
          GPG_PASSPHRASE: ${{ secrets.GPG_PASSPHRASE }}
```

### Script: Update SPM Checksums

```bash
#!/bin/bash
# scripts/update-spm-checksums.sh

CHECKSUMS_FILE=$1
PACKAGE_SWIFT="Package.swift"

while IFS= read -r line; do
    checksum=$(echo "$line" | awk '{print $1}')
    filename=$(echo "$line" | awk '{print $2}' | xargs basename)

    # Extract backend name from filename (e.g., RunAnywhereONNX.xcframework.zip -> ONNX)
    backend=$(echo "$filename" | sed 's/RunAnywhere\(.*\)\.xcframework\.zip/\1/')

    # Update Package.swift
    sed -i "s/checksum: \".*\" \/\/ $backend/checksum: \"$checksum\" \/\/ $backend/" "$PACKAGE_SWIFT"
done < "$CHECKSUMS_FILE"
```

---

## Versioning Strategy

### Semantic Versioning

```
MAJOR.MINOR.PATCH
  │     │     └── Bug fixes, no API changes
  │     └──────── New features, backward compatible
  └────────────── Breaking API changes
```

### Version Synchronization

Keep all components in sync:

| Component | Version | Notes |
|-----------|---------|-------|
| runanywhere-core | 1.0.0 | C++ source |
| RunAnywhereONNX.xcframework | 1.0.0 | iOS binary |
| com.runanywhere:backend-onnx | 1.0.0 | Android AAR |
| runanywhere_onnx (pub.dev) | 1.0.0 | Flutter plugin |

### Git Tags

```bash
# Tag format
git tag -a v1.0.0 -m "Release 1.0.0"
git push origin v1.0.0

# Pre-release tags
git tag -a v1.0.0-beta.1 -m "Beta 1"
git tag -a v1.0.0-rc.1 -m "Release candidate 1"
```

---

## Recommended Approach

Based on your requirements (private source, public binaries, multiple backends, multiple platforms), here's the recommended setup:

### 1. Repository Structure

```
GitHub Organization
├── runanywhere-core (PRIVATE)
│   └── C++ source, build scripts, CI/CD
│
├── runanywhere-binaries (PUBLIC)
│   ├── Package.swift          # SPM with binary targets
│   ├── RunAnywhere.podspec    # CocoaPods
│   └── README.md
│
├── runanywhere-android (PUBLIC)
│   ├── Published to Maven Central
│   └── Source available for reference
│
└── runanywhere-flutter (PUBLIC)
    └── Published to pub.dev
```

### 2. Distribution Flow

```
1. Developer pushes tag to runanywhere-core
                    │
                    ▼
2. CI/CD builds all backends for all platforms
                    │
                    ▼
3. Binaries uploaded to:
   - GitHub Releases on runanywhere-binaries
   - Maven Central for Android
   - pub.dev for Flutter
                    │
                    ▼
4. Package manifests updated with new checksums
                    │
                    ▼
5. Consumers update dependency version
```

### 3. Consumer Experience

```swift
// iOS - Just add SPM dependency
.package(url: "https://github.com/YourOrg/runanywhere-binaries.git", from: "1.0.0")
```

```groovy
// Android - Just add Gradle dependency
implementation 'com.runanywhere:backend-onnx:1.0.0'
```

```yaml
# Flutter - Just add pub dependency
dependencies:
  runanywhere_onnx: ^1.0.0
```

---

## Checklist for Initial Setup

- [ ] Create `runanywhere-binaries` public repo
- [ ] Set up GitHub Actions in `runanywhere-core` for automated builds
- [ ] Create GPG key for Maven Central signing
- [ ] Register on Sonatype for Maven Central access
- [ ] Create pub.dev publisher account
- [ ] Set up repository secrets:
  - `BINARY_REPO_PAT` - Token to push to binaries repo
  - `MAVEN_USERNAME` / `MAVEN_PASSWORD`
  - `GPG_PRIVATE_KEY` / `GPG_PASSPHRASE`
  - `PUB_DEV_CREDENTIALS`
- [ ] Create initial `Package.swift` with placeholder checksums
- [ ] Create initial podspec files
- [ ] Test full release flow with v0.0.1-test tag
