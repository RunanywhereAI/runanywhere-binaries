# Flutter FFI Integration - Core Changes Plan

## Executive Summary

This plan outlines the **minimal changes** required to runanywhere-core to support Flutter FFI integration. Flutter's Dart FFI can directly call C functions from shared libraries, making it simpler than JNI integration. The existing C API (`runanywhere_bridge.h`) is already FFI-compatible, requiring only:

1. Export macros for cross-platform shared library visibility
2. New build scripts for macOS (.dylib) and Linux (.so)
3. CMake updates to enable shared library builds for Flutter platforms
4. No API changes needed - existing C API is perfect for FFI

**Key Principle**: Reuse existing Android/iOS infrastructure. Flutter can consume the same C API with minimal platform-specific adjustments.

---

## Current Architecture Analysis

### Existing C API (Production-Ready)

**Main Header**: `/src/bridge/runanywhere_bridge.h`
- 60+ functions covering all capabilities (STT, TTS, LLM, VAD, embeddings, diarization)
- Clean C interface with opaque handles (`ra_backend_handle`, `ra_stream_handle`)
- JSON for configuration/results, avoiding complex struct marshalling
- Memory management: `ra_free_string()`, `ra_free_audio()`, `ra_free_embedding()`
- Callback support: `ra_text_stream_callback`, `ra_tts_stream_callback`, etc.
- Error handling: `ra_result_code` enum + `ra_get_last_error()`

**Types Header**: `/src/capabilities/types.h`
- Shared types: `ra_result_code`, `ra_device_type`, `ra_capability_type`
- Audio types: `ra_audio_format`, `ra_audio_config`
- Callback typedefs for streaming
- All types are POD (Plain Old Data) - perfect for FFI

### Current Platform Support

**iOS** (XCFramework):
- Built via: `/scripts/ios/build.sh`
- Output: `dist/RunAnywhereCore.xcframework`
- Headers: `ra_core.h` (umbrella), `ra_types.h`, `ra_onnx_bridge.h`, `ra_llamacpp_bridge.h`
- Static library (.a) with all symbols embedded
- Includes: ONNX Runtime, LlamaCPP, Sherpa-ONNX

**Android** (Shared Libraries):
- Built via: `/scripts/android/build.sh`
- Output: `dist/android/{jni,onnx,llamacpp}/*.so` per ABI
- JNI layer: `/src/bridge/jni/runanywhere_jni.cpp` (thin wrapper around C API)
- Loader library: `/src/bridge/jni/runanywhere_loader.cpp` (solves RTLD_GLOBAL issue)
- Distribution structure:
  ```
  dist/android/
  ├── jni/{ABI}/librunanywhere_jni.so + librunanywhere_bridge.so
  ├── onnx/{ABI}/librunanywhere_onnx.so + libonnxruntime.so + libsherpa-onnx-*.so
  └── llamacpp/{ABI}/librunanywhere_llamacpp.so + libomp.so + libc++_shared.so
  ```

**Current CMake Configuration**:
- Option: `RA_BUILD_SHARED` (OFF by default) - enables shared library builds
- Platform detection: iOS, Android, macOS, Linux
- Backend toggles: `RA_BUILD_ONNX`, `RA_BUILD_LLAMACPP`, `RA_BUILD_COREML`, `RA_BUILD_TFLITE`
- Position-independent code enabled globally
- C++17 standard

---

## Required Core Changes

### 1. C API Export Macros

**Problem**: Current headers lack explicit export macros for shared library visibility.

**Solution**: Add platform-specific export macros to make symbols visible across platforms.

**File to modify**: `/src/bridge/runanywhere_bridge.h`

**Changes**:
```c
// Add at top of file (after includes, before extern "C")
#ifndef RA_API
  #if defined(_WIN32) || defined(__CYGWIN__)
    #ifdef RA_BUILD_SHARED
      #define RA_API __declspec(dllexport)
    #else
      #define RA_API __declspec(dllimport)
    #endif
  #elif defined(__GNUC__) && __GNUC__ >= 4
    #define RA_API __attribute__((visibility("default")))
  #else
    #define RA_API
  #endif
#endif

// Then prefix ALL public functions, e.g.:
RA_API const char** ra_get_available_backends(int* count);
RA_API ra_backend_handle ra_create_backend(const char* backend_name);
// ... etc for all 60+ functions
```

**Impact**:
- iOS: No effect (static library)
- Android: No effect (already uses -fvisibility=default in scripts)
- macOS/Linux: Ensures symbol visibility in .dylib/.so for Flutter
- Windows: Future-proofing for Windows Flutter support

**Alternative (Minimal)**: If we control compilation flags, we can skip macros and rely on `-fvisibility=default` in CMake. However, macros are cleaner and more portable.

### 2. CMake Updates for Flutter Platforms

**Problem**: Need shared library builds for macOS and Linux (not currently configured).

**Solution**: Update CMakeLists.txt to support Flutter-specific builds.

**File to modify**: `/CMakeLists.txt`

**Changes**:

```cmake
# Add new option
option(RA_BUILD_FLUTTER "Build for Flutter FFI (shared library)" OFF)

# When building for Flutter, force shared library
if(RA_BUILD_FLUTTER)
    set(RA_BUILD_SHARED ON CACHE BOOL "Force shared library for Flutter" FORCE)
    message(STATUS "Flutter build mode: Shared library enabled")
endif()

# Platform-specific shared library settings (add after line 136)
if(RA_BUILD_SHARED)
    # Set visibility flags
    if(NOT WIN32)
        target_compile_options(runanywhere_bridge PRIVATE -fvisibility=default)
    endif()

    # Set SONAME/install_name for runtime linking
    if(APPLE AND NOT IOS)
        set_target_properties(runanywhere_bridge PROPERTIES
            INSTALL_NAME_DIR "@rpath"
            BUILD_WITH_INSTALL_RPATH TRUE
        )
    elseif(UNIX AND NOT ANDROID)
        set_target_properties(runanywhere_bridge PROPERTIES
            INSTALL_RPATH "$ORIGIN"
            BUILD_WITH_INSTALL_RPATH TRUE
        )
    endif()
endif()
```

**Impact**: Enables `./scripts/flutter/build-macos.sh` and `build-linux.sh` to work correctly.

### 3. Build Scripts for Flutter Platforms

#### New Script: `/scripts/flutter/build-macos.sh`

Creates `.dylib` for macOS (x86_64 + arm64 universal binary).

```bash
#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build/flutter-macos"
DIST_DIR="${ROOT_DIR}/dist/flutter/macos"

echo "Building RunAnywhere for Flutter (macOS)..."

# Clean
rm -rf "${BUILD_DIR}" "${DIST_DIR}"
mkdir -p "${BUILD_DIR}" "${DIST_DIR}"

# Build for arm64
cmake -B "${BUILD_DIR}/arm64" \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_BUILD_TYPE=Release \
    -DRA_BUILD_FLUTTER=ON \
    -DRA_BUILD_ONNX=ON \
    -DRA_BUILD_LLAMACPP=OFF \
    "${ROOT_DIR}"
cmake --build "${BUILD_DIR}/arm64" --config Release -j$(sysctl -n hw.ncpu)

# Build for x86_64
cmake -B "${BUILD_DIR}/x86_64" \
    -DCMAKE_OSX_ARCHITECTURES=x86_64 \
    -DCMAKE_BUILD_TYPE=Release \
    -DRA_BUILD_FLUTTER=ON \
    -DRA_BUILD_ONNX=ON \
    -DRA_BUILD_LLAMACPP=OFF \
    "${ROOT_DIR}"
cmake --build "${BUILD_DIR}/x86_64" --config Release -j$(sysctl -n hw.ncpu)

# Create universal binary
lipo -create \
    "${BUILD_DIR}/arm64/librunanywhere_bridge.dylib" \
    "${BUILD_DIR}/x86_64/librunanywhere_bridge.dylib" \
    -output "${DIST_DIR}/librunanywhere_bridge.dylib"

# Copy headers
mkdir -p "${DIST_DIR}/include"
cp "${ROOT_DIR}/src/bridge/runanywhere_bridge.h" "${DIST_DIR}/include/"
cp "${ROOT_DIR}/src/capabilities/types.h" "${DIST_DIR}/include/"

echo "macOS build complete: ${DIST_DIR}"
echo "  Library: librunanywhere_bridge.dylib ($(du -sh ${DIST_DIR}/librunanywhere_bridge.dylib | cut -f1))"
```

**Output**:
```
dist/flutter/macos/
├── librunanywhere_bridge.dylib (universal: arm64 + x86_64)
└── include/
    ├── runanywhere_bridge.h
    └── types.h
```

#### New Script: `/scripts/flutter/build-linux.sh`

Creates `.so` for Linux (x86_64, arm64 optional).

```bash
#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build/flutter-linux"
DIST_DIR="${ROOT_DIR}/dist/flutter/linux"

echo "Building RunAnywhere for Flutter (Linux)..."

# Detect architecture
ARCH=$(uname -m)

# Clean
rm -rf "${BUILD_DIR}" "${DIST_DIR}"
mkdir -p "${BUILD_DIR}" "${DIST_DIR}"

# Build
cmake -B "${BUILD_DIR}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DRA_BUILD_FLUTTER=ON \
    -DRA_BUILD_ONNX=ON \
    -DRA_BUILD_LLAMACPP=OFF \
    "${ROOT_DIR}"
cmake --build "${BUILD_DIR}" --config Release -j$(nproc)

# Copy library
cp "${BUILD_DIR}/librunanywhere_bridge.so" "${DIST_DIR}/"

# Copy headers
mkdir -p "${DIST_DIR}/include"
cp "${ROOT_DIR}/src/bridge/runanywhere_bridge.h" "${DIST_DIR}/include/"
cp "${ROOT_DIR}/src/capabilities/types.h" "${DIST_DIR}/include/"

echo "Linux build complete: ${DIST_DIR}"
echo "  Library: librunanywhere_bridge.so ($(du -sh ${DIST_DIR}/librunanywhere_bridge.so | cut -f1))"
```

**Output**:
```
dist/flutter/linux/
├── librunanywhere_bridge.so (x86_64 or arm64)
└── include/
    ├── runanywhere_bridge.h
    └── types.h
```

#### Reuse Android Build: `/scripts/android/build.sh`

**No changes needed!** Flutter Android can use the existing Android build output:
```
dist/android/jni/{arm64-v8a,armeabi-v7a,x86_64,x86}/
├── librunanywhere_jni.so      # Skip this (Flutter doesn't need JNI)
├── librunanywhere_bridge.so   # ✓ Use this
└── include/
    ├── runanywhere_bridge.h   # ✓ Use this
    └── types.h                # ✓ Use this
```

Flutter can load `librunanywhere_bridge.so` directly without JNI wrapper.

#### Reuse iOS Build: `/scripts/ios/build.sh`

**No changes needed!** Flutter iOS can reference the existing XCFramework:
```
dist/RunAnywhereCore.xcframework/
├── ios-arm64/libRunAnywhereCore.a
├── ios-arm64_x86_64-simulator/libRunAnywhereCore.a
└── Headers/RunAnywhereCore/
    ├── ra_core.h
    ├── ra_types.h
    ├── ra_onnx_bridge.h
    └── ra_llamacpp_bridge.h
```

Flutter iOS links statically against the XCFramework.

### 4. Directory Structure Creation

**New directory**: `/scripts/flutter/`

Contains:
- `build-macos.sh` - macOS universal dylib builder
- `build-linux.sh` - Linux shared library builder
- `build-all.sh` - Convenience script to build all Flutter platforms
- `README.md` - Documentation for Flutter SDK developers

---

## Build Output Structure for Flutter

### Expected Directory Layout

```
dist/
├── flutter/
│   ├── macos/
│   │   ├── librunanywhere_bridge.dylib (universal: arm64+x86_64)
│   │   └── include/
│   │       ├── runanywhere_bridge.h
│   │       └── types.h
│   ├── linux/
│   │   ├── librunanywhere_bridge.so (x86_64)
│   │   └── include/
│   │       ├── runanywhere_bridge.h
│   │       └── types.h
│   ├── android/  -> symlink to ../android/jni/
│   └── ios/      -> symlink to ../RunAnywhereCore.xcframework/
├── android/
│   └── jni/
│       ├── arm64-v8a/
│       │   ├── librunanywhere_bridge.so
│       │   └── librunanywhere_jni.so (not needed by Flutter)
│       └── include/
│           ├── runanywhere_bridge.h
│           └── types.h
└── RunAnywhereCore.xcframework/
    ├── ios-arm64/libRunAnywhereCore.a
    ├── ios-arm64_x86_64-simulator/libRunAnywhereCore.a
    └── Headers/RunAnywhereCore/
        ├── ra_core.h
        ├── ra_types.h
        ├── ra_onnx_bridge.h
        └── ra_llamacpp_bridge.h
```

### Platform-Specific Notes

**macOS**:
- Universal binary (arm64 + x86_64) for M1/M2/Intel compatibility
- Dynamic library with `@rpath` for Flutter plugin bundling
- Size: ~50-80MB (includes ONNX Runtime)

**Linux**:
- Single architecture per build (x86_64 most common)
- Shared library with `$ORIGIN` rpath for relative loading
- Size: ~50-80MB (includes ONNX Runtime)

**Android**:
- Reuses existing build - Flutter loads `.so` directly (no JNI needed)
- Multi-ABI support: arm64-v8a, armeabi-v7a, x86_64, x86
- Size per ABI: ~20-30MB

**iOS**:
- Reuses existing XCFramework
- Static linking into Flutter app bundle
- Size: ~40-60MB (fat binary)

---

## API Surface for Flutter FFI

Flutter Dart FFI will call the C API directly. Below is the grouped API surface with notes on FFI compatibility.

### Backend Lifecycle (6 functions)

```c
RA_API const char** ra_get_available_backends(int* count);
RA_API ra_backend_handle ra_create_backend(const char* backend_name);
RA_API ra_result_code ra_initialize(ra_backend_handle handle, const char* config_json);
RA_API bool ra_is_initialized(ra_backend_handle handle);
RA_API void ra_destroy(ra_backend_handle handle);
RA_API char* ra_get_backend_info(ra_backend_handle handle);  // Free with ra_free_string
```

**FFI Notes**:
- `ra_backend_handle` → Dart `Pointer<Void>`
- Return `char*` → Dart `Pointer<Utf8>`, convert with `toDartString()`, then free with `ra_free_string()`
- Arrays (`const char**`) → Dart `Pointer<Pointer<Utf8>>`

### Capability Query (3 functions)

```c
RA_API bool ra_supports_capability(ra_backend_handle handle, ra_capability_type capability);
RA_API int ra_get_capabilities(ra_backend_handle handle, ra_capability_type* capabilities, int max_count);
RA_API ra_device_type ra_get_device(ra_backend_handle handle);
```

### Speech-to-Text (STT) - Batch (5 functions)

```c
RA_API ra_result_code ra_stt_load_model(ra_backend_handle handle, const char* model_path,
                                         const char* model_type, const char* config_json);
RA_API bool ra_stt_is_model_loaded(ra_backend_handle handle);
RA_API ra_result_code ra_stt_unload_model(ra_backend_handle handle);
RA_API ra_result_code ra_stt_transcribe(ra_backend_handle handle, const float* audio_samples,
                                         size_t num_samples, int sample_rate, const char* language,
                                         char** result_json);
RA_API void ra_stt_cancel(ra_backend_handle handle);
```

**FFI Notes**:
- `const float* audio_samples` → Dart `Pointer<Float>` (use `Float32List.asPointer()`)
- `char** result_json` → Dart `Pointer<Pointer<Utf8>>` (allocate with `malloc`, read, then free)

### Speech-to-Text (STT) - Streaming (7 functions)

```c
RA_API bool ra_stt_supports_streaming(ra_backend_handle handle);
RA_API ra_stream_handle ra_stt_create_stream(ra_backend_handle handle, const char* config_json);
RA_API ra_result_code ra_stt_feed_audio(ra_backend_handle handle, ra_stream_handle stream,
                                         const float* samples, size_t num_samples, int sample_rate);
RA_API bool ra_stt_is_ready(ra_backend_handle handle, ra_stream_handle stream);
RA_API ra_result_code ra_stt_decode(ra_backend_handle handle, ra_stream_handle stream, char** result_json);
RA_API bool ra_stt_is_endpoint(ra_backend_handle handle, ra_stream_handle stream);
RA_API void ra_stt_destroy_stream(ra_backend_handle handle, ra_stream_handle stream);
```

**FFI Notes**:
- `ra_stream_handle` → Dart `Pointer<Void>`
- Streaming pattern: create → feed → decode (poll) → destroy

### Text-to-Speech (TTS) - Batch (5 functions)

```c
RA_API ra_result_code ra_tts_load_model(ra_backend_handle handle, const char* model_path,
                                         const char* model_type, const char* config_json);
RA_API bool ra_tts_is_model_loaded(ra_backend_handle handle);
RA_API ra_result_code ra_tts_unload_model(ra_backend_handle handle);
RA_API ra_result_code ra_tts_synthesize(ra_backend_handle handle, const char* text, const char* voice_id,
                                         float speed_rate, float pitch_shift, float** audio_samples,
                                         size_t* num_samples, int* sample_rate);
RA_API void ra_free_audio(float* audio_samples);
```

**FFI Notes**:
- `float** audio_samples` → Dart `Pointer<Pointer<Float>>` (allocate, read, free with `ra_free_audio`)
- `size_t* num_samples` → Dart `Pointer<Uint64>` or `Pointer<IntPtr>` depending on platform

### Text-to-Speech (TTS) - Streaming (3 functions)

```c
RA_API bool ra_tts_supports_streaming(ra_backend_handle handle);
RA_API ra_result_code ra_tts_synthesize_stream(ra_backend_handle handle, const char* text,
                                                const char* voice_id, float speed_rate, float pitch_shift,
                                                ra_tts_stream_callback callback, void* user_data);
RA_API void ra_tts_cancel(ra_backend_handle handle);
```

**FFI Notes**:
- `ra_tts_stream_callback` → Dart `Pointer<NativeFunction<...>>`
- Callback signature: `typedef bool (*ra_tts_stream_callback)(const float* samples, size_t num_samples, bool is_final, void* user_data);`
- Use `Pointer.fromFunction<NativeCallback>()` to pass Dart function to C
- **CRITICAL**: Callback must be a top-level or static Dart function (not a closure)

### Text Generation (LLM) - Batch (4 functions)

```c
RA_API ra_result_code ra_text_load_model(ra_backend_handle handle, const char* model_path, const char* config_json);
RA_API bool ra_text_is_model_loaded(ra_backend_handle handle);
RA_API ra_result_code ra_text_generate(ra_backend_handle handle, const char* prompt, const char* system_prompt,
                                        int max_tokens, float temperature, char** result_json);
RA_API void ra_text_cancel(ra_backend_handle handle);
```

### Text Generation (LLM) - Streaming (1 function)

```c
RA_API ra_result_code ra_text_generate_stream(ra_backend_handle handle, const char* prompt,
                                               const char* system_prompt, int max_tokens, float temperature,
                                               ra_text_stream_callback callback, void* user_data);
```

**FFI Notes**:
- `ra_text_stream_callback` → Dart `Pointer<NativeFunction<Bool Function(Pointer<Utf8>, Pointer<Void>)>>`
- Callback signature: `typedef bool (*ra_text_stream_callback)(const char* token, void* user_data);`

### Embeddings (4 functions)

```c
RA_API ra_result_code ra_embed_load_model(ra_backend_handle handle, const char* model_path, const char* config_json);
RA_API ra_result_code ra_embed_text(ra_backend_handle handle, const char* text, float** embedding, int* dimensions);
RA_API int ra_embed_get_dimensions(ra_backend_handle handle);
RA_API void ra_free_embedding(float* embedding);
```

**FFI Notes**:
- `float** embedding` → Dart `Pointer<Pointer<Float>>` (allocate, read as `Float32List`, free with `ra_free_embedding`)

### Voice Activity Detection (VAD) - Batch (4 functions)

```c
RA_API ra_result_code ra_vad_load_model(ra_backend_handle handle, const char* model_path, const char* config_json);
RA_API bool ra_vad_is_model_loaded(ra_backend_handle handle);
RA_API ra_result_code ra_vad_process(ra_backend_handle handle, const float* samples, size_t num_samples,
                                      int sample_rate, bool* is_speech, float* probability);
RA_API void ra_vad_reset(ra_backend_handle handle);
```

### Voice Activity Detection (VAD) - Streaming (2 functions)

```c
RA_API ra_stream_handle ra_vad_create_stream(ra_backend_handle handle, const char* config_json);
RA_API ra_result_code ra_vad_feed_stream(ra_backend_handle handle, ra_stream_handle stream,
                                          const float* samples, size_t num_samples, int sample_rate,
                                          bool* is_speech, float* probability);
```

### Speaker Diarization (3 functions)

```c
RA_API ra_result_code ra_diarize_load_model(ra_backend_handle handle, const char* model_path, const char* config_json);
RA_API ra_result_code ra_diarize(ra_backend_handle handle, const float* samples, size_t num_samples,
                                  int sample_rate, int min_speakers, int max_speakers, char** result_json);
RA_API void ra_diarize_cancel(ra_backend_handle handle);
```

### Memory Management (3 functions)

```c
RA_API void ra_free_string(char* str);
RA_API void ra_free_audio(float* audio_samples);
RA_API void ra_free_embedding(float* embedding);
```

**FFI Critical**:
- All `char*` returned from C must be freed with `ra_free_string()`
- All `float*` audio must be freed with `ra_free_audio()`
- All `float*` embeddings must be freed with `ra_free_embedding()`
- Dart's `malloc.free()` will NOT work - must use C's allocator

### Utility (3 functions)

```c
RA_API const char* ra_get_last_error(void);
RA_API const char* ra_get_version(void);
RA_API ra_result_code ra_extract_archive(const char* archive_path, const char* dest_dir);
```

### Callback Function Signatures for FFI

Flutter must define these callbacks with exact C signatures:

```dart
// Text generation streaming
typedef TextStreamCallback = Bool Function(Pointer<Utf8> token, Pointer<Void> userData);

// TTS streaming
typedef TtsStreamCallback = Bool Function(Pointer<Float> samples, IntPtr numSamples, Bool isFinal, Pointer<Void> userData);

// STT streaming (if added later)
typedef SttStreamCallback = Bool Function(Pointer<Utf8> text, Bool isFinal, Pointer<Void> userData);

// VAD streaming (if added later)
typedef VadStreamCallback = Void Function(Bool isSpeech, Float probability, Double timestampMs, Pointer<Void> userData);
```

**Flutter FFI Callback Requirements**:
1. Callbacks must be **top-level functions** or **static methods** (not closures)
2. Use `Pointer.fromFunction<NativeCallback>(dartFunction, exceptionalReturn)`
3. Pass `Pointer<Void>` as `user_data` to maintain Dart state
4. Free C-allocated memory via C functions, not Dart's `malloc.free()`

---

## Implementation Steps

### Step 1: Add Export Macros to C Headers
**Duration**: 30 minutes
**Files**: `src/bridge/runanywhere_bridge.h`

1. Add `RA_API` macro definition at top of header
2. Prefix all 60+ function declarations with `RA_API`
3. Verify compilation on macOS/Linux with `-fvisibility=hidden` flag
4. Test symbol visibility: `nm -gU librunanywhere_bridge.dylib | grep "^T _ra_"`

**Deliverable**: Updated header with export macros, backward-compatible with existing builds.

### Step 2: Update CMakeLists.txt for Flutter Support
**Duration**: 45 minutes
**Files**: `CMakeLists.txt`

1. Add `RA_BUILD_FLUTTER` option
2. Add conditional visibility flags for shared library builds
3. Add platform-specific install_name/rpath settings for macOS/Linux
4. Test local build: `cmake -DRA_BUILD_FLUTTER=ON -DRA_BUILD_ONNX=ON && make`

**Deliverable**: CMake builds shared library with proper linkage for Flutter.

### Step 3: Create macOS Build Script
**Duration**: 1 hour
**Files**: `scripts/flutter/build-macos.sh`

1. Create script following structure above
2. Build arm64 and x86_64 separately
3. Combine with `lipo` into universal binary
4. Copy headers to distribution directory
5. Test on both Intel and Apple Silicon Macs
6. Verify with: `file dist/flutter/macos/librunanywhere_bridge.dylib`
   - Should show: "Mach-O 64-bit dynamically linked shared library arm64" and x86_64

**Deliverable**: Functional macOS build script producing universal `.dylib`

### Step 4: Create Linux Build Script
**Duration**: 45 minutes
**Files**: `scripts/flutter/build-linux.sh`

1. Create script following structure above
2. Build for host architecture (x86_64 or arm64)
3. Copy headers to distribution directory
4. Test on Linux VM or CI
5. Verify symbols: `nm -gD dist/flutter/linux/librunanywhere_bridge.so | grep " T ra_"`

**Deliverable**: Functional Linux build script producing `.so`

### Step 5: Create Flutter Build Documentation
**Duration**: 30 minutes
**Files**: `scripts/flutter/README.md`

1. Document prerequisites (CMake, NDK for Android, Xcode for iOS/macOS)
2. Usage instructions for each platform
3. Output directory structure explanation
4. Troubleshooting section (common errors)
5. Integration guide for Flutter SDK developers

**Deliverable**: Comprehensive build documentation for Flutter SDK team.

### Step 6: Create Convenience Build Script
**Duration**: 15 minutes
**Files**: `scripts/flutter/build-all.sh`

```bash
#!/bin/bash
# Build for all Flutter platforms

cd "$(dirname "$0")"

echo "Building for all Flutter platforms..."

# macOS (if on macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    ./build-macos.sh
fi

# Linux (if on Linux)
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    ./build-linux.sh
fi

# Android (reuse existing)
../android/build.sh

# iOS (reuse existing)
../ios/build.sh

echo "All platforms built! See dist/flutter/ and dist/android/"
```

**Deliverable**: One-command build for all supported platforms.

### Step 7: Update Root CMakeLists.txt Build Options
**Duration**: 15 minutes
**Files**: `CMakeLists.txt` (configuration summary section)

1. Add Flutter build mode to summary output
2. Document `RA_BUILD_FLUTTER` option in comments

**Deliverable**: Clear build configuration feedback for developers.

### Step 8: Test End-to-End Integration
**Duration**: 2 hours
**Prerequisites**: Flutter SDK installed

1. Build all platforms: `./scripts/flutter/build-all.sh`
2. Create minimal Dart FFI test app:
   ```dart
   // test_ffi.dart
   import 'dart:ffi';
   import 'package:ffi/ffi.dart';

   typedef CreateBackendNative = Pointer<Void> Function(Pointer<Utf8>);
   typedef CreateBackendDart = Pointer<Void> Function(Pointer<Utf8>);

   void main() {
     final lib = DynamicLibrary.open('dist/flutter/macos/librunanywhere_bridge.dylib');
     final createBackend = lib.lookupFunction<CreateBackendNative, CreateBackendDart>('ra_create_backend');

     final backendName = 'onnx'.toNativeUtf8();
     final handle = createBackend(backendName);
     malloc.free(backendName);

     print('Backend handle: $handle');
   }
   ```
3. Run on macOS: `dart test_ffi.dart`
4. Verify no crashes, handle is non-null
5. Test symbol lookup for all major functions

**Deliverable**: Verified FFI compatibility on at least one platform.

---

## Testing Strategy

### Unit Testing (C++ Level)
**No changes needed** - existing test suite covers C API functionality.

### FFI Compatibility Testing

#### Test 1: Symbol Visibility
**Platform**: macOS, Linux, Android
**Command**: `nm -gD <library> | grep " T ra_"`
**Expected**: All 60+ `ra_*` functions are visible (exported)

#### Test 2: Header Standalone Compilation
**Platform**: All
**Command**:
```bash
gcc -c -x c -include runanywhere_bridge.h -o /dev/null /dev/null
clang -c -x c -include runanywhere_bridge.h -o /dev/null /dev/null
```
**Expected**: No compilation errors, headers are self-contained

#### Test 3: Basic FFI Binding
**Platform**: macOS (easiest to test)
**Tool**: Dart FFI test script
**Test cases**:
1. Load library: `DynamicLibrary.open()`
2. Lookup function: `lib.lookupFunction('ra_create_backend')`
3. Call function: `createBackend('onnx'.toNativeUtf8())`
4. Verify non-null handle returned
5. Call `ra_destroy(handle)`

**Expected**: No crashes, correct return values

#### Test 4: Memory Management
**Platform**: macOS
**Test cases**:
1. Call `ra_get_backend_info(handle)` → returns `char*`
2. Convert to Dart string: `result.toDartString()`
3. Free: `raFreeString(result)`
4. Repeat 100 times, check for memory leaks (Instruments on macOS)

**Expected**: No memory leaks, stable memory usage

#### Test 5: Callback Invocation
**Platform**: macOS
**Test case**:
1. Define Dart callback: `bool onToken(Pointer<Utf8> token, Pointer<Void> userData) { ... }`
2. Convert to native: `Pointer.fromFunction<TextStreamCallback>(onToken, false)`
3. Call `ra_text_generate_stream()` with callback
4. Verify callback is invoked, receives token strings
5. Return `false` from callback to test cancellation

**Expected**: Callbacks work correctly, cancellation works

#### Test 6: Streaming API
**Platform**: macOS
**Test case**:
1. Create STT stream: `ra_stt_create_stream()`
2. Feed audio chunks: `ra_stt_feed_audio()` in loop
3. Poll for results: `ra_stt_decode()` when `ra_stt_is_ready()` returns true
4. Destroy stream: `ra_stt_destroy_stream()`

**Expected**: Streaming state machine works correctly

### Integration Testing (with Flutter SDK)
**Responsibility**: Flutter SDK team
**Strategy**: Once core changes land, Flutter SDK wraps C API with Dart layer

### Cross-Platform Testing Matrix

| Platform | Library Format | Architecture | Test Command |
|----------|---------------|--------------|--------------|
| macOS    | .dylib        | arm64+x86_64 | `dart test_ffi.dart` |
| Linux    | .so           | x86_64       | `dart test_ffi.dart` |
| Android  | .so           | arm64-v8a    | Flutter Android app |
| iOS      | .a (static)   | arm64        | Flutter iOS app |

### Continuous Integration
**Add to CI pipeline**:
1. Build Flutter libraries for all platforms
2. Run symbol visibility tests
3. Run basic FFI binding tests (Dart script)
4. Archive build artifacts to GitHub Releases

---

## Risk Mitigation

### Risk 1: Symbol Visibility Issues
**Likelihood**: Medium
**Impact**: High (Flutter can't find functions)
**Mitigation**:
- Add export macros early in implementation
- Test symbol visibility on each platform immediately after build
- Use `-fvisibility=default` as fallback if macros fail

### Risk 2: Callback ABI Mismatch
**Likelihood**: Low
**Impact**: High (crashes)
**Mitigation**:
- Use standard C calling conventions (`extern "C"`)
- Test callbacks thoroughly on macOS first
- Document callback requirements clearly in FFI guide

### Risk 3: Memory Leaks in FFI Boundary
**Likelihood**: Medium
**Impact**: Medium (performance degradation)
**Mitigation**:
- Provide clear memory management examples in docs
- Test with Valgrind (Linux) and Instruments (macOS)
- Create helper functions in Flutter SDK to auto-free C strings

### Risk 4: Platform-Specific Build Failures
**Likelihood**: Medium
**Impact**: Medium (blocks Flutter support on that platform)
**Mitigation**:
- Start with macOS (most controlled environment)
- Test on Linux early (different toolchain)
- Reuse proven Android/iOS builds
- Document platform-specific prerequisites clearly

### Risk 5: Breaking Existing Builds
**Likelihood**: Low
**Impact**: High
**Mitigation**:
- Export macros are additive (no effect on static builds)
- `RA_BUILD_FLUTTER` is opt-in (default OFF)
- CMake changes are conditional
- Test existing build scripts after changes

---

## Dependencies

### External Dependencies (Required)
- **CMake** 3.22+ (already required)
- **ONNX Runtime**: Already downloaded via `scripts/download-onnx-ios.sh` (iOS) and `scripts/android/download-onnx.sh` (Android)
- **Android NDK** (for Android builds only)
- **Xcode** (for macOS/iOS builds only)

### Build Tools
- `lipo` (macOS only - for universal binaries)
- `nm` (for symbol inspection)
- `file` (for binary verification)

### No New Third-Party Libraries
All FFI-required functionality already exists in the C API. No new dependencies needed.

---

## Success Criteria

### Phase 1: Core Changes (This Plan)
- [ ] Export macros added to `runanywhere_bridge.h`
- [ ] CMake supports `RA_BUILD_FLUTTER=ON`
- [ ] macOS build script produces universal `.dylib`
- [ ] Linux build script produces `.so`
- [ ] All symbols exported correctly (`nm` verification)
- [ ] Headers are standalone-compilable
- [ ] Existing Android/iOS builds still work

### Phase 2: FFI Testing (Follow-up)
- [ ] Basic Dart FFI test app loads library successfully
- [ ] Can create/destroy backend
- [ ] Can call at least one function from each capability group
- [ ] Memory management works (no leaks)
- [ ] Callbacks work correctly
- [ ] Documentation complete

### Phase 3: Flutter SDK Integration (Flutter Team)
- [ ] Flutter package wraps C API with Dart layer
- [ ] Platform channels handle model loading
- [ ] Example app demonstrates STT/TTS/LLM
- [ ] Published to pub.dev

---

## Timeline Estimate

| Step | Duration | Dependencies |
|------|----------|--------------|
| 1. Export macros | 30 min | None |
| 2. CMake updates | 45 min | Step 1 |
| 3. macOS script | 1 hour | Step 2 |
| 4. Linux script | 45 min | Step 2 |
| 5. Documentation | 30 min | Steps 3-4 |
| 6. Convenience script | 15 min | Steps 3-4 |
| 7. CMake summary | 15 min | Step 2 |
| 8. End-to-end test | 2 hours | Steps 1-6 |

**Total Core Implementation**: ~6 hours of focused development

**Testing & Validation**: 2-4 hours (depends on platform access)

**Total**: **1-2 days** for complete Flutter FFI support in runanywhere-core

---

## Next Steps After Core Changes

1. **Flutter SDK Development** (separate repo/package):
   - Create Dart FFI bindings generator (using `package:ffigen`)
   - Wrap C API with idiomatic Dart interfaces
   - Add Flutter platform channels for file/asset management
   - Create example apps for each platform

2. **CI/CD Integration**:
   - Add Flutter build jobs to GitHub Actions
   - Publish build artifacts to GitHub Releases
   - Automate version bumping

3. **Documentation**:
   - Create Flutter integration guide in main repo
   - Add troubleshooting section for FFI issues
   - Document platform-specific quirks

4. **Performance Optimization**:
   - Profile FFI call overhead
   - Optimize audio buffer passing (shared memory?)
   - Benchmark against native Kotlin/Swift SDKs

---

## Appendix: Dart FFI Code Examples

### Example 1: Basic Library Loading

```dart
import 'dart:ffi';
import 'dart:io';
import 'package:ffi/ffi.dart';

// Load platform-specific library
DynamicLibrary loadRunAnywhereLibrary() {
  if (Platform.isAndroid) {
    return DynamicLibrary.open('librunanywhere_bridge.so');
  } else if (Platform.isIOS) {
    return DynamicLibrary.process(); // Static linking
  } else if (Platform.isMacOS) {
    return DynamicLibrary.open('librunanywhere_bridge.dylib');
  } else if (Platform.isLinux) {
    return DynamicLibrary.open('librunanywhere_bridge.so');
  }
  throw UnsupportedError('Platform not supported');
}

void main() {
  final lib = loadRunAnywhereLibrary();
  print('Library loaded successfully');
}
```

### Example 2: Backend Lifecycle

```dart
// Native function signatures
typedef CreateBackendNative = Pointer<Void> Function(Pointer<Utf8>);
typedef CreateBackendDart = Pointer<Void> Function(Pointer<Utf8>);

typedef InitializeNative = Int32 Function(Pointer<Void>, Pointer<Utf8>);
typedef InitializeDart = int Function(Pointer<Void>, Pointer<Utf8>);

typedef DestroyNative = Void Function(Pointer<Void>);
typedef DestroyDart = void Function(Pointer<Void>);

class RunAnywhereBackend {
  final DynamicLibrary _lib;
  late final Pointer<Void> _handle;

  late final CreateBackendDart _createBackend;
  late final InitializeDart _initialize;
  late final DestroyDart _destroy;

  RunAnywhereBackend(this._lib) {
    _createBackend = _lib.lookupFunction<CreateBackendNative, CreateBackendDart>('ra_create_backend');
    _initialize = _lib.lookupFunction<InitializeNative, InitializeDart>('ra_initialize');
    _destroy = _lib.lookupFunction<DestroyNative, DestroyDart>('ra_destroy');
  }

  void create(String backendName) {
    final name = backendName.toNativeUtf8();
    _handle = _createBackend(name);
    malloc.free(name);

    if (_handle == nullptr) {
      throw Exception('Failed to create backend: $backendName');
    }
  }

  void initialize([String? configJson]) {
    final config = configJson?.toNativeUtf8() ?? nullptr;
    final result = _initialize(_handle, config);
    if (configJson != null) malloc.free(config);

    if (result != 0) { // RA_SUCCESS = 0
      throw Exception('Initialization failed: error code $result');
    }
  }

  void dispose() {
    if (_handle != nullptr) {
      _destroy(_handle);
      _handle = nullptr;
    }
  }
}
```

### Example 3: Memory Management with Auto-Free

```dart
typedef GetBackendInfoNative = Pointer<Utf8> Function(Pointer<Void>);
typedef GetBackendInfoDart = Pointer<Utf8> Function(Pointer<Void>);

typedef FreeStringNative = Void Function(Pointer<Utf8>);
typedef FreeStringDart = void Function(Pointer<Utf8>);

extension RunAnywhereBackendInfo on RunAnywhereBackend {
  late final GetBackendInfoDart _getBackendInfo =
    _lib.lookupFunction<GetBackendInfoNative, GetBackendInfoDart>('ra_get_backend_info');
  late final FreeStringDart _freeString =
    _lib.lookupFunction<FreeStringNative, FreeStringDart>('ra_free_string');

  String getBackendInfo() {
    final cStr = _getBackendInfo(_handle);
    if (cStr == nullptr) return '{}';

    final dartStr = cStr.toDartString();
    _freeString(cStr); // CRITICAL: Free C-allocated memory
    return dartStr;
  }
}
```

### Example 4: Audio Processing (STT)

```dart
import 'dart:typed_data';

typedef SttTranscribeNative = Int32 Function(
  Pointer<Void>, // handle
  Pointer<Float>, // audio_samples
  IntPtr, // num_samples
  Int32, // sample_rate
  Pointer<Utf8>, // language
  Pointer<Pointer<Utf8>> // result_json
);

typedef SttTranscribeDart = int Function(
  Pointer<Void>,
  Pointer<Float>,
  int,
  int,
  Pointer<Utf8>,
  Pointer<Pointer<Utf8>>
);

extension RunAnywhereSTT on RunAnywhereBackend {
  late final SttTranscribeDart _sttTranscribe =
    _lib.lookupFunction<SttTranscribeNative, SttTranscribeDart>('ra_stt_transcribe');

  String transcribe(Float32List audioSamples, int sampleRate, {String? language}) {
    // Allocate native array
    final nativeSamples = malloc<Float>(audioSamples.length);
    final nativeList = nativeSamples.asTypedList(audioSamples.length);
    nativeList.setAll(0, audioSamples);

    // Prepare language
    final lang = language?.toNativeUtf8() ?? nullptr;

    // Prepare output pointer
    final resultPtr = malloc<Pointer<Utf8>>();

    try {
      final result = _sttTranscribe(
        _handle,
        nativeSamples,
        audioSamples.length,
        sampleRate,
        lang,
        resultPtr
      );

      if (result != 0) {
        throw Exception('Transcription failed: $result');
      }

      final resultJson = resultPtr.value.toDartString();
      _freeString(resultPtr.value);
      return resultJson;

    } finally {
      malloc.free(nativeSamples);
      if (lang != nullptr) malloc.free(lang);
      malloc.free(resultPtr);
    }
  }
}
```

### Example 5: Streaming Callback

```dart
typedef TextStreamCallbackNative = Bool Function(Pointer<Utf8>, Pointer<Void>);

typedef TextGenerateStreamNative = Int32 Function(
  Pointer<Void>, // handle
  Pointer<Utf8>, // prompt
  Pointer<Utf8>, // system_prompt
  Int32, // max_tokens
  Float, // temperature
  Pointer<NativeFunction<TextStreamCallbackNative>>, // callback
  Pointer<Void> // user_data
);

typedef TextGenerateStreamDart = int Function(
  Pointer<Void>,
  Pointer<Utf8>,
  Pointer<Utf8>,
  int,
  double,
  Pointer<NativeFunction<TextStreamCallbackNative>>,
  Pointer<Void>
);

// Top-level callback function (required by FFI)
bool _onToken(Pointer<Utf8> token, Pointer<Void> userData) {
  final callback = userData.cast<StreamCallbackData>().ref;
  final dartToken = token.toDartString();
  callback.onToken(dartToken);
  return !callback.cancelled; // Return false to cancel
}

class StreamCallbackData extends Struct {
  external Pointer<Void> dartObject;
  @Bool()
  external bool cancelled;

  void onToken(String token) {
    // Forward to Dart callback (via dartObject pointer)
  }
}

extension RunAnywhereLLM on RunAnywhereBackend {
  late final TextGenerateStreamDart _textGenerateStream =
    _lib.lookupFunction<TextGenerateStreamNative, TextGenerateStreamDart>('ra_text_generate_stream');

  void generateStream(
    String prompt,
    {String? systemPrompt,
    int maxTokens = 512,
    double temperature = 0.7,
    required void Function(String) onToken}
  ) {
    final nativeCallback = Pointer.fromFunction<TextStreamCallbackNative>(_onToken, false);
    final callbackData = malloc<StreamCallbackData>();
    // ... setup callbackData ...

    final promptPtr = prompt.toNativeUtf8();
    final sysPromptPtr = systemPrompt?.toNativeUtf8() ?? nullptr;

    try {
      final result = _textGenerateStream(
        _handle,
        promptPtr,
        sysPromptPtr,
        maxTokens,
        temperature,
        nativeCallback,
        callbackData.cast<Void>()
      );

      if (result != 0) {
        throw Exception('Text generation failed: $result');
      }
    } finally {
      malloc.free(promptPtr);
      if (sysPromptPtr != nullptr) malloc.free(sysPromptPtr);
      malloc.free(callbackData);
    }
  }
}
```

---

## References

### Internal Documentation
- `runanywhere-core/CLAUDE.md` - Core library architecture
- `runanywhere-core/src/bridge/runanywhere_bridge.h` - C API reference
- `runanywhere-core/src/capabilities/types.h` - Type definitions
- `sdks/CLAUDE.md` - SDK architecture (for context on how SDKs use core)

### External Resources
- [Dart FFI Documentation](https://dart.dev/guides/libraries/c-interop)
- [Flutter FFI Best Practices](https://docs.flutter.dev/development/platform-integration/c-interop)
- [ONNX Runtime C API](https://onnxruntime.ai/docs/api/c/)
- [CMake Shared Library Guide](https://cmake.org/cmake/help/latest/guide/tutorial/Adding%20a%20Library.html)
