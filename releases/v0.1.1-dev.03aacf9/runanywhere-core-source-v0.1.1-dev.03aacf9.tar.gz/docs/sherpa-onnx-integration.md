# Sherpa-ONNX Integration Plan for RunAnywhere STT

## Overview

This document outlines the changes required to integrate sherpa-onnx library into the RunAnywhere ONNX backend to support speech recognition (STT) models like Whisper, Zipformer, and Paraformer.

## Current State

The current ONNX backend uses basic ONNX Runtime which:
- Loads single `.onnx` model files via `OrtCreateSession()`
- Works for simple models with encoder/decoder structure
- Cannot handle sherpa-onnx models that have complex multi-file structures (encoder, decoder, tokenizer, config files)
- Located at: `src/backends/onnx/backend/onnx_backend.cpp`

## Why Sherpa-ONNX is Needed

Sherpa-ONNX provides:
1. **Speech-specific model handling**: Encoder, decoder, tokenizer coordination
2. **Streaming support**: Real-time transcription with chunked audio processing
3. **Model archive support**: Handles `.tar.bz2` archives with multiple model files
4. **Pre-built models**: Access to optimized speech models (Whisper, Zipformer, Paraformer)
5. **Platform optimization**: Mobile-friendly models (20MB-250MB range)

## Required Changes

### 1. Add Sherpa-ONNX Library Dependency

**Location**: `runanywhere-core/third_party/`

**Steps**:
```bash
cd runanywhere-core/third_party
git clone https://github.com/k2-fsa/sherpa-onnx.git
cd sherpa-onnx
mkdir build && cd build
cmake ..
make
```

**Files to add**:
- `third_party/sherpa-onnx/` - Source code
- `third_party/sherpa-onnx/build/lib/libsherpa-onnx-core.a` - Static library
- `third_party/sherpa-onnx/sherpa-onnx/csrc/` - C++ headers

**CMakeLists.txt update**:
```cmake
# Add sherpa-onnx library
add_subdirectory(third_party/sherpa-onnx)
target_link_libraries(runanywhere_onnx PRIVATE sherpa-onnx-core)
```

### 2. Create Sherpa-ONNX STT Service

**New file**: `src/backends/onnx/services/sherpa_onnx_stt_service.h`

```cpp
#pragma once
#include <string>
#include <vector>
#include <memory>
#include "sherpa-onnx/csrc/offline-recognizer.h"
#include "sherpa-onnx/csrc/online-recognizer.h"

namespace runanywhere {
namespace onnx {

class SherpaONNXSTTService {
public:
    SherpaONNXSTTService();
    ~SherpaONNXSTTService();

    // Initialize with model directory path
    bool initialize(const std::string& model_dir);

    // Streaming recognition
    bool start_stream();
    void accept_waveform(const float* samples, int32_t num_samples);
    std::string get_partial_result();
    std::string get_final_result();
    void stop_stream();

    // Batch recognition
    std::string transcribe(const float* samples, int32_t num_samples);

private:
    std::unique_ptr<sherpa_onnx::OnlineRecognizer> online_recognizer_;
    std::unique_ptr<sherpa_onnx::OfflineRecognizer> offline_recognizer_;
    std::unique_ptr<sherpa_onnx::OnlineStream> stream_;
    bool is_streaming_ = false;
};

} // namespace onnx
} // namespace runanywhere
```

**Implementation**: `src/backends/onnx/services/sherpa_onnx_stt_service.cpp`

```cpp
#include "sherpa_onnx_stt_service.h"
#include <fstream>
#include <nlohmann/json.hpp>

namespace runanywhere {
namespace onnx {

bool SherpaONNXSTTService::initialize(const std::string& model_dir) {
    // Load model config
    std::string config_path = model_dir + "/config.json";
    std::ifstream config_file(config_path);
    if (!config_file.is_open()) {
        return false;
    }

    nlohmann::json config;
    config_file >> config;

    // Create recognizer config
    sherpa_onnx::OnlineRecognizerConfig recognizer_config;

    // Set model paths
    recognizer_config.model_config.transducer.encoder =
        model_dir + "/encoder.onnx";
    recognizer_config.model_config.transducer.decoder =
        model_dir + "/decoder.onnx";
    recognizer_config.model_config.transducer.joiner =
        model_dir + "/joiner.onnx";
    recognizer_config.model_config.tokens =
        model_dir + "/tokens.txt";

    // Configure for mobile
    recognizer_config.model_config.num_threads = 2;
    recognizer_config.model_config.provider = "cpu";
    recognizer_config.enable_endpoint_detection = true;

    // Create recognizer
    online_recognizer_ = std::make_unique<sherpa_onnx::OnlineRecognizer>(
        recognizer_config
    );

    return online_recognizer_ != nullptr;
}

bool SherpaONNXSTTService::start_stream() {
    if (!online_recognizer_) {
        return false;
    }

    stream_ = online_recognizer_->CreateStream();
    is_streaming_ = true;
    return true;
}

void SherpaONNXSTTService::accept_waveform(
    const float* samples,
    int32_t num_samples
) {
    if (stream_) {
        stream_->AcceptWaveform(16000, samples, num_samples);
    }
}

std::string SherpaONNXSTTService::get_partial_result() {
    if (!stream_) {
        return "";
    }

    while (online_recognizer_->IsReady(stream_.get())) {
        online_recognizer_->DecodeStream(stream_.get());
    }

    return online_recognizer_->GetResult(stream_.get()).text;
}

std::string SherpaONNXSTTService::get_final_result() {
    if (!stream_) {
        return "";
    }

    // Process remaining audio
    stream_->InputFinished();
    while (online_recognizer_->IsReady(stream_.get())) {
        online_recognizer_->DecodeStream(stream_.get());
    }

    auto result = online_recognizer_->GetResult(stream_.get());
    return result.text;
}

void SherpaONNXSTTService::stop_stream() {
    stream_.reset();
    is_streaming_ = false;
}

} // namespace onnx
} // namespace runanywhere
```

### 3. Update ONNX Backend to Support Multi-File Models

**File**: `src/backends/onnx/backend/onnx_backend.h`

Add new method:
```cpp
bool load_speech_model(const std::string& model_dir);
```

**File**: `src/backends/onnx/backend/onnx_backend.cpp`

```cpp
bool ONNXBackend::load_speech_model(const std::string& model_dir) {
    if (!initialized_) {
        return false;
    }

    // Check if this is a sherpa-onnx model directory
    std::string config_path = model_dir + "/config.json";
    std::ifstream config_file(config_path);
    if (!config_file.is_open()) {
        // Not a sherpa-onnx model, fall back to single file loading
        return load_model(model_dir);
    }

    // Initialize sherpa-onnx service
    if (!sherpa_stt_service_) {
        sherpa_stt_service_ = std::make_unique<SherpaONNXSTTService>();
    }

    return sherpa_stt_service_->initialize(model_dir);
}
```

### 4. Add Model Archive Extraction Support

**New file**: `src/backends/onnx/utils/archive_extractor.h`

```cpp
#pragma once
#include <string>

namespace runanywhere {
namespace onnx {
namespace utils {

class ArchiveExtractor {
public:
    // Extract .tar.bz2 archive to destination directory
    static bool extract_tar_bz2(
        const std::string& archive_path,
        const std::string& dest_dir
    );

    // Extract .tar.gz archive
    static bool extract_tar_gz(
        const std::string& archive_path,
        const std::string& dest_dir
    );

    // Auto-detect and extract
    static bool extract(
        const std::string& archive_path,
        const std::string& dest_dir
    );
};

} // namespace utils
} // namespace onnx
} // namespace runanywhere
```

**Dependencies needed**:
- `libbz2` for .tar.bz2 extraction
- `zlib` for .tar.gz extraction

### 5. Update C Bridge for Swift Integration

**File**: `src/backends/onnx/bridge/onnx_bridge.h`

Add new C functions:
```c
// Load speech model from directory
RA_ONNX_EXPORT int ra_onnx_load_speech_model(
    OnnxHandle handle,
    const char* model_dir
);

// Start streaming recognition
RA_ONNX_EXPORT int ra_onnx_stt_start_stream(OnnxHandle handle);

// Feed audio chunk (16kHz, float32 samples)
RA_ONNX_EXPORT int ra_onnx_stt_accept_waveform(
    OnnxHandle handle,
    const float* samples,
    int num_samples
);

// Get partial transcription result
RA_ONNX_EXPORT const char* ra_onnx_stt_get_partial_result(OnnxHandle handle);

// Get final transcription result
RA_ONNX_EXPORT const char* ra_onnx_stt_get_final_result(OnnxHandle handle);

// Stop streaming
RA_ONNX_EXPORT void ra_onnx_stt_stop_stream(OnnxHandle handle);

// Extract model archive
RA_ONNX_EXPORT int ra_onnx_extract_archive(
    const char* archive_path,
    const char* dest_dir
);
```

**Implementation**: `src/backends/onnx/bridge/onnx_bridge.cpp`

```cpp
int ra_onnx_load_speech_model(OnnxHandle handle, const char* model_dir) {
    auto backend = static_cast<ONNXBackend*>(handle);
    return backend->load_speech_model(model_dir) ? 0 : -1;
}

int ra_onnx_stt_start_stream(OnnxHandle handle) {
    auto backend = static_cast<ONNXBackend*>(handle);
    return backend->get_sherpa_service()->start_stream() ? 0 : -1;
}

int ra_onnx_stt_accept_waveform(
    OnnxHandle handle,
    const float* samples,
    int num_samples
) {
    auto backend = static_cast<ONNXBackend*>(handle);
    backend->get_sherpa_service()->accept_waveform(samples, num_samples);
    return 0;
}

const char* ra_onnx_stt_get_partial_result(OnnxHandle handle) {
    auto backend = static_cast<ONNXBackend*>(handle);
    static std::string result;
    result = backend->get_sherpa_service()->get_partial_result();
    return result.c_str();
}

const char* ra_onnx_stt_get_final_result(OnnxHandle handle) {
    auto backend = static_cast<ONNXBackend*>(handle);
    static std::string result;
    result = backend->get_sherpa_service()->get_final_result();
    return result.c_str();
}

void ra_onnx_stt_stop_stream(OnnxHandle handle) {
    auto backend = static_cast<ONNXBackend*>(handle);
    backend->get_sherpa_service()->stop_stream();
}

int ra_onnx_extract_archive(const char* archive_path, const char* dest_dir) {
    return utils::ArchiveExtractor::extract(archive_path, dest_dir) ? 0 : -1;
}
```

### 6. Update Swift ONNX Service

**File**: `sdks/sdk/runanywhere-swift/Modules/ONNXRuntime/Sources/ONNXRuntime/ONNXSTTService.swift`

Add streaming methods:
```swift
func streamTranscribe(_ audioStream: AsyncStream<Data>, language: String) -> AsyncStream<String> {
    return AsyncStream { continuation in
        Task {
            // Start sherpa-onnx streaming
            let status = ra_onnx_stt_start_stream(handle)
            guard status == 0 else {
                continuation.finish()
                return
            }

            // Process audio chunks
            for await audioChunk in audioStream {
                // Convert Data to float32 array (assuming 16-bit PCM input)
                let samples = audioChunk.withUnsafeBytes { buffer in
                    buffer.bindMemory(to: Int16.self).map { Float($0) / 32768.0 }
                }

                // Feed to sherpa-onnx
                samples.withUnsafeBufferPointer { buffer in
                    ra_onnx_stt_accept_waveform(handle, buffer.baseAddress, Int32(buffer.count))
                }

                // Get partial result
                if let result = ra_onnx_stt_get_partial_result(handle) {
                    let text = String(cString: result)
                    if !text.isEmpty {
                        continuation.yield(text)
                    }
                }
            }

            // Get final result
            if let finalResult = ra_onnx_stt_get_final_result(handle) {
                let text = String(cString: finalResult)
                if !text.isEmpty {
                    continuation.yield(text)
                }
            }

            ra_onnx_stt_stop_stream(handle)
            continuation.finish()
        }
    }
}
```

### 7. Add Model Download and Extraction in Swift

**File**: `sdks/sdk/runanywhere-swift/Modules/ONNXRuntime/Sources/ONNXRuntime/ONNXServiceProvider.swift`

Update initialization to handle archives:
```swift
public func createSTTService(configuration: STTConfiguration) async throws -> STTService {
    Self.logger.info("Creating ONNX Runtime STT service for model: \(configuration.modelId ?? "unknown")")

    var modelPath: String? = nil
    if let modelId = configuration.modelId {
        let allModels = try await RunAnywhere.availableModels()
        let modelInfo = allModels.first { $0.id == modelId }

        if let localPath = modelInfo?.localPath {
            // Check if it's an archive that needs extraction
            if localPath.pathExtension == "bz2" || localPath.pathExtension == "gz" {
                // Extract to cache directory
                let cacheDir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
                let extractDir = cacheDir.appendingPathComponent("onnx_models/\(modelId)")

                // Extract if not already extracted
                if !FileManager.default.fileExists(atPath: extractDir.path) {
                    try FileManager.default.createDirectory(at: extractDir, withIntermediateDirectories: true)

                    // Call C bridge to extract
                    let status = ra_onnx_extract_archive(localPath.path, extractDir.path)
                    guard status == 0 else {
                        throw SDKError.modelLoadFailed("Failed to extract model archive")
                    }
                }

                modelPath = extractDir.path
            } else {
                modelPath = localPath.path
            }

            Self.logger.info("Found local model path: \(modelPath ?? "nil")")
        } else {
            Self.logger.error("Model '\(modelId)' is not downloaded. Please download the model first.")
            throw SDKError.modelNotFound("Model '\(modelId)' is not downloaded.")
        }
    }

    let service = ONNXSTTService()
    try await service.initialize(modelPath: modelPath)
    return service
}
```

## Recommended Sherpa-ONNX Models for Mobile

### Small Models (< 50MB)
1. **Zipformer English 20M** (20MB)
   - URL: `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17.tar.bz2`
   - Streaming: Yes
   - Language: English
   - Best for: Real-time transcription on mobile

### Medium Models (50-150MB)
2. **Whisper Tiny** (75MB)
   - URL: `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-tiny.en.tar.bz2`
   - Streaming: No (batch processing)
   - Language: English
   - Best for: High accuracy, non-real-time

### Larger Models (150-300MB)
3. **Whisper Small** (250MB)
   - URL: `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-small.en.tar.bz2`
   - Streaming: No
   - Language: English
   - Best for: Best accuracy, powerful devices

## Build System Changes

### CMakeLists.txt
```cmake
# Add sherpa-onnx dependency
find_package(sherpa-onnx REQUIRED)

# Add archive extraction libraries
find_package(BZip2 REQUIRED)
find_package(ZLIB REQUIRED)

# Update ONNX backend target
target_sources(runanywhere_onnx PRIVATE
    src/backends/onnx/services/sherpa_onnx_stt_service.cpp
    src/backends/onnx/utils/archive_extractor.cpp
)

target_link_libraries(runanywhere_onnx PRIVATE
    sherpa-onnx-core
    BZip2::BZip2
    ZLIB::ZLIB
)
```

### iOS Build Script
Update `scripts/build-ios-onnx.sh` to include sherpa-onnx:
```bash
# Build sherpa-onnx for iOS
pushd third_party/sherpa-onnx
mkdir -p build-ios
cd build-ios
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE=../toolchains/ios.cmake \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=OFF
make -j$(sysctl -n hw.ncpu)
popd

# Link sherpa-onnx in final XCFramework
libtool -static -o librunanywhere_onnx_combined.a \
    build/ios/lib/librunanywhere_onnx.a \
    third_party/onnxruntime-ios/lib/libonnxruntime.a \
    third_party/sherpa-onnx/build-ios/lib/libsherpa-onnx-core.a \
    /usr/lib/libbz2.a \
    /usr/lib/libz.a
```

## Testing Plan

1. **Unit Tests**
   - Test archive extraction
   - Test sherpa-onnx initialization
   - Test streaming recognition
   - Test batch recognition

2. **Integration Tests**
   - Download Zipformer 20M model
   - Extract and load model
   - Test real-time streaming from microphone
   - Verify transcription accuracy

3. **Performance Tests**
   - Measure memory usage
   - Measure inference latency
   - Test on different iOS devices (iPhone 12+, iPad)

## Timeline Estimate

- **Week 1**: Add sherpa-onnx dependency, build integration
- **Week 2**: Implement C++ service layer and C bridge
- **Week 3**: Update Swift integration, add archive extraction
- **Week 4**: Testing, optimization, documentation

## References

- Sherpa-ONNX: https://github.com/k2-fsa/sherpa-onnx
- Documentation: https://k2-fsa.github.io/sherpa/onnx/
- Pre-trained Models: https://github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models
- ONNX Runtime: https://onnxruntime.ai/
