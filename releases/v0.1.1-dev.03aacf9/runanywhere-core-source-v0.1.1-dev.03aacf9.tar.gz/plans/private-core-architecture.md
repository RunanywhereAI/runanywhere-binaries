# RunAnywhere Private Core Architecture
## Layers 1-3: Implementation Guide

**Version:** 1.0
**Last Updated:** 2025-11-09
**Purpose:** Implementation blueprint for private binary layers

---

## Table of Contents

1. [Overview](#overview)
2. [Repository Structure](#repository-structure)
3. [Layer 1: Backend Adapters](#layer-1-backend-adapters)
4. [Layer 2: RunAnywhere Core](#layer-2-runanywhere-core)
5. [Layer 3: Native Bridges](#layer-3-native-bridges)
6. [Build System](#build-system)
7. [Binary Packaging](#binary-packaging)
8. [Distribution Infrastructure](#distribution-infrastructure)
9. [Versioning & Release](#versioning-release)
10. [Consumption by Public SDKs](#consumption-by-public-sdks)

---

## Overview

### What We're Building

Three private layers that form the proprietary core of RunAnywhere:

```
┌────────────────────────────────────────────────────┐
│ Layer 3: Native Bridges                            │
│ - Swift → C bridge (Objective-C++)                 │
│ - Kotlin → JNI bridge                              │
│ - Dart → FFI bridge                                │
│ OUTPUT: Part of platform XCFramework/AAR          │
└────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────┐
│ Layer 2: RunAnywhere Core (C++)                    │
│ - Policy Engine (routing logic)                    │
│ - Model Lifecycle                                  │
│ - Configuration Management                         │
│ - Telemetry                                        │
│ - OTA Updates                                      │
│ OUTPUT: librunanywhere_core.a / .so               │
└────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────┐
│ Layer 1: Backend Adapters (C++)                    │
│ - llamacpp_backend.cpp                             │
│ - coreml_backend.cpp                               │
│ - tflite_backend.cpp                               │
│ - onnx_backend.cpp                                 │
│ OUTPUT: libra_backend_*.a / .so per backend       │
└────────────────────────────────────────────────────┘
```

### What Gets Shipped

**iOS:**
```
RunAnywhereCore.xcframework (contains Layers 2+3 + llama.cpp)
RunAnywhereCoreML.xcframework (optional, Layer 1 adapter)
RunAnywhereTFLite.xcframework (optional, Layer 1 adapter)
```

**Android:**
```
com.runanywhere:core:1.0.0 (AAR with Layers 2+3 + llama.cpp)
com.runanywhere:backend-coreml:1.0.0 (optional adapter)
com.runanywhere:backend-tflite:1.0.0 (optional adapter)
```

---

## Repository Structure

### Private Repository Layout

```
runanywhere-core/                    # Private repo
├── CMakeLists.txt                   # Root build config
├── cmake/
│   ├── iOS.cmake                    # iOS-specific settings
│   ├── Android.cmake                # Android-specific settings
│   ├── Codesigning.cmake            # Binary signing
│   └── Packaging.cmake              # XCFramework/AAR creation
│
├── include/                         # Public C API headers
│   └── runanywhere/
│       ├── runanywhere.h            # Main API (SHIPPED in binaries)
│       ├── types.h                  # Common types
│       └── version.h                # Version macros
│
├── src/
│   ├── core/                        # Layer 2: Core engine
│   │   ├── runtime.cpp
│   │   ├── policy_engine.cpp
│   │   ├── device_detector.cpp
│   │   ├── config_parser.cpp
│   │   ├── model_manager.cpp
│   │   ├── telemetry.cpp
│   │   └── ota_manager.cpp
│   │
│   ├── backends/                    # Layer 1: Backend adapters
│   │   ├── backend_interface.cpp
│   │   ├── llamacpp/
│   │   │   ├── llamacpp_backend.cpp
│   │   │   └── llamacpp_backend.h
│   │   ├── coreml/
│   │   │   ├── coreml_backend.mm    # Objective-C++
│   │   │   └── coreml_backend.h
│   │   ├── tflite/
│   │   │   ├── tflite_backend.cpp
│   │   │   └── tflite_backend.h
│   │   └── onnx/
│   │       ├── onnx_backend.cpp
│   │       └── onnx_backend.h
│   │
│   └── bridges/                     # Layer 3: Language bridges
│       ├── swift/
│       │   ├── ra_bridge.cpp        # C bridge for Swift
│       │   └── ra_bridge.h
│       ├── jni/
│       │   ├── ra_jni.cpp           # JNI for Android
│       │   └── ra_jni.h
│       └── dart/
│           ├── ra_ffi.cpp           # C for Dart FFI
│           └── ra_ffi.h
│
├── third_party/                     # Vendored dependencies
│   ├── llama.cpp/                   # Git submodule
│   ├── onnxruntime/                 # Downloaded in CMake
│   ├── tensorflow-lite/             # Downloaded in CMake
│   └── json/                        # nlohmann/json (header-only)
│
├── scripts/
│   ├── build-ios.sh                 # Build all iOS artifacts
│   ├── build-android.sh             # Build all Android artifacts
│   ├── sign-binaries.sh             # Code signing
│   ├── upload-artifacts.sh          # Upload to CDN
│   └── generate-checksums.sh        # SHA256 checksums
│
├── ci/
│   ├── build-binaries.yml           # GitHub Actions for builds
│   ├── release.yml                  # Release automation
│   └── test.yml                     # Binary smoke tests
│
└── docs/
    ├── build-instructions.md
    ├── release-process.md
    └── architecture.md
```

---

## Layer 1: Backend Adapters

### Backend Interface (Abstract Base)

```cpp
// src/backends/backend_interface.h
#pragma once

#include <string>
#include <vector>
#include <memory>
#include <functional>

namespace runanywhere {

// Forward declarations
struct DeviceCapabilities;
struct InferenceRequest;
struct InferenceResult;

enum class BackendType {
    LLAMA_CPP,
    CORE_ML,
    TFLITE,
    ONNX_RUNTIME,
    MLX
};

enum class DeviceType {
    CPU,
    GPU,
    NPU,
    ANE,
    DSP
};

// Abstract interface that ALL backends must implement
class BackendInterface {
public:
    virtual ~BackendInterface() = default;

    // Identification
    virtual BackendType get_type() const = 0;
    virtual std::string get_name() const = 0;
    virtual std::string get_version() const = 0;

    // Capability checks
    virtual bool is_available(const DeviceCapabilities& caps) const = 0;
    virtual DeviceType get_device_type() const = 0;
    virtual bool supports_quantization(const std::string& quant_type) const = 0;
    virtual bool supports_streaming() const = 0;

    // Model lifecycle
    virtual bool load_model(const std::string& path, const std::string& config) = 0;
    virtual bool unload_model() = 0;
    virtual bool is_loaded() const = 0;

    // Inference
    virtual InferenceResult infer(const InferenceRequest& request) = 0;
    virtual void infer_stream(
        const InferenceRequest& request,
        std::function<void(const std::string& token)> callback
    ) = 0;

    // Resource management
    virtual size_t get_memory_usage_bytes() const = 0;
    virtual void set_memory_budget_bytes(size_t budget) = 0;

    // Performance hints
    virtual void set_num_threads(int threads) = 0;
    virtual void warm_up() = 0;
};

// Factory for creating backends
class BackendFactory {
public:
    static std::unique_ptr<BackendInterface> create(
        BackendType type,
        const DeviceCapabilities& caps
    );

    static std::vector<BackendType> available_backends(
        const DeviceCapabilities& caps
    );
};

} // namespace runanywhere
```

### Example: llama.cpp Backend Adapter

```cpp
// src/backends/llamacpp/llamacpp_backend.cpp
#include "llamacpp_backend.h"
#include "llama.h"  // From third_party/llama.cpp

namespace runanywhere {

class LlamaCppBackend : public BackendInterface {
private:
    llama_model* model_ = nullptr;
    llama_context* ctx_ = nullptr;
    llama_model_params model_params_;
    llama_context_params ctx_params_;

    bool loaded_ = false;
    size_t memory_budget_ = 0;

public:
    LlamaCppBackend() {
        // Initialize default params
        model_params_ = llama_model_default_params();
        ctx_params_ = llama_context_default_params();

        // Sensible defaults
        ctx_params_.n_ctx = 2048;
        ctx_params_.n_batch = 512;
        ctx_params_.n_threads = 4;
    }

    ~LlamaCppBackend() override {
        unload_model();
    }

    // === Identification ===

    BackendType get_type() const override {
        return BackendType::LLAMA_CPP;
    }

    std::string get_name() const override {
        return "llama.cpp";
    }

    std::string get_version() const override {
        return LLAMA_BUILD_NUMBER;
    }

    // === Capability checks ===

    bool is_available(const DeviceCapabilities& caps) const override {
        // llama.cpp always available (CPU fallback)
        return true;
    }

    DeviceType get_device_type() const override {
        // Detect at runtime
#ifdef __APPLE__
        if (ctx_params_.n_gpu_layers > 0) {
            return DeviceType::GPU;  // Metal
        }
#endif
        return DeviceType::CPU;
    }

    bool supports_quantization(const std::string& quant_type) const override {
        // llama.cpp supports many quant types
        static const std::vector<std::string> supported = {
            "Q4_0", "Q4_1", "Q4_K_S", "Q4_K_M",
            "Q5_0", "Q5_1", "Q5_K_S", "Q5_K_M",
            "Q8_0", "F16", "F32"
        };
        return std::find(supported.begin(), supported.end(), quant_type) != supported.end();
    }

    bool supports_streaming() const override {
        return true;
    }

    // === Model lifecycle ===

    bool load_model(const std::string& path, const std::string& config) override {
        if (loaded_) {
            unload_model();
        }

        // Parse config JSON (use nlohmann/json)
        // ... parse n_ctx, n_threads, n_gpu_layers from config

        // Initialize backend
        llama_backend_init();

        // Load model
        model_ = llama_load_model_from_file(path.c_str(), model_params_);
        if (!model_) {
            return false;
        }

        // Create context
        ctx_ = llama_new_context_with_model(model_, ctx_params_);
        if (!ctx_) {
            llama_free_model(model_);
            model_ = nullptr;
            return false;
        }

        loaded_ = true;
        return true;
    }

    bool unload_model() override {
        if (ctx_) {
            llama_free(ctx_);
            ctx_ = nullptr;
        }
        if (model_) {
            llama_free_model(model_);
            model_ = nullptr;
        }
        llama_backend_free();
        loaded_ = false;
        return true;
    }

    bool is_loaded() const override {
        return loaded_;
    }

    // === Inference ===

    InferenceResult infer(const InferenceRequest& request) override {
        if (!loaded_) {
            throw std::runtime_error("Model not loaded");
        }

        // Tokenize input
        std::vector<llama_token> tokens = tokenize(request.prompt);

        // Run inference
        auto start = std::chrono::steady_clock::now();

        // Prefill
        llama_batch batch = llama_batch_get_one(
            tokens.data(),
            tokens.size(),
            0,  // pos
            0   // seq_id
        );

        if (llama_decode(ctx_, batch) != 0) {
            throw std::runtime_error("llama_decode failed");
        }

        // Decode loop
        std::vector<llama_token> generated;
        for (int i = 0; i < request.max_tokens; ++i) {
            // Sample next token
            llama_token next = sample_token();
            if (next == llama_token_eos(model_)) {
                break;
            }
            generated.push_back(next);

            // Single token decode
            batch = llama_batch_get_one(&next, 1, tokens.size() + i, 0);
            if (llama_decode(ctx_, batch) != 0) {
                break;
            }
        }

        auto end = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);

        // Detokenize
        std::string output = detokenize(generated);

        return InferenceResult{
            .output = output,
            .tokens_generated = generated.size(),
            .latency_ms = duration.count()
        };
    }

    void infer_stream(
        const InferenceRequest& request,
        std::function<void(const std::string& token)> callback
    ) override {
        // Similar to infer() but call callback per token
        // ... implementation
    }

    // === Resource management ===

    size_t get_memory_usage_bytes() const override {
        if (!ctx_) return 0;
        // Estimate: model weights + KV cache
        size_t model_size = llama_model_size(model_);
        size_t kv_size = llama_get_state_size(ctx_);
        return model_size + kv_size;
    }

    void set_memory_budget_bytes(size_t budget) override {
        memory_budget_ = budget;
        // Adjust context size if needed
    }

    void set_num_threads(int threads) override {
        ctx_params_.n_threads = threads;
    }

    void warm_up() override {
        // Run dummy inference to compile shaders/kernels
        std::vector<llama_token> dummy = {1, 2, 3};
        llama_batch batch = llama_batch_get_one(dummy.data(), dummy.size(), 0, 0);
        llama_decode(ctx_, batch);
    }

private:
    std::vector<llama_token> tokenize(const std::string& text) {
        // Use llama.cpp tokenizer
        std::vector<llama_token> tokens(text.size() + 16);
        int n = llama_tokenize(
            model_,
            text.c_str(),
            text.size(),
            tokens.data(),
            tokens.size(),
            false,  // add_bos
            true    // special
        );
        tokens.resize(n);
        return tokens;
    }

    std::string detokenize(const std::vector<llama_token>& tokens) {
        std::string result;
        for (auto token : tokens) {
            const char* piece = llama_token_to_piece(model_, token);
            result += piece;
        }
        return result;
    }

    llama_token sample_token() {
        // Simple greedy sampling (can be extended)
        float* logits = llama_get_logits(ctx_);
        int n_vocab = llama_n_vocab(model_);

        llama_token max_token = 0;
        float max_logit = logits[0];
        for (int i = 1; i < n_vocab; ++i) {
            if (logits[i] > max_logit) {
                max_logit = logits[i];
                max_token = i;
            }
        }
        return max_token;
    }
};

// Factory registration
std::unique_ptr<BackendInterface> BackendFactory::create(
    BackendType type,
    const DeviceCapabilities& caps
) {
    switch (type) {
        case BackendType::LLAMA_CPP:
            return std::make_unique<LlamaCppBackend>();
        case BackendType::CORE_ML:
            return std::make_unique<CoreMLBackend>();
        // ... other backends
        default:
            return nullptr;
    }
}

} // namespace runanywhere
```

### CoreML Backend Adapter (iOS/macOS)

```objc
// src/backends/coreml/coreml_backend.mm (Objective-C++)
#include "coreml_backend.h"
#import <CoreML/CoreML.h>
#import <Foundation/Foundation.h>

namespace runanywhere {

class CoreMLBackend : public BackendInterface {
private:
    MLModel* model_ API_AVAILABLE(ios(11.0), macos(10.13));
    bool loaded_ = false;

public:
    BackendType get_type() const override {
        return BackendType::CORE_ML;
    }

    std::string get_name() const override {
        return "CoreML";
    }

    bool is_available(const DeviceCapabilities& caps) const override {
#ifdef __APPLE__
        if (@available(iOS 11.0, macOS 10.13, *)) {
            return caps.has_neural_engine || caps.platform == "iOS" || caps.platform == "macOS";
        }
#endif
        return false;
    }

    DeviceType get_device_type() const override {
        // CoreML automatically chooses ANE/GPU/CPU
        // We can hint which one was likely used
        return DeviceType::ANE;
    }

    bool load_model(const std::string& path, const std::string& config) override {
#ifdef __APPLE__
        if (@available(iOS 11.0, macOS 10.13, *)) {
            @autoreleasepool {
                NSURL* url = [NSURL fileURLWithPath:@(path.c_str())];
                NSError* error = nil;

                MLModelConfiguration* config_obj = [[MLModelConfiguration alloc] init];

                // Parse config to set compute units
                // config_obj.computeUnits = MLComputeUnitsAll;

                model_ = [MLModel modelWithContentsOfURL:url
                                           configuration:config_obj
                                                   error:&error];

                if (error) {
                    NSLog(@"CoreML load error: %@", error);
                    return false;
                }

                loaded_ = (model_ != nil);
                return loaded_;
            }
        }
#endif
        return false;
    }

    bool unload_model() override {
        model_ = nil;
        loaded_ = false;
        return true;
    }

    InferenceResult infer(const InferenceRequest& request) override {
#ifdef __APPLE__
        if (@available(iOS 11.0, macOS 10.13, *)) {
            @autoreleasepool {
                // Convert request to MLFeatureProvider
                // Run prediction
                // Convert output back

                NSError* error = nil;
                id<MLFeatureProvider> input = create_input(request);
                id<MLFeatureProvider> output = [model_ predictionFromFeatures:input
                                                                        error:&error];

                if (error) {
                    throw std::runtime_error([[error description] UTF8String]);
                }

                return extract_result(output);
            }
        }
#endif
        throw std::runtime_error("CoreML not available");
    }

    // ... other methods

private:
    id<MLFeatureProvider> create_input(const InferenceRequest& request) {
        // Convert tokens to CoreML input format
        // This depends on the model's input signature
        return nil;
    }

    InferenceResult extract_result(id<MLFeatureProvider> output) {
        // Extract logits/tokens from CoreML output
        return InferenceResult{};
    }
};

} // namespace runanywhere
```

---

## Layer 2: RunAnywhere Core

### Core Runtime

```cpp
// src/core/runtime.h
#pragma once

#include "runanywhere/runanywhere.h"
#include "policy_engine.h"
#include "model_manager.h"
#include "config_parser.h"
#include "telemetry.h"
#include "ota_manager.h"

#include <memory>
#include <string>

namespace runanywhere {

class Runtime {
private:
    // Core components
    std::unique_ptr<PolicyEngine> policy_engine_;
    std::unique_ptr<ModelManager> model_manager_;
    std::unique_ptr<ConfigParser> config_parser_;
    std::unique_ptr<TelemetryCollector> telemetry_;
    std::unique_ptr<OTAManager> ota_manager_;

    // Current state
    ServerConfig config_;
    DeviceCapabilities device_caps_;
    bool initialized_ = false;

public:
    Runtime();
    ~Runtime();

    // Initialization
    bool initialize(const std::string& config_json);
    void shutdown();

    // Configuration
    bool update_config(const std::string& config_json);
    const ServerConfig& get_config() const { return config_; }

    // Device info
    DeviceCapabilities detect_device_capabilities();
    std::string get_device_info_json() const;

    // Model management
    std::unique_ptr<Model> load_model(const std::string& manifest_json);
    void unload_model(Model* model);

    // Telemetry
    void record_event(const TelemetryEvent& event);
    void flush_telemetry();

private:
    void load_config(const std::string& json);
    void initialize_components();
};

} // namespace runanywhere
```

```cpp
// src/core/runtime.cpp
#include "runtime.h"
#include "device_detector.h"
#include <nlohmann/json.hpp>

namespace runanywhere {

Runtime::Runtime() {
    // Components created on-demand
}

Runtime::~Runtime() {
    shutdown();
}

bool Runtime::initialize(const std::string& config_json) {
    if (initialized_) {
        return true;
    }

    // Detect device capabilities
    DeviceDetector detector;
    device_caps_ = detector.detect();

    // Parse config
    load_config(config_json);

    // Initialize components
    initialize_components();

    initialized_ = true;
    return true;
}

void Runtime::shutdown() {
    if (!initialized_) return;

    // Flush telemetry
    if (telemetry_) {
        telemetry_->flush();
    }

    // Cleanup
    model_manager_.reset();
    policy_engine_.reset();
    telemetry_.reset();
    ota_manager_.reset();

    initialized_ = false;
}

void Runtime::load_config(const std::string& json) {
    if (json.empty()) {
        // Use default config
        config_ = ServerConfig::default_config();
        return;
    }

    try {
        auto parsed = nlohmann::json::parse(json);
        config_ = ServerConfig::from_json(parsed);
    } catch (const std::exception& e) {
        // Log error, use defaults
        config_ = ServerConfig::default_config();
    }
}

void Runtime::initialize_components() {
    // Create policy engine
    policy_engine_ = std::make_unique<PolicyEngine>(device_caps_, config_);

    // Create model manager
    model_manager_ = std::make_unique<ModelManager>(policy_engine_.get());

    // Create telemetry (if enabled)
    if (config_.enable_telemetry) {
        telemetry_ = std::make_unique<TelemetryCollector>(config_);
    }

    // Create OTA manager (if enabled)
    if (config_.enable_ota_updates) {
        ota_manager_ = std::make_unique<OTAManager>(config_);
    }
}

std::unique_ptr<Model> Runtime::load_model(const std::string& manifest_json) {
    if (!initialized_) {
        throw std::runtime_error("Runtime not initialized");
    }

    // Parse manifest
    auto manifest = ModelManifest::from_json(manifest_json);

    // Ask policy engine which backend to use
    BackendType backend = policy_engine_->select_backend(manifest, device_caps_);

    // Load model via model manager
    return model_manager_->load_model(manifest, backend);
}

DeviceCapabilities Runtime::detect_device_capabilities() {
    DeviceDetector detector;
    return detector.detect();
}

std::string Runtime::get_device_info_json() const {
    nlohmann::json j;
    j["platform"] = device_caps_.platform;
    j["soc"] = device_caps_.soc;
    j["ram_mb"] = device_caps_.ram_mb;
    j["cpu_arch"] = device_caps_.cpu_arch;
    j["has_neural_engine"] = device_caps_.has_neural_engine;
    j["has_hexagon_dsp"] = device_caps_.has_hexagon_dsp;
    j["has_metal"] = device_caps_.has_metal;
    j["has_vulkan"] = device_caps_.has_vulkan;
    return j.dump();
}

} // namespace runanywhere
```

### Policy Engine

```cpp
// src/core/policy_engine.h
#pragma once

#include "runanywhere/types.h"
#include "backends/backend_interface.h"
#include <string>

namespace runanywhere {

struct ModelManifest {
    std::string model_id;
    size_t size_mb;
    std::string format;  // "gguf", "coreml", "tflite"
    std::string quantization;
    int min_ram_mb;
    bool requires_npu;

    static ModelManifest from_json(const std::string& json);
};

struct SessionContext {
    int battery_percent;
    float temperature_celsius;
    int64_t available_ram_mb;
    bool has_network;
    float target_p95_latency_ms;
};

class PolicyEngine {
private:
    DeviceCapabilities device_;
    ServerConfig config_;

    // Cached decisions
    std::map<std::string, BackendType> decision_cache_;

public:
    PolicyEngine(const DeviceCapabilities& device, const ServerConfig& config);

    // Primary decision method
    BackendType select_backend(
        const ModelManifest& manifest,
        const DeviceCapabilities& device
    );

    // Adaptive policy (called during inference)
    bool should_throttle(const SessionContext& ctx) const;
    bool should_offload_to_cloud(const SessionContext& ctx) const;

    // Backend availability
    std::vector<BackendType> available_backends() const;

private:
    BackendType apply_policy(const ModelManifest& manifest);
    bool check_server_override(const std::string& model_id, BackendType& out);
    BackendType select_ios_backend(const ModelManifest& manifest);
    BackendType select_android_backend(const ModelManifest& manifest);
};

} // namespace runanywhere
```

```cpp
// src/core/policy_engine.cpp
#include "policy_engine.h"
#include <algorithm>

namespace runanywhere {

PolicyEngine::PolicyEngine(
    const DeviceCapabilities& device,
    const ServerConfig& config
)
    : device_(device)
    , config_(config)
{
}

BackendType PolicyEngine::select_backend(
    const ModelManifest& manifest,
    const DeviceCapabilities& device
) {
    // Check cache first
    auto it = decision_cache_.find(manifest.model_id);
    if (it != decision_cache_.end()) {
        return it->second;
    }

    // Priority 1: Server override (for A/B testing, emergency switches)
    BackendType override_backend;
    if (check_server_override(manifest.model_id, override_backend)) {
        decision_cache_[manifest.model_id] = override_backend;
        return override_backend;
    }

    // Priority 2: Device-specific policy
    BackendType selected = apply_policy(manifest);
    decision_cache_[manifest.model_id] = selected;
    return selected;
}

BackendType PolicyEngine::apply_policy(const ModelManifest& manifest) {
    if (device_.platform == "iOS" || device_.platform == "macOS") {
        return select_ios_backend(manifest);
    } else if (device_.platform == "Android") {
        return select_android_backend(manifest);
    }

    // Default: llama.cpp (universal fallback)
    return BackendType::LLAMA_CPP;
}

BackendType PolicyEngine::select_ios_backend(const ModelManifest& manifest) {
    // iOS with ANE: prefer CoreML for models <4GB
    if (device_.has_neural_engine && manifest.size_mb < 4096) {
        if (manifest.format == "coreml" || manifest.format == "mlpackage") {
            return BackendType::CORE_ML;
        }
    }

    // macOS with Apple Silicon: prefer MLX
    if (device_.platform == "macOS" && device_.cpu_arch == "arm64") {
        if (manifest.format == "gguf") {
            return BackendType::MLX;
        }
    }

    // Metal-capable devices: llama.cpp with Metal
    if (device_.has_metal) {
        return BackendType::LLAMA_CPP;  // Will use Metal backend
    }

    // Fallback: CPU
    return BackendType::LLAMA_CPP;
}

BackendType PolicyEngine::select_android_backend(const ModelManifest& manifest) {
    // Qualcomm devices with good thermals: TFLite + NNAPI
    if (device_.has_hexagon_dsp && device_.soc.find("Snapdragon") != std::string::npos) {
        // Check thermal state from SessionContext in production
        if (manifest.format == "tflite") {
            return BackendType::TFLITE;
        }
    }

    // MediaTek devices: ONNX Runtime with NNAPI
    if (device_.soc.find("Dimensity") != std::string::npos) {
        if (manifest.format == "onnx") {
            return BackendType::ONNX_RUNTIME;
        }
    }

    // Low-end devices: smallest footprint
    if (device_.ram_mb < 3000) {
        return BackendType::LLAMA_CPP;  // CPU only
    }

    // Default: llama.cpp with Vulkan (if available)
    return BackendType::LLAMA_CPP;
}

bool PolicyEngine::check_server_override(
    const std::string& model_id,
    BackendType& out
) {
    // Check if server config has an override for this model
    auto it = config_.backend_overrides.find(model_id);
    if (it != config_.backend_overrides.end()) {
        out = it->second;
        return true;
    }
    return false;
}

bool PolicyEngine::should_throttle(const SessionContext& ctx) const {
    // Thermal throttle
    if (ctx.temperature_celsius > config_.max_thermal_celsius) {
        return true;
    }

    // Battery critical
    if (ctx.battery_percent < config_.min_battery_percent) {
        return true;
    }

    return false;
}

bool PolicyEngine::should_offload_to_cloud(const SessionContext& ctx) const {
    // Low battery + network available
    if (ctx.battery_percent < 10 && ctx.has_network) {
        return true;
    }

    // Device overheating
    if (ctx.temperature_celsius > config_.max_thermal_celsius + 5) {
        return true;
    }

    return false;
}

std::vector<BackendType> PolicyEngine::available_backends() const {
    std::vector<BackendType> available;

    // llama.cpp always available
    available.push_back(BackendType::LLAMA_CPP);

    if (device_.has_neural_engine) {
        available.push_back(BackendType::CORE_ML);
    }

    if (device_.platform == "Android") {
        available.push_back(BackendType::TFLITE);
        available.push_back(BackendType::ONNX_RUNTIME);
    }

    if (device_.platform == "macOS" && device_.cpu_arch == "arm64") {
        available.push_back(BackendType::MLX);
    }

    return available;
}

} // namespace runanywhere
```

### Device Detector

```cpp
// src/core/device_detector.h
#pragma once

#include "runanywhere/types.h"

namespace runanywhere {

class DeviceDetector {
public:
    DeviceCapabilities detect();

private:
    DeviceCapabilities detect_ios();
    DeviceCapabilities detect_android();
    DeviceCapabilities detect_linux();
};

} // namespace runanywhere
```

```cpp
// src/core/device_detector.cpp
#include "device_detector.h"

#ifdef __APPLE__
#include <sys/sysctl.h>
#include <sys/utsname.h>
#import <Foundation/Foundation.h>
#ifdef TARGET_OS_IOS
#import <UIKit/UIKit.h>
#endif
#endif

#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

namespace runanywhere {

DeviceCapabilities DeviceDetector::detect() {
#ifdef __APPLE__
    return detect_ios();
#elif defined(__ANDROID__)
    return detect_android();
#else
    return detect_linux();
#endif
}

#ifdef __APPLE__
DeviceCapabilities DeviceDetector::detect_ios() {
    DeviceCapabilities caps;

    // Platform
#if TARGET_OS_IOS
    caps.platform = "iOS";
#elif TARGET_OS_OSX
    caps.platform = "macOS";
#endif

    // CPU architecture
#if defined(__arm64__)
    caps.cpu_arch = "arm64";
#elif defined(__x86_64__)
    caps.cpu_arch = "x86_64";
#endif

    // SOC (simplified - in production, parse hw.machine)
    size_t size = 256;
    char model[256];
    sysctlbyname("hw.machine", model, &size, nullptr, 0);
    caps.soc = std::string(model);

    // RAM
    int64_t memsize = 0;
    size = sizeof(memsize);
    sysctlbyname("hw.memsize", &memsize, &size, nullptr, 0);
    caps.ram_mb = memsize / (1024 * 1024);

    // CPU cores
    int ncpu = 0;
    size = sizeof(ncpu);
    sysctlbyname("hw.ncpu", &ncpu, &size, nullptr, 0);
    caps.cpu_core_count = ncpu;

    // Neural Engine (heuristic: A11 and later)
    // In production, check MLComputeUnits availability
    caps.has_neural_engine = (caps.soc.find("iPhone") != std::string::npos) &&
                             (caps.soc >= "iPhone10,");  // A11 Bionic

    // Metal
    caps.has_metal = true;  // All modern Apple devices

    caps.has_vulkan = false;
    caps.has_hexagon_dsp = false;

    return caps;
}
#endif

#ifdef __ANDROID__
DeviceCapabilities DeviceDetector::detect_android() {
    DeviceCapabilities caps;
    caps.platform = "Android";

    // Get system properties
    char prop_value[PROP_VALUE_MAX];

    // SOC
    __system_property_get("ro.board.platform", prop_value);
    caps.soc = std::string(prop_value);

    // CPU arch
#if defined(__aarch64__)
    caps.cpu_arch = "arm64";
#elif defined(__arm__)
    caps.cpu_arch = "arm";
#elif defined(__x86_64__)
    caps.cpu_arch = "x86_64";
#endif

    // RAM (from /proc/meminfo)
    FILE* meminfo = fopen("/proc/meminfo", "r");
    if (meminfo) {
        char line[256];
        while (fgets(line, sizeof(line), meminfo)) {
            long kb = 0;
            if (sscanf(line, "MemTotal: %ld kB", &kb) == 1) {
                caps.ram_mb = kb / 1024;
                break;
            }
        }
        fclose(meminfo);
    }

    // CPU cores
    caps.cpu_core_count = sysconf(_SC_NPROCESSORS_ONLN);

    // Hexagon DSP (heuristic: check for Qualcomm SOC)
    caps.has_hexagon_dsp = (caps.soc.find("sm") != std::string::npos) ||  // Snapdragon
                           (caps.soc.find("qcom") != std::string::npos);

    // Vulkan (check at runtime in production)
    caps.has_vulkan = true;  // Most modern Android devices

    caps.has_neural_engine = false;
    caps.has_metal = false;

    return caps;
}
#endif

DeviceCapabilities DeviceDetector::detect_linux() {
    DeviceCapabilities caps;
    caps.platform = "Linux";

    // Read /proc/cpuinfo
    FILE* cpuinfo = fopen("/proc/cpuinfo", "r");
    if (cpuinfo) {
        char line[256];
        while (fgets(line, sizeof(line), cpuinfo)) {
            if (strncmp(line, "processor", 9) == 0) {
                caps.cpu_core_count++;
            }
        }
        fclose(cpuinfo);
    }

    // Detect Jetson (check /proc/device-tree/model)
    FILE* model = fopen("/proc/device-tree/model", "r");
    if (model) {
        char model_str[256];
        if (fgets(model_str, sizeof(model_str), model)) {
            if (strstr(model_str, "Jetson")) {
                caps.soc = "Jetson";
            }
        }
        fclose(model);
    }

    return caps;
}

} // namespace runanywhere
```

---

## Layer 3: Native Bridges

### Swift Bridge (iOS/macOS)

```cpp
// src/bridges/swift/ra_bridge.h
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Opaque handles
typedef void* ra_runtime_handle;
typedef void* ra_model_handle;

// Version
const char* ra_version(void);

// Runtime
ra_runtime_handle ra_init(const char* config_json);
void ra_shutdown(ra_runtime_handle handle);
int ra_update_config(ra_runtime_handle handle, const char* config_json);

// Device info
char* ra_get_device_info(ra_runtime_handle handle);

// Model
ra_model_handle ra_load_model(ra_runtime_handle handle, const char* manifest_json);
void ra_unload_model(ra_model_handle handle);

// Inference
typedef void (*ra_token_callback)(const char* token, void* user_data);

char* ra_infer(
    ra_model_handle handle,
    const char* prompt,
    int max_tokens
);

void ra_infer_stream(
    ra_model_handle handle,
    const char* prompt,
    int max_tokens,
    ra_token_callback callback,
    void* user_data
);

// Introspection
const char* ra_get_backend_name(ra_model_handle handle);
long ra_get_memory_usage(ra_model_handle handle);

// Utility
void ra_free_string(char* str);

#ifdef __cplusplus
}
#endif
```

```cpp
// src/bridges/swift/ra_bridge.cpp
#include "ra_bridge.h"
#include "core/runtime.h"
#include <cstring>

using namespace runanywhere;

extern "C" {

const char* ra_version() {
    return "1.0.0";
}

ra_runtime_handle ra_init(const char* config_json) {
    try {
        auto* runtime = new Runtime();
        std::string config = config_json ? config_json : "";
        if (!runtime->initialize(config)) {
            delete runtime;
            return nullptr;
        }
        return runtime;
    } catch (...) {
        return nullptr;
    }
}

void ra_shutdown(ra_runtime_handle handle) {
    if (handle) {
        auto* runtime = static_cast<Runtime*>(handle);
        runtime->shutdown();
        delete runtime;
    }
}

int ra_update_config(ra_runtime_handle handle, const char* config_json) {
    if (!handle || !config_json) return -1;

    try {
        auto* runtime = static_cast<Runtime*>(handle);
        return runtime->update_config(config_json) ? 0 : -1;
    } catch (...) {
        return -1;
    }
}

char* ra_get_device_info(ra_runtime_handle handle) {
    if (!handle) return nullptr;

    try {
        auto* runtime = static_cast<Runtime*>(handle);
        std::string info = runtime->get_device_info_json();

        char* result = (char*)malloc(info.size() + 1);
        strcpy(result, info.c_str());
        return result;
    } catch (...) {
        return nullptr;
    }
}

ra_model_handle ra_load_model(ra_runtime_handle handle, const char* manifest_json) {
    if (!handle || !manifest_json) return nullptr;

    try {
        auto* runtime = static_cast<Runtime*>(handle);
        auto model = runtime->load_model(manifest_json);
        return model.release();  // Transfer ownership
    } catch (...) {
        return nullptr;
    }
}

void ra_unload_model(ra_model_handle handle) {
    if (handle) {
        auto* model = static_cast<Model*>(handle);
        delete model;
    }
}

char* ra_infer(ra_model_handle handle, const char* prompt, int max_tokens) {
    if (!handle || !prompt) return nullptr;

    try {
        auto* model = static_cast<Model*>(handle);
        InferenceRequest req;
        req.prompt = prompt;
        req.max_tokens = max_tokens;

        auto result = model->infer(req);

        char* output = (char*)malloc(result.output.size() + 1);
        strcpy(output, result.output.c_str());
        return output;
    } catch (...) {
        return nullptr;
    }
}

void ra_infer_stream(
    ra_model_handle handle,
    const char* prompt,
    int max_tokens,
    ra_token_callback callback,
    void* user_data
) {
    if (!handle || !prompt || !callback) return;

    try {
        auto* model = static_cast<Model*>(handle);
        InferenceRequest req;
        req.prompt = prompt;
        req.max_tokens = max_tokens;

        model->infer_stream(req, [callback, user_data](const std::string& token) {
            callback(token.c_str(), user_data);
        });
    } catch (...) {
        // Error handling
    }
}

const char* ra_get_backend_name(ra_model_handle handle) {
    if (!handle) return "unknown";

    auto* model = static_cast<Model*>(handle);
    return model->get_backend_name();
}

long ra_get_memory_usage(ra_model_handle handle) {
    if (!handle) return 0;

    auto* model = static_cast<Model*>(handle);
    return model->get_memory_usage_bytes();
}

void ra_free_string(char* str) {
    if (str) {
        free(str);
    }
}

} // extern "C"
```

### JNI Bridge (Android)

```cpp
// src/bridges/jni/ra_jni.cpp
#include <jni.h>
#include "core/runtime.h"
#include <string>

using namespace runanywhere;

// Helper: Convert jstring to std::string
static std::string j2str(JNIEnv* env, jstring jstr) {
    if (!jstr) return "";
    const char* chars = env->GetStringUTFChars(jstr, nullptr);
    std::string result(chars);
    env->ReleaseStringUTFChars(jstr, chars);
    return result;
}

extern "C" {

// ai.runanywhere.RunAnywhere.nativeInit
JNIEXPORT jlong JNICALL
Java_ai_runanywhere_RunAnywhere_nativeInit(
    JNIEnv* env,
    jobject /* this */,
    jstring config
) {
    try {
        auto* runtime = new Runtime();
        std::string config_str = j2str(env, config);

        if (!runtime->initialize(config_str)) {
            delete runtime;
            return 0;
        }

        return reinterpret_cast<jlong>(runtime);
    } catch (const std::exception& e) {
        // Throw Java exception
        jclass exClass = env->FindClass("java/lang/RuntimeException");
        env->ThrowNew(exClass, e.what());
        return 0;
    }
}

// ai.runanywhere.RunAnywhere.nativeShutdown
JNIEXPORT void JNICALL
Java_ai_runanywhere_RunAnywhere_nativeShutdown(
    JNIEnv* /* env */,
    jobject /* this */,
    jlong handle
) {
    if (handle) {
        auto* runtime = reinterpret_cast<Runtime*>(handle);
        runtime->shutdown();
        delete runtime;
    }
}

// ai.runanywhere.RunAnywhere.nativeGetDeviceInfo
JNIEXPORT jstring JNICALL
Java_ai_runanywhere_RunAnywhere_nativeGetDeviceInfo(
    JNIEnv* env,
    jobject /* this */,
    jlong handle
) {
    if (!handle) return nullptr;

    try {
        auto* runtime = reinterpret_cast<Runtime*>(handle);
        std::string info = runtime->get_device_info_json();
        return env->NewStringUTF(info.c_str());
    } catch (...) {
        return nullptr;
    }
}

// ai.runanywhere.RunAnywhere.nativeLoadModel
JNIEXPORT jlong JNICALL
Java_ai_runanywhere_RunAnywhere_nativeLoadModel(
    JNIEnv* env,
    jobject /* this */,
    jlong handle,
    jstring manifest
) {
    if (!handle) return 0;

    try {
        auto* runtime = reinterpret_cast<Runtime*>(handle);
        std::string manifest_str = j2str(env, manifest);

        auto model = runtime->load_model(manifest_str);
        return reinterpret_cast<jlong>(model.release());
    } catch (const std::exception& e) {
        jclass exClass = env->FindClass("java/lang/RuntimeException");
        env->ThrowNew(exClass, e.what());
        return 0;
    }
}

// ai.runanywhere.Model.nativeInfer
JNIEXPORT jstring JNICALL
Java_ai_runanywhere_Model_nativeInfer(
    JNIEnv* env,
    jobject /* this */,
    jlong handle,
    jstring prompt,
    jint maxTokens
) {
    if (!handle) return nullptr;

    try {
        auto* model = reinterpret_cast<Model*>(handle);
        std::string prompt_str = j2str(env, prompt);

        InferenceRequest req;
        req.prompt = prompt_str;
        req.max_tokens = maxTokens;

        auto result = model->infer(req);
        return env->NewStringUTF(result.output.c_str());
    } catch (const std::exception& e) {
        jclass exClass = env->FindClass("java/lang/RuntimeException");
        env->ThrowNew(exClass, e.what());
        return nullptr;
    }
}

// ai.runanywhere.Model.nativeGetBackendName
JNIEXPORT jstring JNICALL
Java_ai_runanywhere_Model_nativeGetBackendName(
    JNIEnv* env,
    jobject /* this */,
    jlong handle
) {
    if (!handle) return nullptr;

    auto* model = reinterpret_cast<Model*>(handle);
    return env->NewStringUTF(model->get_backend_name());
}

// ai.runanywhere.Model.nativeUnload
JNIEXPORT void JNICALL
Java_ai_runanywhere_Model_nativeUnload(
    JNIEnv* /* env */,
    jobject /* this */,
    jlong handle
) {
    if (handle) {
        auto* model = reinterpret_cast<Model*>(handle);
        delete model;
    }
}

} // extern "C"
```

---

## Build System

### Root CMakeLists.txt

```cmake
cmake_minimum_required(VERSION 3.22)
project(RunAnywhere VERSION 1.0.0 LANGUAGES CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

# Options
option(RA_BUILD_CORE "Build core library" ON)
option(RA_BUILD_BACKENDS "Build backend adapters" ON)
option(RA_BUILD_BRIDGES "Build native bridges" ON)

option(RA_WITH_LLAMACPP "Include llama.cpp backend" ON)
option(RA_WITH_COREML "Include CoreML backend (Apple only)" OFF)
option(RA_WITH_TFLITE "Include TensorFlow Lite backend" OFF)
option(RA_WITH_ONNX "Include ONNX Runtime backend" OFF)
option(RA_WITH_MLX "Include MLX backend (Apple Silicon only)" OFF)

# Platform detection
if(IOS OR CMAKE_SYSTEM_NAME STREQUAL "iOS")
    set(RA_PLATFORM_IOS TRUE)
    set(RA_WITH_COREML ON)  # Always enable on iOS
elseif(ANDROID)
    set(RA_PLATFORM_ANDROID TRUE)
elseif(APPLE)
    set(RA_PLATFORM_MACOS TRUE)
    if(CMAKE_SYSTEM_PROCESSOR MATCHES "arm64")
        set(RA_WITH_COREML ON)
        set(RA_WITH_MLX ON)
    endif()
endif()

# Third-party dependencies
add_subdirectory(third_party)

# Core library (Layer 2)
if(RA_BUILD_CORE)
    add_subdirectory(src/core)
endif()

# Backend adapters (Layer 1)
if(RA_BUILD_BACKENDS)
    add_subdirectory(src/backends)
endif()

# Native bridges (Layer 3)
if(RA_BUILD_BRIDGES)
    add_subdirectory(src/bridges)
endif()

# Platform-specific packaging
include(cmake/Packaging.cmake)
```

### Core Library CMake

```cmake
# src/core/CMakeLists.txt

add_library(runanywhere_core STATIC
    runtime.cpp
    policy_engine.cpp
    device_detector.cpp
    config_parser.cpp
    model_manager.cpp
    telemetry.cpp
    ota_manager.cpp
)

target_include_directories(runanywhere_core
    PUBLIC
        $<BUILD_INTERFACE:${PROJECT_SOURCE_DIR}/include>
        $<INSTALL_INTERFACE:include>
    PRIVATE
        ${PROJECT_SOURCE_DIR}/src
)

target_link_libraries(runanywhere_core
    PRIVATE
        nlohmann_json::nlohmann_json
)

# Platform-specific code
if(RA_PLATFORM_IOS OR RA_PLATFORM_MACOS)
    target_sources(runanywhere_core PRIVATE
        device_detector_apple.mm
    )
    target_link_libraries(runanywhere_core PUBLIC
        "-framework Foundation"
        "-framework CoreML"
    )
elseif(RA_PLATFORM_ANDROID)
    target_sources(runanywhere_core PRIVATE
        device_detector_android.cpp
    )
    target_link_libraries(runanywhere_core PUBLIC
        log
        android
    )
endif()

# Export
set_target_properties(runanywhere_core PROPERTIES
    OUTPUT_NAME "runanywhere_core"
    VERSION ${PROJECT_VERSION}
)
```

### Backends CMake

```cmake
# src/backends/CMakeLists.txt

# Common backend interface
add_library(backend_interface INTERFACE)
target_include_directories(backend_interface INTERFACE
    ${PROJECT_SOURCE_DIR}/src/backends
)

# llama.cpp backend
if(RA_WITH_LLAMACPP)
    add_library(ra_backend_llamacpp STATIC
        llamacpp/llamacpp_backend.cpp
    )
    target_link_libraries(ra_backend_llamacpp
        PUBLIC backend_interface
        PRIVATE runanywhere_core llama
    )

    # Enable Metal on Apple platforms
    if(APPLE)
        target_compile_definitions(ra_backend_llamacpp PRIVATE
            GGML_USE_METAL
        )
    endif()
endif()

# CoreML backend
if(RA_WITH_COREML AND APPLE)
    add_library(ra_backend_coreml STATIC
        coreml/coreml_backend.mm
    )
    target_link_libraries(ra_backend_coreml
        PUBLIC backend_interface
        PRIVATE runanywhere_core
                "-framework CoreML"
                "-framework Foundation"
    )
    target_compile_options(ra_backend_coreml PRIVATE
        -fobjc-arc
    )
endif()

# TensorFlow Lite backend
if(RA_WITH_TFLITE)
    add_library(ra_backend_tflite STATIC
        tflite/tflite_backend.cpp
    )
    target_link_libraries(ra_backend_tflite
        PUBLIC backend_interface
        PRIVATE runanywhere_core tensorflow-lite
    )
endif()

# ONNX Runtime backend
if(RA_WITH_ONNX)
    add_library(ra_backend_onnx STATIC
        onnx/onnx_backend.cpp
    )
    target_link_libraries(ra_backend_onnx
        PUBLIC backend_interface
        PRIVATE runanywhere_core onnxruntime
    )
endif()
```

### Bridges CMake

```cmake
# src/bridges/CMakeLists.txt

# Swift bridge (C for Swift)
if(RA_PLATFORM_IOS OR RA_PLATFORM_MACOS)
    add_library(ra_bridge_swift STATIC
        swift/ra_bridge.cpp
    )
    target_link_libraries(ra_bridge_swift
        PUBLIC runanywhere_core
    )
    target_include_directories(ra_bridge_swift PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/swift
    )
endif()

# JNI bridge (Android)
if(RA_PLATFORM_ANDROID)
    add_library(ra_bridge_jni SHARED
        jni/ra_jni.cpp
    )
    target_link_libraries(ra_bridge_jni
        PUBLIC runanywhere_core
        PRIVATE log
    )
endif()

# Dart FFI bridge (Flutter)
add_library(ra_bridge_dart SHARED
    dart/ra_ffi.cpp
)
target_link_libraries(ra_bridge_dart
    PUBLIC runanywhere_core
)
```

### iOS Build Script

```bash
#!/bin/bash
# scripts/build-ios.sh

set -e

VERSION="1.0.0"
BUILD_TYPE="${BUILD_TYPE:-Release}"
OUTPUT_DIR="build/xcframeworks"

echo "🔨 Building RunAnywhere for iOS (v${VERSION})"

# Clean previous builds
rm -rf build/ios-* ${OUTPUT_DIR}
mkdir -p ${OUTPUT_DIR}

# Build for iOS device (arm64)
echo "📱 Building for iOS device..."
cmake -B build/ios-arm64 \
    -GXcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=14.0 \
    -DRA_WITH_LLAMACPP=ON \
    -DRA_WITH_COREML=ON \
    -DCMAKE_BUILD_TYPE=${BUILD_TYPE}

cmake --build build/ios-arm64 --config ${BUILD_TYPE} --parallel

# Build for iOS simulator (arm64 + x86_64)
echo "🖥️  Building for iOS simulator..."
cmake -B build/ios-sim \
    -GXcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
    -DCMAKE_OSX_SYSROOT=iphonesimulator \
    -DRA_WITH_LLAMACPP=ON \
    -DRA_WITH_COREML=ON \
    -DCMAKE_BUILD_TYPE=${BUILD_TYPE}

cmake --build build/ios-sim --config ${BUILD_TYPE} --parallel

# Create XCFramework for Core (includes llama.cpp)
echo "📦 Creating RunAnywhereCore.xcframework..."
xcodebuild -create-xcframework \
    -library build/ios-arm64/${BUILD_TYPE}-iphoneos/librunanywhere_core.a \
    -headers include/runanywhere \
    -library build/ios-sim/${BUILD_TYPE}-iphonesimulator/librunanywhere_core.a \
    -headers include/runanywhere \
    -output ${OUTPUT_DIR}/RunAnywhereCore.xcframework

# Optionally create separate frameworks for backends
if [ -f build/ios-arm64/${BUILD_TYPE}-iphoneos/libra_backend_coreml.a ]; then
    echo "📦 Creating RunAnywhereCoreML.xcframework..."
    xcodebuild -create-xcframework \
        -library build/ios-arm64/${BUILD_TYPE}-iphoneos/libra_backend_coreml.a \
        -library build/ios-sim/${BUILD_TYPE}-iphonesimulator/libra_backend_coreml.a \
        -output ${OUTPUT_DIR}/RunAnywhereCoreML.xcframework
fi

echo "✅ iOS build complete!"
ls -lh ${OUTPUT_DIR}
```

### Android Build Script

```bash
#!/bin/bash
# scripts/build-android.sh

set -e

VERSION="1.0.0"
BUILD_TYPE="${BUILD_TYPE:-Release}"
NDK_PATH="${ANDROID_NDK:-$ANDROID_HOME/ndk-bundle}"
OUTPUT_DIR="build/android"

echo "🔨 Building RunAnywhere for Android (v${VERSION})"

# ABIs to build (only 64-bit)
ABIS=("arm64-v8a" "x86_64")

for ABI in "${ABIS[@]}"; do
    echo "📱 Building for ${ABI}..."

    cmake -B build/android-${ABI} \
        -DCMAKE_TOOLCHAIN_FILE=${NDK_PATH}/build/cmake/android.toolchain.cmake \
        -DANDROID_ABI=${ABI} \
        -DANDROID_PLATFORM=android-24 \
        -DANDROID_STL=c++_shared \
        -DRA_WITH_LLAMACPP=ON \
        -DRA_WITH_TFLITE=ON \
        -DCMAKE_BUILD_TYPE=${BUILD_TYPE}

    cmake --build build/android-${ABI} --config ${BUILD_TYPE} --parallel

    # Copy .so files to jniLibs
    mkdir -p ${OUTPUT_DIR}/jniLibs/${ABI}
    cp build/android-${ABI}/librunanywhere_core.so ${OUTPUT_DIR}/jniLibs/${ABI}/
    cp build/android-${ABI}/libra_bridge_jni.so ${OUTPUT_DIR}/jniLibs/${ABI}/
done

echo "✅ Android native libraries built!"

# Build AAR (if android/ Gradle project exists)
if [ -d "android" ]; then
    echo "📦 Building AAR..."
    cd android
    ./gradlew assembleRelease
    cd ..
    echo "✅ AAR created at android/app/build/outputs/aar/"
fi
```

---

## Binary Packaging

### Code Signing Script

```bash
#!/bin/bash
# scripts/sign-binaries.sh

set -e

SIGN_IDENTITY="${CODESIGN_IDENTITY:-Apple Distribution: RunAnywhere Inc}"
OUTPUT_DIR="build/xcframeworks"

echo "🔐 Signing binaries..."

# Sign iOS XCFrameworks
for framework in ${OUTPUT_DIR}/*.xcframework; do
    echo "Signing $(basename $framework)..."
    codesign \
        --sign "${SIGN_IDENTITY}" \
        --timestamp \
        --options runtime \
        --deep \
        ${framework}

    # Verify
    codesign --verify --deep --strict ${framework}
    echo "✅ $(basename $framework) signed and verified"
done

# Sign Android AARs
if [ -d "android/app/build/outputs/aar" ]; then
    for aar in android/app/build/outputs/aar/*.aar; do
        echo "Signing $(basename $aar)..."
        jarsigner \
            -verbose \
            -sigalg SHA256withRSA \
            -digestalg SHA-256 \
            -keystore ${KEYSTORE_PATH} \
            -storepass "${KEYSTORE_PASSWORD}" \
            ${aar} \
            runanywhere

        # Verify
        jarsigner -verify -verbose -certs ${aar}
        echo "✅ $(basename $aar) signed and verified"
    done
fi

echo "✅ All binaries signed!"
```

### Packaging Script

```bash
#!/bin/bash
# scripts/package-release.sh

set -e

VERSION="1.0.0"
OUTPUT_DIR="build/release-${VERSION}"

echo "📦 Packaging release v${VERSION}..."

mkdir -p ${OUTPUT_DIR}/{ios,android}

# Package iOS artifacts
cd build/xcframeworks
for framework in *.xcframework; do
    echo "Packaging ${framework}..."
    zip -r ${OUTPUT_DIR}/ios/${framework}.zip ${framework}
    shasum -a 256 ${OUTPUT_DIR}/ios/${framework}.zip > ${OUTPUT_DIR}/ios/${framework}.zip.sha256
done
cd ../..

# Package Android artifacts
if [ -d "android/app/build/outputs/aar" ]; then
    cp android/app/build/outputs/aar/*.aar ${OUTPUT_DIR}/android/
    cd ${OUTPUT_DIR}/android
    for aar in *.aar; do
        shasum -a 256 ${aar} > ${aar}.sha256
    done
    cd ../../..
fi

# Create manifest
cat > ${OUTPUT_DIR}/manifest.json << EOF
{
  "version": "${VERSION}",
  "released_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "platforms": {
    "ios": {
      "core": {
        "url": "https://releases.runanywhere.ai/ios/${VERSION}/RunAnywhereCore.xcframework.zip",
        "sha256": "$(cat ${OUTPUT_DIR}/ios/RunAnywhereCore.xcframework.zip.sha256 | awk '{print $1}')",
        "size_mb": $(du -m ${OUTPUT_DIR}/ios/RunAnywhereCore.xcframework.zip | awk '{print $1}')
      }
    },
    "android": {
      "core": {
        "artifact": "com.runanywhere:core:${VERSION}",
        "size_mb": $(du -m ${OUTPUT_DIR}/android/runanywhere-core-release.aar | awk '{print $1}')
      }
    }
  }
}
EOF

echo "✅ Release packaged at ${OUTPUT_DIR}"
tree ${OUTPUT_DIR}
```

---

## Distribution Infrastructure

### CDN Upload Script

```bash
#!/bin/bash
# scripts/upload-artifacts.sh

set -e

VERSION="1.0.0"
RELEASE_DIR="build/release-${VERSION}"
CDN_BUCKET="s3://releases.runanywhere.ai"

echo "☁️  Uploading artifacts to CDN..."

# Upload iOS artifacts
aws s3 sync ${RELEASE_DIR}/ios/ ${CDN_BUCKET}/ios/${VERSION}/ \
    --acl public-read \
    --cache-control "max-age=31536000"

# Upload manifest
aws s3 cp ${RELEASE_DIR}/manifest.json ${CDN_BUCKET}/manifest-${VERSION}.json \
    --acl public-read \
    --content-type application/json

# Update latest pointer
aws s3 cp ${CDN_BUCKET}/manifest-${VERSION}.json ${CDN_BUCKET}/manifest-latest.json \
    --acl public-read

echo "✅ Artifacts uploaded!"
echo "📍 iOS: https://releases.runanywhere.ai/ios/${VERSION}/"
echo "📍 Manifest: https://releases.runanywhere.ai/manifest-${VERSION}.json"
```

### GitHub Actions CI/CD

```yaml
# .github/workflows/build-release.yml
name: Build and Release Binaries

on:
  push:
    tags:
      - 'v*'

jobs:
  build-ios:
    runs-on: macos-14
    steps:
      - uses: actions/checkout@v4
        with:
          submodules: recursive

      - name: Setup Xcode
        uses: maxim-lobanov/setup-xcode@v1
        with:
          xcode-version: '15.2'

      - name: Build iOS binaries
        run: ./scripts/build-ios.sh
        env:
          BUILD_TYPE: Release

      - name: Sign binaries
        run: ./scripts/sign-binaries.sh
        env:
          CODESIGN_IDENTITY: ${{ secrets.CODESIGN_IDENTITY }}

      - name: Package release
        run: ./scripts/package-release.sh

      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: ios-binaries
          path: build/release-*/ios/

  build-android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          submodules: recursive

      - name: Setup Android NDK
        uses: nttld/setup-ndk@v1
        with:
          ndk-version: r26b

      - name: Build Android binaries
        run: ./scripts/build-android.sh
        env:
          BUILD_TYPE: Release

      - name: Sign AAR
        run: ./scripts/sign-binaries.sh
        env:
          KEYSTORE_PATH: ${{ secrets.KEYSTORE_PATH }}
          KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}

      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: android-binaries
          path: build/release-*/android/

  release:
    needs: [build-ios, build-android]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Download iOS artifacts
        uses: actions/download-artifact@v4
        with:
          name: ios-binaries
          path: release/ios/

      - name: Download Android artifacts
        uses: actions/download-artifact@v4
        with:
          name: android-binaries
          path: release/android/

      - name: Upload to CDN
        run: ./scripts/upload-artifacts.sh
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
        with:
          files: |
            release/ios/*.zip
            release/android/*.aar
            release/manifest.json
```

---

## Versioning & Release

### Version Management

**Semantic Versioning:** `MAJOR.MINOR.PATCH`

```cpp
// include/runanywhere/version.h
#pragma once

#define RA_VERSION_MAJOR 1
#define RA_VERSION_MINOR 0
#define RA_VERSION_PATCH 0

#define RA_VERSION_STRING "1.0.0"
#define RA_VERSION_NUMBER ((RA_VERSION_MAJOR << 16) | (RA_VERSION_MINOR << 8) | RA_VERSION_PATCH)

namespace runanywhere {

struct Version {
    int major;
    int minor;
    int patch;

    static Version current() {
        return {RA_VERSION_MAJOR, RA_VERSION_MINOR, RA_VERSION_PATCH};
    }

    bool compatible_with(const Version& other) const {
        // Same major version = compatible
        return major == other.major;
    }
};

} // namespace runanywhere
```

### Release Checklist

```markdown
# Release Process for v1.X.Y

## Pre-release (1-2 days before)
- [ ] Update version in `CMakeLists.txt`
- [ ] Update version in `include/runanywhere/version.h`
- [ ] Update CHANGELOG.md
- [ ] Run full test suite on all platforms
- [ ] Test integration with public SDKs
- [ ] Update documentation

## Release Day
- [ ] Create git tag: `git tag v1.X.Y`
- [ ] Push tag: `git push origin v1.X.Y`
- [ ] Wait for CI to build binaries
- [ ] Verify checksums of artifacts
- [ ] Test download URLs
- [ ] Update public SDKs to point to new version

## Post-release
- [ ] Monitor crash reports (first 24 hours)
- [ ] Check telemetry for adoption
- [ ] Announce release (blog, Twitter, email)
- [ ] Update example apps
```

---

## Consumption by Public SDKs

### iOS Swift SDK Consumption

```swift
// Public SDK: Package.swift
import PackageDescription

let package = Package(
    name: "RunAnywhere",
    platforms: [.iOS(.v14)],
    products: [
        .library(name: "RunAnywhere", targets: ["RunAnywhere"]),
    ],
    targets: [
        // PUBLIC: Swift wrapper (source code in GitHub)
        .target(
            name: "RunAnywhere",
            dependencies: ["RunAnywhereCore"],
            path: "Sources/RunAnywhere"
        ),

        // PRIVATE: Binary XCFramework (downloaded from CDN)
        .binaryTarget(
            name: "RunAnywhereCore",
            url: "https://releases.runanywhere.ai/ios/1.0.0/RunAnywhereCore.xcframework.zip",
            checksum: "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2"
        ),
    ]
)
```

**Workflow:**
1. Developer adds dependency in their app: `.package(url: "https://github.com/runanywhere/runanywhere-swift", from: "1.0.0")`
2. SPM fetches public Swift code from GitHub
3. SPM downloads `RunAnywhereCore.xcframework.zip` from CDN
4. SPM verifies checksum
5. XCFramework is extracted and linked into app
6. App can now call RunAnywhere APIs

### Android SDK Consumption

```gradle
// Public SDK: build.gradle.kts (in GitHub repo)
plugins {
    id("com.android.library")
    kotlin("android")
}

android {
    namespace = "ai.runanywhere"
}

dependencies {
    // PRIVATE: Binary AAR (from Maven)
    api("ai.runanywhere:core:1.0.0")
}
```

**Workflow:**
1. Developer adds dependency in their app: `implementation("ai.runanywhere:sdk:1.0.0")`
2. Gradle fetches public Kotlin code from Maven Central (thin wrapper)
3. Gradle resolves transitive dependency `ai.runanywhere:core:1.0.0`
4. Gradle downloads AAR from private Maven repo (authenticated)
5. AAR contains `.so` files for arm64-v8a/x86_64
6. App bundles only the ABI it needs (via splits)

### Maven Publishing (Private Repo)

```gradle
// Private repo: publish.gradle.kts
publishing {
    publications {
        create<MavenPublication>("release") {
            groupId = "ai.runanywhere"
            artifactId = "core"
            version = "1.0.0"

            artifact("build/outputs/aar/runanywhere-core-release.aar")

            pom {
                name.set("RunAnywhere Core")
                description.set("Multi-backend AI inference (closed source)")
                url.set("https://runanywhere.ai")

                licenses {
                    license {
                        name.set("Proprietary")
                        url.set("https://runanywhere.ai/license")
                    }
                }
            }
        }
    }

    repositories {
        maven {
            name = "RunAnywherePrivate"
            url = uri("https://maven.runanywhere.ai/releases")
            credentials {
                username = System.getenv("MAVEN_USER")
                password = System.getenv("MAVEN_TOKEN")
            }
        }
    }
}
```

### Flutter Plugin Consumption

```yaml
# Public plugin: pubspec.yaml (in GitHub)
name: runanywhere
version: 1.0.0

dependencies:
  flutter:
    sdk: flutter
  ffi: ^2.1.0

# Native dependencies pulled during build
flutter:
  plugin:
    platforms:
      ios:
        pluginClass: RunAnywherePlugin
      android:
        package: ai.runanywhere
        pluginClass: RunAnywherePlugin
```

```ruby
# ios/runanywhere.podspec (downloads binary)
Pod::Spec.new do |s|
  s.name = 'runanywhere'
  s.version = '1.0.0'

  # PRIVATE: Download binary during pod install
  s.vendored_frameworks = 'Frameworks/RunAnywhereCore.xcframework'

  s.prepare_command = <<-CMD
    curl -L https://releases.runanywhere.ai/flutter/ios/1.0.0/RunAnywhereCore.xcframework.zip -o framework.zip
    unzip -q framework.zip -d Frameworks/
    rm framework.zip
  CMD
end
```

---

## Summary: What You Need To Do

### 1. Set Up Private Repository

```bash
# Create private repo
git init runanywhere-core
cd runanywhere-core

# Add submodules
git submodule add https://github.com/ggerganov/llama.cpp third_party/llama.cpp

# Set up structure (as shown above)
mkdir -p src/{core,backends,bridges}
mkdir -p include/runanywhere
mkdir -p scripts ci
```

### 2. Implement Core Components

**Priority order:**
1. ✅ Layer 2: Core runtime + policy engine (1-2 weeks)
2. ✅ Layer 1: llama.cpp backend adapter (1 week)
3. ✅ Layer 3: Swift + JNI bridges (1 week)
4. ✅ Build system: CMake + scripts (1 week)
5. ✅ CI/CD: GitHub Actions (3 days)
6. ⏳ Layer 1: CoreML/TFLite backends (2-3 weeks)

### 3. Build and Test Locally

```bash
# iOS
./scripts/build-ios.sh
# Test with Xcode sample app

# Android
./scripts/build-android.sh
# Test with Android Studio sample app
```

### 4. Set Up Distribution

```bash
# Create S3 bucket for CDN
aws s3 mb s3://releases.runanywhere.ai

# Set up Maven repo (Sonatype or self-hosted)
# Configure credentials in CI

# Test upload
./scripts/upload-artifacts.sh
```

### 5. Update Public SDKs

**iOS SDK:**
```bash
cd runanywhere-swift
# Update Package.swift with new binary URL
# Push to GitHub
git tag v1.0.0
git push --tags
```

**Android SDK:**
```bash
cd runanywhere-android
# Update build.gradle with new core version
# Push to GitHub
git tag v1.0.0
git push --tags
```

### 6. Release

```bash
# Tag release in private repo
git tag v1.0.0
git push origin v1.0.0

# CI builds and uploads binaries automatically
# Verify downloads work
# Announce release
```

---

**End of Document**

This is the complete blueprint for implementing Layers 1-3 as private binaries that public SDKs consume. Follow this guide step-by-step to build your proprietary core.
