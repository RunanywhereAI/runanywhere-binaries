# On-Device AI: Fundamentals & Reference Guide

**Version:** 1.0
**Last Updated:** 2025-11-09
**Purpose:** Educational reference for understanding on-device AI

---

## Table of Contents

1. [Model Fundamentals](#model-fundamentals)
2. [Model Formats](#model-formats)
3. [Inference Runtimes](#inference-runtimes)
4. [Hardware Landscape](#hardware-landscape)
5. [Model Types & Behavior](#model-types--behavior)
6. [Performance Considerations](#performance-considerations)

---

## Model Fundamentals

### What Is a Model?

Every ML model consists of:

| Component | Description | Size Impact |
|-----------|-------------|-------------|
| **Graph/Architecture** | Computation DAG (layers, ops, shapes) | Negligible |
| **Weights** | Learned parameters (matrices) | 7B @ FP32 = 28GB |
| **Config** | Hyperparameters, vocab size | <1MB |
| **Tokenizer** | Text ↔ token mapping (NLP only) | ~1-5MB |
| **Metadata** | Training info, license, version | <1MB |

### Weight Quantization

```
Precision    Size (7B params)    Quality    Use Case
──────────────────────────────────────────────────────
FP32         28 GB               Best       Training
FP16         14 GB               Excellent  Desktop
INT8         7 GB                Good       Mid-range
INT4         3.5 GB              Acceptable Budget phones
```

**Edge deployment target:** INT4-INT8 with group-wise quantization (Q4_K_M, Q5_K_M).

### Tokenization (for Language Models)

Tokenization converts text into numbers that models can process:

```
"Hello world" → [15496, 995] → Model processes → [8995, 374] → "It's great"
```

**Key concepts:**
- **Vocabulary:** Fixed set of tokens (usually 32k-100k)
- **Tokenizer types:** BPE (Byte-Pair Encoding), WordPiece, SentencePiece
- **Special tokens:** `<BOS>`, `<EOS>`, `<PAD>`, `<UNK>`

### KV Cache Memory (LLMs)

For LLMs, the Key-Value cache dominates memory during decoding:

```
KV_bytes = 2 × Batch × Layers × HiddenSize × ContextLength × ElementBytes

Example (7B-class model, FP16):
2 × 1 × 32 × 4096 × 2048 × 2 = ~1 GB

Mitigation strategies:
- Shorter context (512-1024 on phones)
- KV quantization (INT8: 50% reduction)
- Paged KV cache (swap to storage)
```

---

## Model Formats

| Format | Creator | Primary Use | Advantages | Mobile Support |
|--------|---------|-------------|-----------|----------------|
| **GGUF** | llama.cpp | LLM (quantized) | Single-file, mmap-able | ✅ Excellent |
| **ONNX** | Microsoft | Cross-platform | Hardware-agnostic | ✅ Good |
| **TFLite** | Google | Mobile ML | NNAPI integration | ✅ Excellent |
| **CoreML** | Apple | iOS/macOS | ANE acceleration | ✅ iOS/macOS only |
| **MLX** | Apple | Apple Silicon | Unified memory | ✅ macOS only |
| **TorchScript** | Meta | PyTorch | Legacy (use ExecuTorch) | ⚠️ Large |
| **OpenVINO** | Intel | Intel hardware | CPU/iGPU optimization | ⚠️ Desktop |
| **TensorRT** | NVIDIA | NVIDIA GPUs | Extreme optimization | ❌ No mobile |

### Conversion Flow

```
PyTorch (.pt) → GGUF / ONNX / TFLite / CoreML
```

---

## Inference Runtimes

### LLM-Focused

**llama.cpp** (Recommended for MVP)
- **Format:** GGUF
- **Backends:** CPU (NEON), Metal (iOS), Vulkan (experimental)
- **Quantization:** Q4_0, Q4_K_M, Q5_K_M, Q8_0
- **Pros:** Single binary, great ARM perf
- **Cons:** LLM-only, limited vision support

**MLC-LLM** (Advanced)
- **Format:** Compiled via Apache TVM
- **Backends:** Metal, Vulkan, WebGPU, CUDA
- **Pros:** Cutting-edge optimization
- **Cons:** Complex build, less stable

### General-Purpose

**ONNX Runtime Mobile**
- **Format:** ONNX
- **EPs:** NNAPI, Core ML, XNNPACK, QNN (Qualcomm)
- **Pros:** Vendor-neutral, wide support
- **Cons:** Larger binary (~10-20MB per EP)

**TensorFlow Lite**
- **Format:** TFLite
- **Delegates:** XNNPACK (CPU), GPU, NNAPI, Hexagon
- **Pros:** Mature ecosystem
- **Cons:** Quantization workflows complex

**ExecuTorch** (Emerging)
- **Format:** PyTorch exported graphs
- **Backends:** XNNPACK, Core ML, QNN, Vulkan
- **Pros:** PyTorch-native
- **Cons:** Young (2024), fewer examples

**Core ML Runtime** (iOS/macOS)
- **Format:** .mlmodel / .mlpackage
- **Hardware:** ANE, Metal (GPU), CPU
- **Pros:** Automatic ANE offload
- **Cons:** Apple-only, black-box

### Mobile-Optimized (CV/Audio)

**NCNN** (Tencent)
- **Format:** .param / .bin
- **Backends:** Vulkan, CPU
- **Pros:** Tiny (<1MB), fast startup
- **Use Case:** CV models, audio encoders

**MNN** (Alibaba)
- **Format:** .mnn
- **Backends:** Metal, OpenCL, Vulkan, CPU
- **Pros:** Lightweight
- **Use Case:** Multi-modal models

---

## Hardware Landscape

### CPU Architectures

**ARM (99% of mobile)**

| Core | Performance | Devices | TOPS (AI) |
|------|-------------|---------|-----------|
| Cortex-A53 | 1.5 GFLOPS/core | Budget ($50-150) | ~0.1 |
| Cortex-A55 | 2 GFLOPS/core | Entry ($150-300) | ~0.2 |
| Cortex-A76 | 12 GFLOPS/core | Mid ($300-600) | ~0.5 |
| Cortex-X3 | 35+ GFLOPS/core | Flagship ($800+) | ~1.0 |

**SIMD Extensions:**
- ARMv8: NEON (128-bit vectors)
- ARMv8.2: FP16 arithmetic (2× throughput)
- ARMv8.4: Dot product instructions (INT8)

**Apple Silicon**

| Chip | CPU Cores | GPU Cores | ANE TOPS | RAM | Devices |
|------|-----------|-----------|----------|-----|---------|
| A17 Pro | 6 (2P+4E) | 6 | 35 | 8GB | iPhone 15 Pro |
| M3 | 8 (4P+4E) | 10 | 18 | 8-24GB | MacBook Air/Pro |
| M4 | 10 (4P+6E) | 10 | 38 | 16-32GB | MacBook Pro |

**Key Feature:** AMX (Apple Matrix Coprocessor) – hidden unit for matrix math

### Mobile GPUs

| Vendor | GPU | API | Notes |
|--------|-----|-----|-------|
| Qualcomm | Adreno | Vulkan, OpenCL | AI Engine integration |
| ARM | Mali | OpenCL | Valhall architecture |
| Apple | Apple GPU | Metal | ANE integration |
| Imagination | PowerVR | OpenGL ES | Legacy |

### NPU/DSP (Specialized AI Hardware)

**Qualcomm Hexagon**

| Snapdragon | Hexagon | TOPS | Access |
|------------|---------|------|--------|
| 855 | 680 | 7 | SNPE, QNN |
| 865 | 690 | 15 | SNPE, QNN |
| 888 | 780 | 26 | QNN |
| 8 Gen 2 | — | 45 | QNN |
| 8 Gen 3 | — | 60+ | QNN |

**Access Methods:**
- Android NNAPI (automatic, limited control)
- Qualcomm QNN SDK (full control, licensing required)
- TFLite Hexagon delegate

**Apple Neural Engine (ANE)**

| Chip | ANE TOPS | Access |
|------|----------|--------|
| A15 | 15.8 | Core ML |
| A16 | 17 | Core ML |
| A17 Pro | 35 | Core ML |
| M3 | 18 | Core ML |
| M4 | 38 | Core ML |

**Characteristics:**
- Core ML automatically routes compatible ops to ANE
- 10× more power-efficient than GPU for ML
- Best for: batch matmul, conv, normalization
- Poor for: dynamic shapes, custom ops

**MediaTek APU**

| Dimensity | APU TOPS | Access |
|-----------|----------|--------|
| 9200 | 8 | NeuroPilot, NNAPI |
| 9300 | 12 | NeuroPilot, NNAPI |

**Google Tensor (Pixel)**

| Version | TPU TOPS | Access |
|---------|----------|--------|
| G2 (Pixel 7) | ~10 | NNAPI |
| G3 (Pixel 8) | ~15 | NNAPI |

### Memory Hierarchy

```
Registers (ns)
    ↓
L1 Cache (1-2ns)    32-64KB/core
    ↓
L2 Cache (5-10ns)   256KB-2MB/core
    ↓
L3 Cache (20-40ns)  4-32MB shared
    ↓
RAM (100ns)         4-16GB
    ↓
Storage (μs-ms)     Flash/SSD
```

**Why this matters:**
- 7B Q4 model = 3.5GB must fit in RAM
- Memory-mapped loading prevents exhaustion
- Cache misses kill performance

---

## Model Types & Behavior

| Type | Input → Output | Runtime Pattern | Memory Pattern |
|------|---------------|-----------------|----------------|
| **LLM** | tokens → tokens | Autoregressive (prefill + decode) | KV cache grows |
| **ASR** | audio → text | Streaming encoder + CTC/RNN-T | Fixed window |
| **TTS** | text → audio | Two-stage (acoustic + vocoder) | Fixed frames |
| **VLM** | image+text → text | Encoder + projector + LLM | Image + KV cache |
| **CV** | image → boxes/masks | Feed-forward | Single-pass |

### LLM Inference Flow

```python
Input: "The capital of France is"

# 1. Tokenization
tokens = [450, 7483, 310, 3444, 338]

# 2. Embedding Lookup
embeddings = model.embed(tokens)  # [5, 4096]

# 3. Transformer Layers (prefill)
for layer in model.layers:
    Q, K, V = layer.attention(embeddings)
    attention_out = softmax(Q @ K.T) @ V
    embeddings = layer.ffn(attention_out)

# 4. Output projection
logits = model.lm_head(embeddings[-1])  # [vocab_size]

# 5. Sample next token
next_token = argmax(logits)  # 3681 = " Paris"

# 6. Decode loop (autoregressive)
for _ in range(max_tokens):
    # Use KV cache to avoid recomputing
    # Generate one token at a time
    ...
```

### Where Hardware Acceleration Happens

**Matrix Multiplications** (90% of compute):
```
embeddings @ W_q  ← GPU/NPU/AMX accelerate this
```

- **CPU (ARM NEON):** 128-bit vector operations
- **GPU (Metal/Vulkan):** Parallel compute shaders
- **NPU/ANE:** Fixed-function matrix units (INT8/INT16)
- **AMX:** Hidden Apple coprocessor for matmul

---

## Performance Considerations

### Device Tier Classification

| Tier | CPU | RAM | NPU | Example | Target Models |
|------|-----|-----|-----|---------|---------------|
| **Ultra-Budget** | Cortex-A53 | 2GB | None | $50 Android | 0.5B INT4, ctx≤512 |
| **Budget** | Cortex-A55+A73 | 4GB | Basic | $150 Android | 1B INT4, ctx≤1024 |
| **Mid-Range** | A76+A55 | 6-8GB | Hexagon ~10 TOPS | $400 Android | 1.5B INT4-INT8, ctx 2048 |
| **Flagship** | X3+A715 | 12GB | Hexagon 45 TOPS | Galaxy S24 | 3B INT4-INT8, ctx 4096 |
| **iPhone Pro** | A17 Pro | 8GB | ANE 35 TOPS | iPhone 15 Pro | 3B INT4-FP16, ctx 4096 |
| **Mac** | M3 | 16GB+ | ANE 18 TOPS | MacBook | 7B INT4-FP16, ctx 8192 |

### Practical Numbers

**Memory:**
- 1B parameter model at INT4 ≈ 0.5 GB for weights
- KV cache (FP16) ~ L × H × T × 4 bytes × 2
- Keep T modest (512-1024) on phones or use KV int8

**Latency:**
- Target P95 turn < 700 ms for "human-speed" voice
- Pipeline ASR/LLM/TTS to hide tails

**Thermals:**
- Favor ANE/Hexagon/APU over GPU for steady workloads
- Throttle-aware policy is mandatory

### Execution Stack (iPhone Example)

```
Application Layer (Swift)
    ↓
Your App: model.predict("Hello")
    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Core ML Framework
    ↓
Analyzes model → Routes to best hardware
    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Option 1: ANE]
Core ML → ANE Driver → Neural Engine
    ↓
Matrix ops on dedicated silicon
    ↓
Result

[Option 2: GPU]
Core ML → Metal → GPU Driver
    ↓
Compute shaders on GPU
    ↓
Result

[Option 3: CPU]
Core ML → Accelerate/BNNS → CPU
    ↓
SIMD/NEON instructions
    ↓
Result
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Kernel Layer (XNU)
    ↓
Hardware access, memory management
```

### Model Loading Process

**What happens when you "load a model":**

1. **File Read:** `model.gguf` (3.5GB on disk)

2. **Memory Mapping:**
   ```c
   mmap(file, 3.5GB) → Virtual address space
   ```
   - Doesn't load entire file into RAM immediately
   - OS loads pages (4KB chunks) on-demand
   - Massive speedup vs. traditional file I/O

3. **Parse Metadata:**
   - Architecture: "llama", layers: 32, vocab_size: 32000
   - Context length: 4096 tokens
   - Quantization: Q4_K_M

4. **Allocate Compute Buffers:**
   ```
   Input buffer: [batch × seq_len × hidden_dim]
   Output buffer: [batch × seq_len × vocab_size]
   KV cache: [2 × layers × heads × seq_len × head_dim]
   ```

5. **Initialize Tokenizer:**
   - Load vocabulary
   - Load merge rules (for BPE)

6. **Warm-up (Optional):**
   - Run dummy inference to compile kernels
   - JIT compilation (Metal/CUDA)

---

## References

### Technical Resources

**Inference Runtimes:**
- llama.cpp: https://github.com/ggerganov/llama.cpp
- ONNX Runtime: https://onnxruntime.ai
- TensorFlow Lite: https://tensorflow.org/lite
- Core ML: https://developer.apple.com/documentation/coreml
- ExecuTorch: https://pytorch.org/executorch
- MLX: https://github.com/ml-explore/mlx

**Hardware SDKs:**
- Qualcomm QNN: https://developer.qualcomm.com/software/qualcomm-neural-processing-sdk
- MediaTek NeuroPilot: https://www.mediatek.com/innovations/neuralpilot
- Android NNAPI: https://developer.android.com/ndk/guides/neuralnetworks

**Performance Resources:**
- MLPerf Mobile: https://mlcommons.org/benchmarks/inference-mobile/
- AI Benchmark: https://ai-benchmark.com/ranking.html
- GeekBench ML: https://www.geekbench.com/ml/

---

**End of Document**
