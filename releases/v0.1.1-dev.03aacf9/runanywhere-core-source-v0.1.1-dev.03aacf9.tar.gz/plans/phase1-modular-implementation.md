# RunAnywhere Phase 1: Modular Backend Implementation Plan

**Version:** 1.0
**Created:** 2025-01-20
**Timeline:** 8-12 weeks
**Goal:** Ship standalone backend modules with explicit developer selection

---

## Table of Contents

1. [Prerequisites & Environment Setup](#prerequisites--environment-setup)
2. [Quick Start: ONNX-First Path](#quick-start-onnx-first-path)
3. [Overview](#overview)
4. [Architecture](#architecture)
5. [Language Usage Clarification](#language-usage-clarification)
6. [Week-by-Week Implementation Plan](#week-by-week-implementation-plan)
7. [Repository Structure](#repository-structure)
8. [Implementation Details](#implementation-details)
9. [Build System](#build-system)
10. [Testing Strategy](#testing-strategy)
11. [Release Process](#release-process)
12. [SDK Consumption Patterns](#sdk-consumption-patterns)
13. [SDK Support Matrix](#sdk-support-matrix)
14. [Phase 2 Preparation](#phase-2-preparation)

---

## Prerequisites & Environment Setup

### Required Tools

#### macOS (for iOS/macOS development)

```bash
# 1. Xcode (required for iOS builds)
# Download from App Store or:
# https://developer.apple.com/download/

xcode-select --install  # Install command line tools

# Verify Xcode installation
xcodebuild -version
# Should show: Xcode 15.2 or later

# 2. CMake (required for building C++ code)
brew install cmake

# Verify CMake
cmake --version
# Should show: cmake version 3.27 or later

# 3. Git (for version control and submodules)
brew install git

# 4. Optional but recommended
brew install ninja  # Faster builds than make
brew install ccache  # Cache compiled objects
```

#### Linux/Windows (for Android development)

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y cmake build-essential git ninja-build

# Verify
cmake --version
```

#### Android NDK (required for Android builds)

```bash
# Option 1: Using Android Studio (recommended)
# Download Android Studio from https://developer.android.com/studio
# Open Android Studio → Preferences → Android SDK → SDK Tools
# Check "NDK (Side by side)" and install

# Option 2: Using sdkmanager
sdkmanager --install "ndk;26.1.10909125"

# Set environment variable
export ANDROID_NDK=$HOME/Library/Android/sdk/ndk/26.1.10909125

# Verify
$ANDROID_NDK/ndk-build --version
```

---

### Repository Setup

#### Step 1: Create Private Repository

```bash
# On GitHub, create private repo: runanywhere-core
# Clone it locally
git clone git@github.com:your-org/runanywhere-core.git
cd runanywhere-core

# Create initial structure
mkdir -p src/{common,backends}
mkdir -p include/runanywhere
mkdir -p third_party
mkdir -p scripts
mkdir -p ci/.github/workflows
mkdir -p dist
mkdir -p plans

# Create .gitignore
cat > .gitignore << 'EOF'
# Build outputs
build/
dist/
*.xcframework/
*.aar

# CMake
CMakeCache.txt
CMakeFiles/
cmake_install.cmake
*.cmake

# IDE
.vscode/
.idea/
*.xcworkspace/
*.xcodeproj/

# macOS
.DS_Store

# Logs
*.log

# Third-party downloads (not submodules)
third_party/_deps/
EOF

# Initial commit
git add .
git commit -m "Initial repository structure"
git push origin main
```

#### Step 2: Add Third-Party Dependencies

**Option A: ONNX Runtime (Pre-built Binaries - Recommended)**

We'll download ONNX Runtime binaries via CMake, so **no submodule needed**.

**Option B: llama.cpp (Git Submodule - If you want it later)**

```bash
# Only if you want llama.cpp
git submodule add https://github.com/ggerganov/llama.cpp third_party/llama.cpp
git submodule update --init --recursive
```

**Add nlohmann/json (Header-only, always needed):**

```bash
git submodule add https://github.com/nlohmann/json third_party/json
git submodule update --init

# Commit submodules
git add .gitmodules third_party/
git commit -m "Add third-party dependencies"
git push
```

---

### CMake Configuration Files

#### Create: `cmake/FetchONNXRuntime.cmake`

```cmake
include(FetchContent)

set(ONNX_VERSION "1.17.1")

message(STATUS "Fetching ONNX Runtime v${ONNX_VERSION}")

if(IOS)
    # iOS XCFramework
    set(ONNX_URL "https://github.com/microsoft/onnxruntime/releases/download/v${ONNX_VERSION}/onnxruntime-mobile-c-ios-xcframework-${ONNX_VERSION}.zip")

    FetchContent_Declare(
        onnxruntime
        URL ${ONNX_URL}
        DOWNLOAD_EXTRACT_TIMESTAMP TRUE
    )

    FetchContent_MakeAvailable(onnxruntime)

    # Create imported target
    add_library(onnxruntime INTERFACE IMPORTED)
    target_link_libraries(onnxruntime INTERFACE
        "-framework ${onnxruntime_SOURCE_DIR}/onnxruntime.xcframework"
    )
    target_include_directories(onnxruntime INTERFACE
        "${onnxruntime_SOURCE_DIR}/Headers"
    )

elseif(APPLE)
    # macOS
    set(ONNX_URL "https://github.com/microsoft/onnxruntime/releases/download/v${ONNX_VERSION}/onnxruntime-osx-universal2-${ONNX_VERSION}.tgz")

    FetchContent_Declare(
        onnxruntime
        URL ${ONNX_URL}
        DOWNLOAD_EXTRACT_TIMESTAMP TRUE
    )

    FetchContent_MakeAvailable(onnxruntime)

    add_library(onnxruntime SHARED IMPORTED)
    set_target_properties(onnxruntime PROPERTIES
        IMPORTED_LOCATION "${onnxruntime_SOURCE_DIR}/lib/libonnxruntime.dylib"
    )
    target_include_directories(onnxruntime INTERFACE
        "${onnxruntime_SOURCE_DIR}/include"
    )

elseif(ANDROID)
    # Android - we'll use Maven dependency instead
    # See android/build.gradle.kts
    message(STATUS "ONNX Runtime for Android will be fetched via Gradle")
endif()
```

#### Create: `CMakeLists.txt` (Root)

```cmake
cmake_minimum_required(VERSION 3.22)
project(RunAnywhereCore VERSION 1.0.0 LANGUAGES CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Build options
option(RA_BUILD_ONNX "Build ONNX Runtime backend" OFF)
option(RA_BUILD_LLAMACPP "Build LlamaCPP backend" OFF)
option(RA_BUILD_COREML "Build CoreML backend" OFF)

# Platform detection
if(IOS)
    message(STATUS "Building for iOS")
    set(RA_PLATFORM_IOS TRUE)
elseif(APPLE)
    message(STATUS "Building for macOS")
    set(RA_PLATFORM_MACOS TRUE)
elseif(ANDROID)
    message(STATUS "Building for Android")
    set(RA_PLATFORM_ANDROID TRUE)
endif()

#===============================================================================
# Third-party dependencies
#===============================================================================

# nlohmann/json (always needed)
message(STATUS "Adding nlohmann/json")
set(JSON_BuildTests OFF CACHE BOOL "" FORCE)
add_subdirectory(third_party/json)

# ONNX Runtime (downloaded on demand)
if(RA_BUILD_ONNX)
    include(cmake/FetchONNXRuntime.cmake)
endif()

# llama.cpp (if submodule exists)
if(RA_BUILD_LLAMACPP AND EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/llama.cpp/CMakeLists.txt")
    message(STATUS "Adding llama.cpp")
    set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)

    if(APPLE)
        set(LLAMA_METAL ON CACHE BOOL "" FORCE)
    endif()

    add_subdirectory(third_party/llama.cpp)
endif()

#===============================================================================
# Backends
#===============================================================================

if(RA_BUILD_ONNX)
    add_subdirectory(src/backends/onnx)
endif()

if(RA_BUILD_LLAMACPP)
    add_subdirectory(src/backends/llamacpp)
endif()

if(RA_BUILD_COREML)
    add_subdirectory(src/backends/coreml)
endif()
```

---

### Verify Setup

```bash
# Test CMake configuration (dry run)
cmake -B build/test \
    -DCMAKE_BUILD_TYPE=Debug \
    -DRA_BUILD_ONNX=ON \
    .

# Should output:
# -- Building for macOS (or iOS)
# -- Adding nlohmann/json
# -- Fetching ONNX Runtime v1.17.1
# -- Configuring done
# -- Generating done

# Clean up test
rm -rf build/test
```

---

### Environment Variables (Add to ~/.zshrc or ~/.bashrc)

```bash
# Add to your shell config
export ANDROID_NDK=$HOME/Library/Android/sdk/ndk/26.1.10909125
export ANDROID_HOME=$HOME/Library/Android/sdk

# Optional: Speed up builds
export CCACHE_DIR=$HOME/.ccache
export CMAKE_GENERATOR=Ninja  # Use Ninja instead of Make
```

**Reload shell:**
```bash
source ~/.zshrc  # or source ~/.bashrc
```

---

## Quick Start: ONNX-First Path

**You're starting with ONNX Runtime first!** Here's the streamlined path:

### Phase 0: Setup (Day 1)

```bash
# 1. Clone your private repo
git clone git@github.com:your-org/runanywhere-core.git
cd runanywhere-core

# 2. Add dependencies
git submodule add https://github.com/nlohmann/json third_party/json
git submodule update --init

# 3. Create CMake files
# (Copy the CMakeLists.txt and cmake/FetchONNXRuntime.cmake from above)

# 4. Commit
git add .
git commit -m "Setup ONNX backend infrastructure"
git push
```

### Phase 1: ONNX Backend (Week 1-2)

#### Week 1: Backend Implementation

**Day 1-2: Common Interface**

Create the backend interface that ONNX will implement:

```bash
# Create files
touch src/common/backend_interface.h
touch src/common/telemetry.h
touch src/common/telemetry.cpp
touch src/common/types.h
```

**Copy the code from the [Implementation Details](#implementation-details) section below.**

**Day 3-5: ONNX Backend**

```bash
# Create ONNX backend structure
mkdir -p src/backends/onnx/backend
mkdir -p src/backends/onnx/bridge/ios
mkdir -p src/backends/onnx/tests

# Create files
touch src/backends/onnx/backend/onnx_backend.h
touch src/backends/onnx/backend/onnx_backend.cpp
touch src/backends/onnx/bridge/ios/onnx_bridge.h
touch src/backends/onnx/bridge/ios/onnx_bridge.cpp
touch src/backends/onnx/CMakeLists.txt
```

**Implementation:** See ONNX implementation in [ONNX Backend Section](#onnx-backend-implementation) below.

#### Week 2: Build & Test

**Day 1-2: iOS Build**

```bash
# Create build script
touch scripts/build-ios-onnx.sh
chmod +x scripts/build-ios-onnx.sh

# Build for iOS
./scripts/build-ios-onnx.sh

# Output: dist/ios/RunAnywhereONNX.xcframework
```

**Day 3-4: Public Swift SDK**

Create public repo: `runanywhere-swift`

```bash
# In a separate directory
mkdir runanywhere-swift
cd runanywhere-swift

swift package init --type library --name RunAnywhere

# Create structure
mkdir -p Sources/RunAnywhereONNX
touch Sources/RunAnywhereONNX/ONNXRuntime.swift
touch Sources/RunAnywhereONNX/ONNXModel.swift
```

**Day 5: Integration Test**

Create example iOS app that uses your ONNX backend!

---

### ONNX Backend Implementation

#### File: `src/backends/onnx/backend/onnx_backend.h`

```cpp
#pragma once

#include "common/backend_interface.h"
#include <onnxruntime_cxx_api.h>
#include <memory>
#include <vector>

namespace runanywhere {

class ONNXBackend : public BackendInterface {
private:
    std::unique_ptr<Ort::Env> env_;
    std::unique_ptr<Ort::Session> session_;
    Ort::SessionOptions session_options_;

    bool loaded_ = false;
    std::string model_path_;
    TelemetryCollector telemetry_;

public:
    ONNXBackend();
    ~ONNXBackend() override;

    // BackendInterface implementation
    BackendType get_type() const override;
    std::string get_name() const override;
    std::string get_version() const override;
    BackendCapabilities get_capabilities() const override;
    DeviceType get_device_type() const override;

    bool load_model(const std::string& path, const std::string& config) override;
    bool unload_model() override;
    bool is_model_loaded() const override;

    InferenceResult infer(const InferenceRequest& request) override;
    void infer_stream(
        const InferenceRequest& request,
        std::function<void(const std::string&)> callback
    ) override;

    void cancel_inference() override;
    size_t get_memory_usage_bytes() const override;
    void set_memory_budget_bytes(size_t budget) override;
    void set_num_threads(int threads) override;
    void warm_up() override;
    void set_telemetry_callback(
        std::function<void(const TelemetryEvent&)> callback
    ) override;
};

} // namespace runanywhere
```

#### File: `src/backends/onnx/CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.22)
project(RunAnywhereONNX)

# Backend implementation
add_library(runanywhere_onnx_backend STATIC
    backend/onnx_backend.cpp
    ${PROJECT_SOURCE_DIR}/../../common/telemetry.cpp
)

target_include_directories(runanywhere_onnx_backend
    PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}
    PRIVATE ${PROJECT_SOURCE_DIR}/../../common
)

target_link_libraries(runanywhere_onnx_backend
    PRIVATE onnxruntime
)

# iOS Bridge
if(IOS OR APPLE)
    add_library(runanywhere_onnx_bridge STATIC
        bridge/ios/onnx_bridge.cpp
    )

    target_link_libraries(runanywhere_onnx_bridge
        PUBLIC runanywhere_onnx_backend
    )

    # Final library
    add_library(runanywhere_onnx STATIC)
    target_link_libraries(runanywhere_onnx
        PUBLIC
            runanywhere_onnx_backend
            runanywhere_onnx_bridge
            onnxruntime
            "-framework Foundation"
            "-framework CoreML"
    )
endif()
```

#### File: `scripts/build-ios-onnx.sh`

```bash
#!/bin/bash
set -e

VERSION="1.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
OUTPUT_DIR="$PROJECT_DIR/dist/ios"

echo "🔨 Building RunAnywhereONNX for iOS"

# Clean
rm -rf "$PROJECT_DIR/build/ios-onnx-"*
mkdir -p "$OUTPUT_DIR"

# Build for iOS device (arm64)
echo "📱 Building for iOS device..."
cmake -B "$PROJECT_DIR/build/ios-onnx-device" \
    -G Xcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=14.0 \
    -DCMAKE_BUILD_TYPE=Release \
    -DRA_BUILD_ONNX=ON \
    "$PROJECT_DIR"

cmake --build "$PROJECT_DIR/build/ios-onnx-device" \
    --config Release \
    --parallel

# Build for iOS simulator
echo "🖥️  Building for simulator..."
cmake -B "$PROJECT_DIR/build/ios-onnx-sim" \
    -G Xcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
    -DCMAKE_OSX_SYSROOT=iphonesimulator \
    -DRA_BUILD_ONNX=ON \
    "$PROJECT_DIR"

cmake --build "$PROJECT_DIR/build/ios-onnx-sim" \
    --config Release \
    --parallel

# Create XCFramework
echo "📦 Creating XCFramework..."
xcodebuild -create-xcframework \
    -library "$PROJECT_DIR/build/ios-onnx-device/src/backends/onnx/Release-iphoneos/librunanywhere_onnx.a" \
    -headers "$PROJECT_DIR/src/backends/onnx/bridge/ios" \
    -library "$PROJECT_DIR/build/ios-onnx-sim/src/backends/onnx/Release-iphonesimulator/librunanywhere_onnx.a" \
    -headers "$PROJECT_DIR/src/backends/onnx/bridge/ios" \
    -output "$OUTPUT_DIR/RunAnywhereONNX.xcframework"

# Create zip
cd "$OUTPUT_DIR"
zip -r "RunAnywhereONNX-${VERSION}.xcframework.zip" RunAnywhereONNX.xcframework
shasum -a 256 "RunAnywhereONNX-${VERSION}.xcframework.zip" > "RunAnywhereONNX-${VERSION}.xcframework.zip.sha256"

echo "✅ Build complete!"
echo "📦 Output: $OUTPUT_DIR/RunAnywhereONNX.xcframework"
ls -lh "$OUTPUT_DIR"
```

---

### Testing Your Setup

```bash
# 1. Test CMake configuration
cmake -B build/test -DRA_BUILD_ONNX=ON .

# Should see:
# -- Fetching ONNX Runtime v1.17.1
# -- Configuring done

# 2. Test build (just compile, don't create XCFramework yet)
cmake --build build/test

# 3. Full iOS build
./scripts/build-ios-onnx.sh

# Should output:
# dist/ios/RunAnywhereONNX.xcframework/
```

---

### Checklist: Ready to Start

- [ ] Xcode 15.2+ installed
- [ ] CMake 3.22+ installed
- [ ] Git configured
- [ ] Private repo `runanywhere-core` created
- [ ] `nlohmann/json` submodule added
- [ ] `cmake/FetchONNXRuntime.cmake` created
- [ ] Root `CMakeLists.txt` created
- [ ] `.gitignore` configured
- [ ] Test build succeeds: `cmake -B build/test -DRA_BUILD_ONNX=ON .`

**Once this checklist is complete, you're ready to implement the ONNX backend!**

---

## Overview

### What We're Building

**Three standalone backend modules** that developers can choose from:

```
┌─────────────────────────────────────────┐
│ RunAnywhereLlamaCPP.xcframework         │
│ - LlamaCPP backend (universal fallback) │
│ - Metal acceleration on Apple           │
│ - CPU fallback everywhere                │
│ - Size: ~50 MB                           │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ RunAnywhereCoreML.xcframework           │
│ - CoreML backend (Apple only)           │
│ - Neural Engine acceleration            │
│ - Tiny binary size: ~2 MB                │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ RunAnywhereTFLite.aar                   │
│ - TensorFlow Lite (Android)             │
│ - NNAPI acceleration                     │
│ - Size: ~15 MB                           │
└─────────────────────────────────────────┘
```

### Key Principles

1. ✅ **Standalone**: Each backend is completely independent
2. ✅ **Explicit**: Developer chooses which backend to use
3. ✅ **Common Interface**: All backends share same API shape
4. ✅ **Telemetry**: Collect usage data for Phase 2 policy engine
5. ✅ **Future-Ready**: Designed for easy Phase 2 integration

### What's NOT in Phase 1

- ❌ Policy engine (automatic backend selection)
- ❌ Device detector (advanced capabilities)
- ❌ Runtime switching
- ❌ OTA updates
- ❌ Multi-backend orchestration

**These come in Phase 2 after we have real usage data.**

---

## Architecture

### Simplified Layer Structure

```
┌────────────────────────────────────────────────────┐
│ Public SDKs (Open Source on GitHub)               │
│ - Swift SDK (iOS/macOS)                            │
│ - Kotlin SDK (Android)                             │
│ - Flutter Plugin (iOS/Android/Desktop)             │
│ - Kotlin Multiplatform (iOS/Android unified)       │
└────────────────────────────────────────────────────┘
                          ↓
         All SDKs call the same C Bridge API
                          ↓
┌────────────────────────────────────────────────────┐
│ C Bridge Layer (C API, in binary)                  │
│ - ra_llamacpp_*() functions                        │
│ - ra_coreml_*() functions                          │
│ - ra_tflite_*() functions                          │
│                                                     │
│ NOTE: Plain C API - works with ALL languages!      │
│ Swift imports C, Kotlin uses JNI, Dart uses FFI    │
└────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────┐
│ Backend Implementation (C++, in binary)            │
│ - LlamaCPPBackend (pure C++)                       │
│ - CoreMLBackend (Objective-C++ - internal only)    │
│ - TFLiteBackend (pure C++)                         │
│                                                     │
│ NOTE: Objective-C++ ONLY in CoreML backend to      │
│ call Apple's CoreML framework. NOT exposed to SDKs!│
└────────────────────────────────────────────────────┘
                          ↓
┌────────────────────────────────────────────────────┐
│ Third-Party Libraries (vendored)                   │
│ - llama.cpp                                        │
│ - CoreML.framework                                 │
│ - TensorFlow Lite                                  │
└────────────────────────────────────────────────────┘
```

### Directory Structure Per Backend

Each backend is **completely self-contained**:

```
src/backends/llamacpp/
├── CMakeLists.txt              # Builds only LlamaCPP backend
├── backend/
│   ├── llamacpp_backend.h      # Backend implementation
│   └── llamacpp_backend.cpp
├── bridge/
│   ├── llamacpp_bridge.h       # C API for Swift/Kotlin
│   └── llamacpp_bridge.cpp
├── include/
│   └── runanywhere/
│       └── llamacpp.h          # Public header (shipped)
└── tests/
    └── llamacpp_test.cpp
```

**No shared code between backends** (yet - we'll extract common code later if needed).

---

## Language Usage Clarification

### Why Different Languages in Each Layer

| Layer | Language | Why? |
|-------|----------|------|
| **Public SDKs** | Swift, Kotlin, Dart | Native developer experience per platform |
| **C Bridge** | C | Universal FFI - all languages can call C |
| **LlamaCPP Backend** | C++ | llama.cpp is C++, pure implementation |
| **CoreML Backend** | **Objective-C++** | **ONLY** to call Apple's CoreML framework (Objective-C) |
| **TFLite Backend** | C++ | TensorFlow Lite is C++, pure implementation |

### Important: Objective-C++ is NOT for Swift Support!

**Common Misconception:**
> "We use Objective-C++ to bridge to Swift"

**❌ This is WRONG!**

**Reality:**
> "We use **plain C** to bridge to Swift. Objective-C++ is ONLY used internally in CoreML backend because CoreML.framework is Objective-C."

**The Flow:**

```
Swift SDK
  ↓ imports C headers
C Bridge (ra_llamacpp_*() functions)
  ↓ calls C++ classes
C++ Backend
  ↓ (only for CoreML backend)
Objective-C++ → calls Apple's CoreML.framework
```

### All SDKs Call the Same C Bridge

**Swift (iOS/macOS):**
```swift
// Imports C headers
import RunAnywhereLlamaCPPBinary

// Calls C function
let handle = ra_llamacpp_create()
```

**Kotlin (Android via JNI):**
```kotlin
// JNI wraps C functions
external fun nativeCreate(): Long  // Calls ra_llamacpp_create() via JNI
```

**Flutter (Dart FFI):**
```dart
// FFI binds to C functions
final create = nativeLib
    .lookup<NativeFunction<CreateNative>>('ra_llamacpp_create')
    .asFunction<CreateDart>();
```

**Kotlin Multiplatform:**
```kotlin
// iOS: cinterop (C bindings)
val handle = ra_llamacpp_create()

// Android: JNI (C bindings)
external fun nativeCreate(): Long
```

**All work because they all call the same C API!**

---

## Week-by-Week Implementation Plan

### **Week 1-2: Foundation + LlamaCPP Backend**

**Goal:** Get first backend working end-to-end

#### Week 1: Setup + Core Interface

**Tasks:**
- [ ] Set up private repository (`runanywhere-core`)
- [ ] Add llama.cpp as git submodule
- [ ] Define common backend interface
- [ ] Set up CMake build system
- [ ] Create iOS build scripts

**Deliverables:**
- Repository structure in place
- llama.cpp compiles for iOS
- Basic CMake configuration working

#### Week 2: LlamaCPP Implementation

**Tasks:**
- [ ] Implement LlamaCPPBackend class
- [ ] Create C bridge API
- [ ] Build XCFramework for iOS (device + simulator)
- [ ] Add basic telemetry hooks
- [ ] Write unit tests

**Deliverables:**
- `RunAnywhereLlamaCPP.xcframework` v0.1
- Can load GGUF model and run inference
- Tests pass on iOS simulator

---

### **Week 3-4: CoreML Backend + Public SDK**

**Goal:** Second backend + initial public SDK

#### Week 3: CoreML Backend

**Tasks:**
- [ ] Implement CoreMLBackend class (Objective-C++)
- [ ] Create C bridge for CoreML
- [ ] Build XCFramework
- [ ] Test with mlpackage models
- [ ] Document CoreML-specific configuration

**Deliverables:**
- `RunAnywhereCoreML.xcframework` v0.1
- Can load .mlpackage and run inference
- Tests pass on real iPhone (CoreML needs device)

#### Week 4: Swift Public SDK

**Tasks:**
- [ ] Create public Swift SDK repository
- [ ] Implement `LlamaCPPRuntime.swift` wrapper
- [ ] Implement `CoreMLRuntime.swift` wrapper
- [ ] Set up SPM with binary targets
- [ ] Write Swift examples

**Deliverables:**
- `runanywhere-swift` repository on GitHub
- SPM package with both backends
- Working example app

---

### **Week 5-6: Android LlamaCPP + TFLite**

**Goal:** Android support with two backends

#### Week 5: Android LlamaCPP

**Tasks:**
- [ ] Set up Android NDK build
- [ ] Port LlamaCPP to Android (JNI bridge)
- [ ] Build AAR for multiple ABIs (arm64-v8a, x86_64)
- [ ] Test on Android emulator + real device
- [ ] Gradle integration

**Deliverables:**
- `runanywhere-llamacpp.aar` v0.1
- Works on Android (ARM + x86_64)

#### Week 6: Android TFLite

**Tasks:**
- [ ] Integrate TensorFlow Lite library
- [ ] Implement TFLiteBackend class
- [ ] Create JNI bridge
- [ ] Build AAR
- [ ] Test NNAPI acceleration

**Deliverables:**
- `runanywhere-tflite.aar` v0.1
- NNAPI working on modern Android devices

---

### **Week 7-8: Kotlin SDK + CI/CD**

**Goal:** Android public SDK + automated releases

#### Week 7: Kotlin Public SDK

**Tasks:**
- [ ] Create `runanywhere-android` repository
- [ ] Implement Kotlin wrapper for LlamaCPP
- [ ] Implement Kotlin wrapper for TFLite
- [ ] Gradle publishing setup
- [ ] Android example app

**Deliverables:**
- `runanywhere-android` on GitHub
- Can consume from Gradle
- Working Android example

#### Week 8: CI/CD + Release Infrastructure

**Tasks:**
- [ ] GitHub Actions for iOS builds
- [ ] GitHub Actions for Android builds
- [ ] Set up S3/CDN for binary distribution
- [ ] Checksum generation + verification
- [ ] Create release scripts

**Deliverables:**
- Automated builds on git tag push
- Binaries uploaded to CDN
- Release process documented

---

### **Week 9-10: Polish + Documentation**

**Goal:** Production-ready v1.0 release

#### Week 9: Testing + Bug Fixes

**Tasks:**
- [ ] Comprehensive testing on devices:
  - iOS: iPhone 12, 13, 14, 15 (Pro/non-Pro)
  - Android: Pixel 6/7/8, Samsung S21/S22/S23
- [ ] Performance benchmarking
- [ ] Memory leak checks
- [ ] Crash reporting integration
- [ ] Fix critical bugs

#### Week 10: Documentation + Examples

**Tasks:**
- [ ] API documentation (inline + generated)
- [ ] Integration guides (iOS + Android)
- [ ] Example apps:
  - iOS chat app with LlamaCPP
  - iOS chat app with CoreML
  - Android chat app with TFLite
- [ ] Migration guide (from other libraries)
- [ ] Performance tuning guide

**Deliverables:**
- Complete documentation site
- Production-ready example apps
- Ready for beta users

---

### **Week 11-12: Beta Testing + v1.0 Release**

**Goal:** Public launch

#### Week 11: Beta Program

**Tasks:**
- [ ] Invite 10-20 beta testers
- [ ] Collect feedback
- [ ] Monitor telemetry
- [ ] Fix reported issues
- [ ] Performance optimizations

#### Week 12: v1.0 Launch

**Tasks:**
- [ ] Final testing
- [ ] Create v1.0.0 git tags
- [ ] Publish to CDN
- [ ] Publish public SDKs to GitHub
- [ ] Announcement blog post
- [ ] Social media launch

**Deliverables:**
- 🚀 v1.0.0 public release
- Binaries on CDN
- Public SDKs on GitHub
- Documentation live

---

## Repository Structure

### Private Repository: `runanywhere-core`

```
runanywhere-core/                    # Private repo (closed source)
├── CMakeLists.txt                   # Root build config
├── README.md                        # Internal docs
├── LICENSE                          # Proprietary license
│
├── plans/                           # Planning docs (this file!)
│   ├── phase1-modular-implementation.md
│   └── private-core-architecture.md
│
├── include/                         # Public C headers (shipped in binaries)
│   └── runanywhere/
│       ├── llamacpp.h               # LlamaCPP public API
│       ├── coreml.h                 # CoreML public API
│       ├── tflite.h                 # TFLite public API
│       └── common.h                 # Shared types
│
├── src/
│   ├── common/                      # Shared utilities (not a separate module)
│   │   ├── backend_interface.h      # Abstract interface
│   │   ├── telemetry.h              # Telemetry collector
│   │   ├── telemetry.cpp
│   │   └── types.h                  # Common types
│   │
│   └── backends/
│       ├── llamacpp/                # Standalone backend
│       │   ├── CMakeLists.txt       # Builds RunAnywhereLlamaCPP
│       │   ├── backend/
│       │   │   ├── llamacpp_backend.h
│       │   │   └── llamacpp_backend.cpp
│       │   ├── bridge/
│       │   │   ├── ios/
│       │   │   │   ├── llamacpp_bridge.h
│       │   │   │   └── llamacpp_bridge.cpp
│       │   │   └── android/
│       │   │       ├── llamacpp_jni.h
│       │   │       └── llamacpp_jni.cpp
│       │   └── tests/
│       │       └── llamacpp_test.cpp
│       │
│       ├── coreml/                  # Standalone backend
│       │   ├── CMakeLists.txt       # Builds RunAnywhereCoreML
│       │   ├── backend/
│       │   │   ├── coreml_backend.h
│       │   │   └── coreml_backend.mm   # Objective-C++
│       │   ├── bridge/
│       │   │   ├── coreml_bridge.h
│       │   │   └── coreml_bridge.cpp
│       │   └── tests/
│       │       └── coreml_test.cpp
│       │
│       └── tflite/                  # Standalone backend
│           ├── CMakeLists.txt       # Builds RunAnywhereTFLite
│           ├── backend/
│           │   ├── tflite_backend.h
│           │   └── tflite_backend.cpp
│           ├── bridge/
│           │   ├── tflite_jni.h
│           │   └── tflite_jni.cpp
│           └── tests/
│               └── tflite_test.cpp
│
├── third_party/                     # Vendored dependencies
│   ├── llama.cpp/                   # Git submodule
│   ├── tensorflow-lite/             # Downloaded by CMake
│   └── json/                        # nlohmann/json (header-only)
│
├── scripts/
│   ├── build-ios.sh                 # Build all iOS backends
│   ├── build-ios-llamacpp.sh        # Build only LlamaCPP for iOS
│   ├── build-ios-coreml.sh          # Build only CoreML for iOS
│   ├── build-android.sh             # Build all Android backends
│   ├── build-android-llamacpp.sh    # Build only LlamaCPP for Android
│   ├── build-android-tflite.sh      # Build only TFLite for Android
│   ├── sign-binaries.sh             # Code signing
│   ├── package-release.sh           # Create release artifacts
│   └── upload-to-cdn.sh             # Upload to S3/CDN
│
├── ci/
│   └── .github/
│       └── workflows/
│           ├── build-ios.yml        # iOS CI
│           ├── build-android.yml    # Android CI
│           └── release.yml          # Release automation
│
└── dist/                            # Build output (gitignored)
    ├── ios/
    │   ├── RunAnywhereLlamaCPP.xcframework/
    │   └── RunAnywhereCoreML.xcframework/
    └── android/
        ├── runanywhere-llamacpp.aar
        └── runanywhere-tflite.aar
```

### Public Repository: `runanywhere-swift`

```
runanywhere-swift/                   # Public repo (open source)
├── Package.swift                    # SPM manifest
├── README.md                        # Public documentation
├── LICENSE                          # MIT/Apache license
│
├── Sources/
│   ├── RunAnywhereLlamaCPP/         # LlamaCPP wrapper
│   │   ├── LlamaCPPRuntime.swift
│   │   ├── LlamaCPPModel.swift
│   │   └── LlamaCPPConfig.swift
│   │
│   └── RunAnywhereCoreML/           # CoreML wrapper
│       ├── CoreMLRuntime.swift
│       ├── CoreMLModel.swift
│       └── CoreMLConfig.swift
│
├── Examples/
│   ├── LlamaCPPChat/                # Example iOS app
│   └── CoreMLChat/                  # Example iOS app
│
└── Tests/
    ├── LlamaCPPTests/
    └── CoreMLTests/
```

### Public Repository: `runanywhere-android`

```
runanywhere-android/                 # Public repo (open source)
├── build.gradle.kts
├── settings.gradle.kts
├── README.md
│
├── runanywhere-llamacpp/            # LlamaCPP module
│   ├── build.gradle.kts
│   └── src/main/kotlin/
│       └── ai/runanywhere/llamacpp/
│           ├── LlamaCPPRuntime.kt
│           ├── LlamaCPPModel.kt
│           └── LlamaCPPConfig.kt
│
├── runanywhere-tflite/              # TFLite module
│   ├── build.gradle.kts
│   └── src/main/kotlin/
│       └── ai/runanywhere/tflite/
│           ├── TFLiteRuntime.kt
│           ├── TFLiteModel.kt
│           └── TFLiteConfig.kt
│
└── examples/
    ├── llamacpp-chat/               # Example Android app
    └── tflite-chat/                 # Example Android app
```

---

## Implementation Details

### Common Backend Interface

**File:** `src/common/backend_interface.h`

```cpp
#pragma once

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <cstdint>

namespace runanywhere {

// Forward declarations
struct InferenceRequest;
struct InferenceResult;
struct BackendCapabilities;
struct TelemetryEvent;

//=============================================================================
// Enums
//=============================================================================

enum class BackendType {
    LLAMA_CPP,
    CORE_ML,
    TFLITE,
    ONNX_RUNTIME
};

enum class DeviceType {
    CPU,
    GPU,
    NPU,      // Neural Processing Unit (generic)
    ANE,      // Apple Neural Engine
    DSP,      // Hexagon DSP
    NNAPI     // Android NNAPI
};

enum class InferenceStatus {
    SUCCESS,
    ERROR_MODEL_NOT_LOADED,
    ERROR_INVALID_INPUT,
    ERROR_INFERENCE_FAILED,
    ERROR_OUT_OF_MEMORY
};

//=============================================================================
// Data Structures
//=============================================================================

struct InferenceRequest {
    std::string prompt;
    int max_tokens = 100;
    float temperature = 0.7f;
    float top_p = 0.9f;
    int top_k = 40;
    std::vector<std::string> stop_sequences;

    // Metadata for telemetry
    std::string session_id;
    std::string user_id;
};

struct InferenceResult {
    InferenceStatus status;
    std::string output;
    std::string error_message;

    // Performance metrics
    int64_t latency_ms = 0;
    int tokens_generated = 0;
    float tokens_per_second = 0.0f;

    // Resource usage
    size_t memory_used_bytes = 0;
    float battery_drain_percent = 0.0f;
    bool thermal_throttled = false;
};

struct BackendCapabilities {
    BackendType backend_type;
    DeviceType device_type;

    bool supports_streaming = false;
    bool supports_quantization = false;
    bool supports_batching = false;

    std::vector<std::string> supported_quantizations;
    size_t max_context_length = 2048;
    size_t recommended_max_tokens = 512;
};

struct TelemetryEvent {
    std::string event_type;  // "inference", "model_load", "error"
    std::string backend_name;
    std::string device_model;
    std::string os_version;

    int64_t timestamp_ms;
    std::string session_id;
    std::string model_id;

    // Event-specific data (JSON string)
    std::string data;
};

//=============================================================================
// Abstract Backend Interface
//=============================================================================

/**
 * All backends MUST implement this interface.
 * This allows future policy engine to work with any backend uniformly.
 */
class BackendInterface {
public:
    virtual ~BackendInterface() = default;

    //=========================================================================
    // Identification
    //=========================================================================

    virtual BackendType get_type() const = 0;
    virtual std::string get_name() const = 0;
    virtual std::string get_version() const = 0;

    //=========================================================================
    // Capabilities (for Phase 2 policy engine)
    //=========================================================================

    virtual BackendCapabilities get_capabilities() const = 0;
    virtual DeviceType get_device_type() const = 0;

    //=========================================================================
    // Model Lifecycle
    //=========================================================================

    /**
     * Load a model from file path.
     *
     * @param model_path Path to model file (GGUF, mlpackage, tflite, etc.)
     * @param config_json Optional JSON configuration string
     * @return true if loaded successfully
     */
    virtual bool load_model(
        const std::string& model_path,
        const std::string& config_json = ""
    ) = 0;

    /**
     * Unload currently loaded model and free resources.
     */
    virtual bool unload_model() = 0;

    /**
     * Check if a model is currently loaded.
     */
    virtual bool is_model_loaded() const = 0;

    //=========================================================================
    // Inference
    //=========================================================================

    /**
     * Run synchronous inference.
     * Blocks until complete.
     */
    virtual InferenceResult infer(const InferenceRequest& request) = 0;

    /**
     * Run streaming inference.
     * Callback is called for each generated token.
     *
     * @param request Inference configuration
     * @param callback Called with each token as it's generated
     */
    virtual void infer_stream(
        const InferenceRequest& request,
        std::function<void(const std::string& token)> callback
    ) = 0;

    /**
     * Cancel ongoing inference (if streaming).
     */
    virtual void cancel_inference() = 0;

    //=========================================================================
    // Resource Management
    //=========================================================================

    /**
     * Get current memory usage in bytes.
     */
    virtual size_t get_memory_usage_bytes() const = 0;

    /**
     * Set memory budget (backend may adjust context size).
     */
    virtual void set_memory_budget_bytes(size_t budget) = 0;

    /**
     * Set number of threads (for CPU backends).
     */
    virtual void set_num_threads(int threads) = 0;

    /**
     * Warm up backend (compile shaders, etc.).
     * Call once after loading model.
     */
    virtual void warm_up() = 0;

    //=========================================================================
    // Telemetry (for Phase 2 data collection)
    //=========================================================================

    /**
     * Set telemetry callback.
     * Backend will call this for important events.
     */
    virtual void set_telemetry_callback(
        std::function<void(const TelemetryEvent&)> callback
    ) = 0;
};

//=============================================================================
// Telemetry Helper
//=============================================================================

/**
 * Simple telemetry collector.
 * Backends use this to report events.
 */
class TelemetryCollector {
private:
    std::function<void(const TelemetryEvent&)> callback_;
    std::string session_id_;

public:
    TelemetryCollector();

    void set_callback(std::function<void(const TelemetryEvent&)> callback);
    void set_session_id(const std::string& session_id);

    void record_inference(
        const std::string& backend_name,
        const InferenceResult& result,
        const std::string& model_id
    );

    void record_model_load(
        const std::string& backend_name,
        const std::string& model_path,
        int64_t load_time_ms,
        bool success
    );

    void record_error(
        const std::string& backend_name,
        const std::string& error_message,
        const std::string& error_type
    );
};

} // namespace runanywhere
```

**File:** `src/common/telemetry.cpp`

```cpp
#include "telemetry.h"
#include <chrono>
#include <sstream>

#ifdef __APPLE__
#include <sys/utsname.h>
#import <Foundation/Foundation.h>
#ifdef TARGET_OS_IOS
#import <UIKit/UIKit.h>
#endif
#endif

#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

namespace runanywhere {

namespace {

std::string get_device_model() {
#ifdef __APPLE__
    struct utsname info;
    uname(&info);
    return std::string(info.machine);
#elif defined(__ANDROID__)
    char model[PROP_VALUE_MAX];
    __system_property_get("ro.product.model", model);
    return std::string(model);
#else
    return "unknown";
#endif
}

std::string get_os_version() {
#ifdef __APPLE__
    #ifdef TARGET_OS_IOS
    NSString* version = [[UIDevice currentDevice] systemVersion];
    return std::string([version UTF8String]);
    #else
    NSOperatingSystemVersion version = [[NSProcessInfo processInfo] operatingSystemVersion];
    std::ostringstream oss;
    oss << version.majorVersion << "." << version.minorVersion << "." << version.patchVersion;
    return oss.str();
    #endif
#elif defined(__ANDROID__)
    char version[PROP_VALUE_MAX];
    __system_property_get("ro.build.version.release", version);
    return std::string(version);
#else
    return "unknown";
#endif
}

int64_t current_timestamp_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(
        system_clock::now().time_since_epoch()
    ).count();
}

std::string generate_session_id() {
    // Simple random ID (use better UUID in production)
    std::ostringstream oss;
    oss << "session_" << current_timestamp_ms();
    return oss.str();
}

} // anonymous namespace

TelemetryCollector::TelemetryCollector()
    : session_id_(generate_session_id())
{
}

void TelemetryCollector::set_callback(
    std::function<void(const TelemetryEvent&)> callback
) {
    callback_ = callback;
}

void TelemetryCollector::set_session_id(const std::string& session_id) {
    session_id_ = session_id;
}

void TelemetryCollector::record_inference(
    const std::string& backend_name,
    const InferenceResult& result,
    const std::string& model_id
) {
    if (!callback_) return;

    // Build JSON data
    std::ostringstream data;
    data << "{"
         << "\"latency_ms\":" << result.latency_ms << ","
         << "\"tokens_generated\":" << result.tokens_generated << ","
         << "\"tokens_per_second\":" << result.tokens_per_second << ","
         << "\"memory_used_mb\":" << (result.memory_used_bytes / 1024.0 / 1024.0) << ","
         << "\"battery_drain_percent\":" << result.battery_drain_percent << ","
         << "\"thermal_throttled\":" << (result.thermal_throttled ? "true" : "false") << ","
         << "\"status\":\"" << static_cast<int>(result.status) << "\""
         << "}";

    TelemetryEvent event{
        .event_type = "inference",
        .backend_name = backend_name,
        .device_model = get_device_model(),
        .os_version = get_os_version(),
        .timestamp_ms = current_timestamp_ms(),
        .session_id = session_id_,
        .model_id = model_id,
        .data = data.str()
    };

    callback_(event);
}

void TelemetryCollector::record_model_load(
    const std::string& backend_name,
    const std::string& model_path,
    int64_t load_time_ms,
    bool success
) {
    if (!callback_) return;

    std::ostringstream data;
    data << "{"
         << "\"model_path\":\"" << model_path << "\","
         << "\"load_time_ms\":" << load_time_ms << ","
         << "\"success\":" << (success ? "true" : "false")
         << "}";

    TelemetryEvent event{
        .event_type = "model_load",
        .backend_name = backend_name,
        .device_model = get_device_model(),
        .os_version = get_os_version(),
        .timestamp_ms = current_timestamp_ms(),
        .session_id = session_id_,
        .model_id = model_path,
        .data = data.str()
    };

    callback_(event);
}

void TelemetryCollector::record_error(
    const std::string& backend_name,
    const std::string& error_message,
    const std::string& error_type
) {
    if (!callback_) return;

    std::ostringstream data;
    data << "{"
         << "\"error_type\":\"" << error_type << "\","
         << "\"error_message\":\"" << error_message << "\""
         << "}";

    TelemetryEvent event{
        .event_type = "error",
        .backend_name = backend_name,
        .device_model = get_device_model(),
        .os_version = get_os_version(),
        .timestamp_ms = current_timestamp_ms(),
        .session_id = session_id_,
        .model_id = "",
        .data = data.str()
    };

    callback_(event);
}

} // namespace runanywhere
```

---

### LlamaCPP Backend Implementation

**File:** `src/backends/llamacpp/backend/llamacpp_backend.h`

```cpp
#pragma once

#include "common/backend_interface.h"
#include "llama.h"  // From third_party/llama.cpp
#include <memory>
#include <vector>
#include <string>
#include <atomic>

namespace runanywhere {

class LlamaCPPBackend : public BackendInterface {
private:
    // llama.cpp handles
    llama_model* model_ = nullptr;
    llama_context* ctx_ = nullptr;

    // Configuration
    llama_model_params model_params_;
    llama_context_params ctx_params_;

    // State
    bool loaded_ = false;
    std::atomic<bool> inference_cancelled_{false};
    std::string loaded_model_path_;

    // Telemetry
    TelemetryCollector telemetry_;

    // Resource limits
    size_t memory_budget_bytes_ = 0;

public:
    LlamaCPPBackend();
    ~LlamaCPPBackend() override;

    // Disable copy/move
    LlamaCPPBackend(const LlamaCPPBackend&) = delete;
    LlamaCPPBackend& operator=(const LlamaCPPBackend&) = delete;

    //=========================================================================
    // BackendInterface Implementation
    //=========================================================================

    BackendType get_type() const override;
    std::string get_name() const override;
    std::string get_version() const override;

    BackendCapabilities get_capabilities() const override;
    DeviceType get_device_type() const override;

    bool load_model(
        const std::string& model_path,
        const std::string& config_json = ""
    ) override;

    bool unload_model() override;
    bool is_model_loaded() const override;

    InferenceResult infer(const InferenceRequest& request) override;

    void infer_stream(
        const InferenceRequest& request,
        std::function<void(const std::string&)> callback
    ) override;

    void cancel_inference() override;

    size_t get_memory_usage_bytes() const override;
    void set_memory_budget_bytes(size_t budget) override;
    void set_num_threads(int threads) override;
    void warm_up() override;

    void set_telemetry_callback(
        std::function<void(const TelemetryEvent&)> callback
    ) override;

private:
    //=========================================================================
    // Helper Methods
    //=========================================================================

    void apply_config(const std::string& config_json);

    std::vector<llama_token> tokenize(
        const std::string& text,
        bool add_bos = true
    );

    std::string detokenize(const std::vector<llama_token>& tokens);

    llama_token sample_token(
        float temperature,
        float top_p,
        int top_k
    );

    bool should_stop(
        const std::string& generated_text,
        const std::vector<std::string>& stop_sequences
    );

    size_t estimate_memory_usage() const;
};

} // namespace runanywhere
```

**File:** `src/backends/llamacpp/backend/llamacpp_backend.cpp`

```cpp
#include "llamacpp_backend.h"
#include "nlohmann/json.hpp"
#include <chrono>
#include <sstream>
#include <cstring>

using json = nlohmann::json;

namespace runanywhere {

namespace {

// Convert llama.cpp build number to version string
std::string get_llama_version() {
    return std::to_string(LLAMA_BUILD_NUMBER);
}

} // anonymous namespace

LlamaCPPBackend::LlamaCPPBackend() {
    // Initialize default parameters
    model_params_ = llama_model_default_params();
    ctx_params_ = llama_context_default_params();

    // Sensible defaults
    ctx_params_.n_ctx = 2048;
    ctx_params_.n_batch = 512;
    ctx_params_.n_threads = 4;

#ifdef __APPLE__
    // Enable Metal on Apple platforms
    model_params_.n_gpu_layers = 999;  // Offload all layers
#endif
}

LlamaCPPBackend::~LlamaCPPBackend() {
    unload_model();
}

//=============================================================================
// Identification
//=============================================================================

BackendType LlamaCPPBackend::get_type() const {
    return BackendType::LLAMA_CPP;
}

std::string LlamaCPPBackend::get_name() const {
    return "llama.cpp";
}

std::string LlamaCPPBackend::get_version() const {
    return get_llama_version();
}

//=============================================================================
// Capabilities
//=============================================================================

BackendCapabilities LlamaCPPBackend::get_capabilities() const {
    BackendCapabilities caps;
    caps.backend_type = BackendType::LLAMA_CPP;
    caps.device_type = get_device_type();
    caps.supports_streaming = true;
    caps.supports_quantization = true;
    caps.supports_batching = false;  // Not in Phase 1

    caps.supported_quantizations = {
        "Q4_0", "Q4_1", "Q4_K_S", "Q4_K_M",
        "Q5_0", "Q5_1", "Q5_K_S", "Q5_K_M",
        "Q6_K", "Q8_0", "F16", "F32"
    };

    caps.max_context_length = ctx_params_.n_ctx;
    caps.recommended_max_tokens = 512;

    return caps;
}

DeviceType LlamaCPPBackend::get_device_type() const {
#ifdef __APPLE__
    // Check if using Metal
    if (model_params_.n_gpu_layers > 0) {
        return DeviceType::GPU;  // Metal
    }
#endif

    return DeviceType::CPU;
}

//=============================================================================
// Model Lifecycle
//=============================================================================

bool LlamaCPPBackend::load_model(
    const std::string& model_path,
    const std::string& config_json
) {
    auto load_start = std::chrono::steady_clock::now();

    // Unload existing model
    if (loaded_) {
        unload_model();
    }

    // Apply configuration
    if (!config_json.empty()) {
        apply_config(config_json);
    }

    // Initialize llama.cpp backend
    llama_backend_init();

    // Load model
    model_ = llama_load_model_from_file(model_path.c_str(), model_params_);
    if (!model_) {
        auto load_end = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            load_end - load_start
        );

        telemetry_.record_model_load(
            get_name(),
            model_path,
            duration.count(),
            false
        );

        return false;
    }

    // Create context
    ctx_ = llama_new_context_with_model(model_, ctx_params_);
    if (!ctx_) {
        llama_free_model(model_);
        model_ = nullptr;

        auto load_end = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            load_end - load_start
        );

        telemetry_.record_model_load(
            get_name(),
            model_path,
            duration.count(),
            false
        );

        return false;
    }

    loaded_ = true;
    loaded_model_path_ = model_path;

    auto load_end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
        load_end - load_start
    );

    telemetry_.record_model_load(
        get_name(),
        model_path,
        duration.count(),
        true
    );

    return true;
}

bool LlamaCPPBackend::unload_model() {
    if (!loaded_) return true;

    if (ctx_) {
        llama_free(ctx_);
        ctx_ = nullptr;
    }

    if (model_) {
        llama_free_model(model_);
        model_ = nullptr;
    }

    llama_backend_free();

    loaded_ = false;
    loaded_model_path_.clear();

    return true;
}

bool LlamaCPPBackend::is_model_loaded() const {
    return loaded_;
}

//=============================================================================
// Inference
//=============================================================================

InferenceResult LlamaCPPBackend::infer(const InferenceRequest& request) {
    InferenceResult result;
    result.status = InferenceStatus::SUCCESS;

    if (!loaded_) {
        result.status = InferenceStatus::ERROR_MODEL_NOT_LOADED;
        result.error_message = "Model not loaded";
        return result;
    }

    auto start = std::chrono::steady_clock::now();
    inference_cancelled_ = false;

    try {
        // Tokenize prompt
        auto tokens = tokenize(request.prompt, true);
        if (tokens.empty()) {
            result.status = InferenceStatus::ERROR_INVALID_INPUT;
            result.error_message = "Failed to tokenize prompt";
            return result;
        }

        // Check context size
        if (tokens.size() + request.max_tokens > ctx_params_.n_ctx) {
            result.status = InferenceStatus::ERROR_INVALID_INPUT;
            result.error_message = "Prompt + max_tokens exceeds context size";
            return result;
        }

        // Evaluate prompt (prefill)
        llama_batch batch = llama_batch_get_one(
            tokens.data(),
            tokens.size(),
            0,  // pos
            0   // seq_id
        );

        if (llama_decode(ctx_, batch) != 0) {
            result.status = InferenceStatus::ERROR_INFERENCE_FAILED;
            result.error_message = "Prefill failed";
            return result;
        }

        // Generate tokens
        std::vector<llama_token> generated;
        generated.reserve(request.max_tokens);

        for (int i = 0; i < request.max_tokens && !inference_cancelled_; ++i) {
            // Sample next token
            llama_token next = sample_token(
                request.temperature,
                request.top_p,
                request.top_k
            );

            // Check for EOS
            if (next == llama_token_eos(model_)) {
                break;
            }

            generated.push_back(next);

            // Check stop sequences
            std::string current_output = detokenize(generated);
            if (should_stop(current_output, request.stop_sequences)) {
                break;
            }

            // Decode next token
            batch = llama_batch_get_one(
                &next,
                1,
                tokens.size() + i,
                0
            );

            if (llama_decode(ctx_, batch) != 0) {
                result.status = InferenceStatus::ERROR_INFERENCE_FAILED;
                result.error_message = "Decode failed at token " + std::to_string(i);
                break;
            }
        }

        // Detokenize output
        result.output = detokenize(generated);
        result.tokens_generated = generated.size();

    } catch (const std::exception& e) {
        result.status = InferenceStatus::ERROR_INFERENCE_FAILED;
        result.error_message = std::string("Exception: ") + e.what();

        telemetry_.record_error(
            get_name(),
            e.what(),
            "inference_exception"
        );
    }

    // Calculate metrics
    auto end = std::chrono::steady_clock::now();
    result.latency_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        end - start
    ).count();

    if (result.latency_ms > 0) {
        result.tokens_per_second = (result.tokens_generated * 1000.0f) / result.latency_ms;
    }

    result.memory_used_bytes = get_memory_usage_bytes();

    // Record telemetry
    telemetry_.record_inference(
        get_name(),
        result,
        loaded_model_path_
    );

    return result;
}

void LlamaCPPBackend::infer_stream(
    const InferenceRequest& request,
    std::function<void(const std::string&)> callback
) {
    if (!loaded_ || !callback) return;

    inference_cancelled_ = false;

    try {
        // Tokenize prompt
        auto tokens = tokenize(request.prompt, true);
        if (tokens.empty()) return;

        // Prefill
        llama_batch batch = llama_batch_get_one(
            tokens.data(),
            tokens.size(),
            0,
            0
        );

        if (llama_decode(ctx_, batch) != 0) {
            return;
        }

        // Generate and stream tokens
        for (int i = 0; i < request.max_tokens && !inference_cancelled_; ++i) {
            llama_token next = sample_token(
                request.temperature,
                request.top_p,
                request.top_k
            );

            if (next == llama_token_eos(model_)) {
                break;
            }

            // Convert token to string and callback
            std::string token_str = detokenize({next});
            callback(token_str);

            // Decode next token
            batch = llama_batch_get_one(&next, 1, tokens.size() + i, 0);
            if (llama_decode(ctx_, batch) != 0) {
                break;
            }
        }

    } catch (const std::exception& e) {
        telemetry_.record_error(
            get_name(),
            e.what(),
            "stream_exception"
        );
    }
}

void LlamaCPPBackend::cancel_inference() {
    inference_cancelled_ = true;
}

//=============================================================================
// Resource Management
//=============================================================================

size_t LlamaCPPBackend::get_memory_usage_bytes() const {
    if (!model_ || !ctx_) return 0;

    // Estimate: model size + KV cache size
    size_t model_size = llama_model_size(model_);
    size_t kv_cache_size = llama_get_state_size(ctx_);

    return model_size + kv_cache_size;
}

void LlamaCPPBackend::set_memory_budget_bytes(size_t budget) {
    memory_budget_bytes_ = budget;

    // Could adjust context size based on budget
    // For Phase 1, just store it
}

void LlamaCPPBackend::set_num_threads(int threads) {
    ctx_params_.n_threads = threads;

    // If model already loaded, update context
    if (ctx_) {
        llama_set_n_threads(ctx_, threads, threads);
    }
}

void LlamaCPPBackend::warm_up() {
    if (!loaded_) return;

    // Run dummy inference to warm up Metal shaders
    std::vector<llama_token> dummy = {1, 2, 3};
    llama_batch batch = llama_batch_get_one(dummy.data(), dummy.size(), 0, 0);
    llama_decode(ctx_, batch);
}

void LlamaCPPBackend::set_telemetry_callback(
    std::function<void(const TelemetryEvent&)> callback
) {
    telemetry_.set_callback(callback);
}

//=============================================================================
// Helper Methods
//=============================================================================

void LlamaCPPBackend::apply_config(const std::string& config_json) {
    try {
        auto config = json::parse(config_json);

        if (config.contains("context_size")) {
            ctx_params_.n_ctx = config["context_size"];
        }

        if (config.contains("batch_size")) {
            ctx_params_.n_batch = config["batch_size"];
        }

        if (config.contains("threads")) {
            ctx_params_.n_threads = config["threads"];
        }

        if (config.contains("gpu_layers")) {
            model_params_.n_gpu_layers = config["gpu_layers"];
        }

        if (config.contains("use_mmap")) {
            model_params_.use_mmap = config["use_mmap"];
        }

    } catch (const std::exception& e) {
        // Log error but continue with defaults
        telemetry_.record_error(
            get_name(),
            std::string("Config parse error: ") + e.what(),
            "config_error"
        );
    }
}

std::vector<llama_token> LlamaCPPBackend::tokenize(
    const std::string& text,
    bool add_bos
) {
    if (!model_) return {};

    // Allocate buffer (worst case: 1 token per char + overhead)
    std::vector<llama_token> tokens(text.size() + 16);

    int n_tokens = llama_tokenize(
        model_,
        text.c_str(),
        text.size(),
        tokens.data(),
        tokens.size(),
        add_bos,
        true  // special tokens
    );

    if (n_tokens < 0) {
        // Buffer too small, resize and retry
        tokens.resize(-n_tokens);
        n_tokens = llama_tokenize(
            model_,
            text.c_str(),
            text.size(),
            tokens.data(),
            tokens.size(),
            add_bos,
            true
        );
    }

    tokens.resize(n_tokens);
    return tokens;
}

std::string LlamaCPPBackend::detokenize(
    const std::vector<llama_token>& tokens
) {
    if (!model_ || tokens.empty()) return "";

    std::string result;
    result.reserve(tokens.size() * 4);  // Rough estimate

    for (llama_token token : tokens) {
        const char* piece = llama_token_to_piece(model_, token);
        if (piece) {
            result += piece;
        }
    }

    return result;
}

llama_token LlamaCPPBackend::sample_token(
    float temperature,
    float top_p,
    int top_k
) {
    if (!ctx_) return 0;

    float* logits = llama_get_logits(ctx_);
    int n_vocab = llama_n_vocab(model_);

    // For Phase 1: Simple greedy sampling
    // TODO Phase 2: Implement proper sampling with temperature/top_p/top_k

    llama_token max_token = 0;
    float max_logit = logits[0];

    for (int i = 1; i < n_vocab; ++i) {
        if (logits[i] > max_logit) {
            max_logit = logits[i];
            max_token = i;
        }
    }

    return max_token;
}

bool LlamaCPPBackend::should_stop(
    const std::string& generated_text,
    const std::vector<std::string>& stop_sequences
) {
    for (const auto& stop : stop_sequences) {
        if (generated_text.find(stop) != std::string::npos) {
            return true;
        }
    }
    return false;
}

} // namespace runanywhere
```

---

### LlamaCPP iOS Bridge

**File:** `src/backends/llamacpp/bridge/ios/llamacpp_bridge.h`

```cpp
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

//=============================================================================
// Opaque Handles
//=============================================================================

typedef void* ra_llamacpp_handle;

//=============================================================================
// Version
//=============================================================================

const char* ra_llamacpp_version(void);

//=============================================================================
// Backend Lifecycle
//=============================================================================

/**
 * Create a new LlamaCPP backend instance.
 * Returns NULL on failure.
 */
ra_llamacpp_handle ra_llamacpp_create(void);

/**
 * Destroy backend instance and free resources.
 */
void ra_llamacpp_destroy(ra_llamacpp_handle handle);

//=============================================================================
// Configuration
//=============================================================================

/**
 * Configure backend with JSON string.
 * Example: {"context_size": 4096, "threads": 8, "gpu_layers": 32}
 *
 * Call before loading model.
 * Returns 0 on success, -1 on error.
 */
int ra_llamacpp_configure(
    ra_llamacpp_handle handle,
    const char* config_json
);

//=============================================================================
// Model Management
//=============================================================================

/**
 * Load a GGUF model from file path.
 * Returns 0 on success, -1 on error.
 */
int ra_llamacpp_load_model(
    ra_llamacpp_handle handle,
    const char* model_path
);

/**
 * Unload currently loaded model.
 * Returns 0 on success.
 */
int ra_llamacpp_unload_model(ra_llamacpp_handle handle);

/**
 * Check if model is loaded.
 * Returns 1 if loaded, 0 if not.
 */
int ra_llamacpp_is_loaded(ra_llamacpp_handle handle);

/**
 * Warm up backend (compile Metal shaders, etc.).
 * Call once after loading model for optimal first inference.
 */
void ra_llamacpp_warm_up(ra_llamacpp_handle handle);

//=============================================================================
// Inference
//=============================================================================

/**
 * Run synchronous inference.
 *
 * @param handle Backend handle
 * @param prompt Input prompt
 * @param max_tokens Maximum tokens to generate
 * @param temperature Sampling temperature (0.0 - 2.0)
 * @param out_result Pointer to receive result JSON string (must free with ra_free_string)
 * @return 0 on success, -1 on error
 *
 * Result JSON format:
 * {
 *   "output": "generated text",
 *   "tokens_generated": 42,
 *   "latency_ms": 1234,
 *   "tokens_per_second": 34.2
 * }
 */
int ra_llamacpp_infer(
    ra_llamacpp_handle handle,
    const char* prompt,
    int max_tokens,
    float temperature,
    char** out_result
);

/**
 * Callback for streaming inference.
 * Called for each generated token.
 */
typedef void (*ra_token_callback)(const char* token, void* user_data);

/**
 * Run streaming inference.
 * Calls callback for each token as it's generated.
 */
void ra_llamacpp_infer_stream(
    ra_llamacpp_handle handle,
    const char* prompt,
    int max_tokens,
    float temperature,
    ra_token_callback callback,
    void* user_data
);

/**
 * Cancel ongoing inference (if streaming).
 */
void ra_llamacpp_cancel(ra_llamacpp_handle handle);

//=============================================================================
// Introspection
//=============================================================================

/**
 * Get current memory usage in bytes.
 */
long ra_llamacpp_memory_usage(ra_llamacpp_handle handle);

/**
 * Get device type being used.
 * Returns: "cpu", "gpu" (Metal), etc.
 */
const char* ra_llamacpp_device_type(ra_llamacpp_handle handle);

//=============================================================================
// Telemetry
//=============================================================================

/**
 * Callback for telemetry events.
 * event_json contains telemetry data in JSON format.
 */
typedef void (*ra_telemetry_callback)(const char* event_json, void* user_data);

/**
 * Set telemetry callback.
 * Backend will call this for important events (inference, errors, etc.).
 */
void ra_llamacpp_set_telemetry_callback(
    ra_llamacpp_handle handle,
    ra_telemetry_callback callback,
    void* user_data
);

//=============================================================================
// Utility
//=============================================================================

/**
 * Free string allocated by C library.
 * Must call this for any char* returned by the library.
 */
void ra_free_string(char* str);

#ifdef __cplusplus
}
#endif
```

**File:** `src/backends/llamacpp/bridge/ios/llamacpp_bridge.cpp`

```cpp
#include "llamacpp_bridge.h"
#include "backend/llamacpp_backend.h"
#include "nlohmann/json.hpp"
#include <cstring>
#include <memory>

using namespace runanywhere;
using json = nlohmann::json;

extern "C" {

//=============================================================================
// Version
//=============================================================================

const char* ra_llamacpp_version() {
    return "1.0.0";
}

//=============================================================================
// Backend Lifecycle
//=============================================================================

ra_llamacpp_handle ra_llamacpp_create() {
    try {
        auto* backend = new LlamaCPPBackend();
        return backend;
    } catch (...) {
        return nullptr;
    }
}

void ra_llamacpp_destroy(ra_llamacpp_handle handle) {
    if (handle) {
        auto* backend = static_cast<LlamaCPPBackend*>(handle);
        delete backend;
    }
}

//=============================================================================
// Configuration
//=============================================================================

int ra_llamacpp_configure(
    ra_llamacpp_handle handle,
    const char* config_json
) {
    if (!handle || !config_json) return -1;

    // Configuration will be applied when model is loaded
    // For now, just validate JSON
    try {
        json::parse(config_json);
        return 0;
    } catch (...) {
        return -1;
    }
}

//=============================================================================
// Model Management
//=============================================================================

int ra_llamacpp_load_model(
    ra_llamacpp_handle handle,
    const char* model_path
) {
    if (!handle || !model_path) return -1;

    try {
        auto* backend = static_cast<LlamaCPPBackend*>(handle);
        bool success = backend->load_model(model_path, "");
        return success ? 0 : -1;
    } catch (...) {
        return -1;
    }
}

int ra_llamacpp_unload_model(ra_llamacpp_handle handle) {
    if (!handle) return -1;

    try {
        auto* backend = static_cast<LlamaCPPBackend*>(handle);
        backend->unload_model();
        return 0;
    } catch (...) {
        return -1;
    }
}

int ra_llamacpp_is_loaded(ra_llamacpp_handle handle) {
    if (!handle) return 0;

    auto* backend = static_cast<LlamaCPPBackend*>(handle);
    return backend->is_model_loaded() ? 1 : 0;
}

void ra_llamacpp_warm_up(ra_llamacpp_handle handle) {
    if (!handle) return;

    auto* backend = static_cast<LlamaCPPBackend*>(handle);
    backend->warm_up();
}

//=============================================================================
// Inference
//=============================================================================

int ra_llamacpp_infer(
    ra_llamacpp_handle handle,
    const char* prompt,
    int max_tokens,
    float temperature,
    char** out_result
) {
    if (!handle || !prompt || !out_result) return -1;

    try {
        auto* backend = static_cast<LlamaCPPBackend*>(handle);

        InferenceRequest request;
        request.prompt = prompt;
        request.max_tokens = max_tokens;
        request.temperature = temperature;

        InferenceResult result = backend->infer(request);

        // Convert result to JSON
        json result_json;
        result_json["status"] = static_cast<int>(result.status);
        result_json["output"] = result.output;
        result_json["error_message"] = result.error_message;
        result_json["tokens_generated"] = result.tokens_generated;
        result_json["latency_ms"] = result.latency_ms;
        result_json["tokens_per_second"] = result.tokens_per_second;
        result_json["memory_used_mb"] = result.memory_used_bytes / 1024.0 / 1024.0;

        std::string result_str = result_json.dump();

        // Allocate and copy string
        *out_result = (char*)malloc(result_str.size() + 1);
        strcpy(*out_result, result_str.c_str());

        return 0;

    } catch (...) {
        return -1;
    }
}

void ra_llamacpp_infer_stream(
    ra_llamacpp_handle handle,
    const char* prompt,
    int max_tokens,
    float temperature,
    ra_token_callback callback,
    void* user_data
) {
    if (!handle || !prompt || !callback) return;

    try {
        auto* backend = static_cast<LlamaCPPBackend*>(handle);

        InferenceRequest request;
        request.prompt = prompt;
        request.max_tokens = max_tokens;
        request.temperature = temperature;

        backend->infer_stream(request, [callback, user_data](const std::string& token) {
            callback(token.c_str(), user_data);
        });

    } catch (...) {
        // Error handling
    }
}

void ra_llamacpp_cancel(ra_llamacpp_handle handle) {
    if (!handle) return;

    auto* backend = static_cast<LlamaCPPBackend*>(handle);
    backend->cancel_inference();
}

//=============================================================================
// Introspection
//=============================================================================

long ra_llamacpp_memory_usage(ra_llamacpp_handle handle) {
    if (!handle) return 0;

    auto* backend = static_cast<LlamaCPPBackend*>(handle);
    return backend->get_memory_usage_bytes();
}

const char* ra_llamacpp_device_type(ra_llamacpp_handle handle) {
    if (!handle) return "unknown";

    auto* backend = static_cast<LlamaCPPBackend*>(handle);
    DeviceType type = backend->get_device_type();

    switch (type) {
        case DeviceType::CPU: return "cpu";
        case DeviceType::GPU: return "gpu";
        case DeviceType::NPU: return "npu";
        case DeviceType::ANE: return "ane";
        default: return "unknown";
    }
}

//=============================================================================
// Telemetry
//=============================================================================

struct TelemetryContext {
    ra_telemetry_callback callback;
    void* user_data;
};

void ra_llamacpp_set_telemetry_callback(
    ra_llamacpp_handle handle,
    ra_telemetry_callback callback,
    void* user_data
) {
    if (!handle || !callback) return;

    auto* backend = static_cast<LlamaCPPBackend*>(handle);

    // Allocate context (will be cleaned up when backend is destroyed)
    auto* ctx = new TelemetryContext{callback, user_data};

    backend->set_telemetry_callback([ctx](const TelemetryEvent& event) {
        // Convert event to JSON
        json event_json;
        event_json["event_type"] = event.event_type;
        event_json["backend_name"] = event.backend_name;
        event_json["device_model"] = event.device_model;
        event_json["os_version"] = event.os_version;
        event_json["timestamp_ms"] = event.timestamp_ms;
        event_json["session_id"] = event.session_id;
        event_json["model_id"] = event.model_id;

        // Parse data field (already JSON)
        try {
            event_json["data"] = json::parse(event.data);
        } catch (...) {
            event_json["data"] = event.data;
        }

        std::string event_str = event_json.dump();
        ctx->callback(event_str.c_str(), ctx->user_data);
    });
}

//=============================================================================
// Utility
//=============================================================================

void ra_free_string(char* str) {
    if (str) {
        free(str);
    }
}

} // extern "C"
```

---

### Swift Public SDK

**File:** `Sources/RunAnywhereLlamaCPP/LlamaCPPRuntime.swift` (in public repo)

```swift
import Foundation

/// LlamaCPP backend runtime for RunAnywhere
public final class LlamaCPPRuntime {
    private let handle: OpaquePointer
    private var telemetryHandler: ((TelemetryEvent) -> Void)?

    /// Configuration for LlamaCPP backend
    public struct Configuration {
        public var contextSize: Int
        public var threads: Int
        public var gpuLayers: Int
        public var useMMap: Bool

        public static let `default` = Configuration(
            contextSize: 2048,
            threads: 4,
            gpuLayers: 999,  // Offload all to Metal
            useMMap: true
        )

        public init(
            contextSize: Int = 2048,
            threads: Int = 4,
            gpuLayers: Int = 999,
            useMMap: Bool = true
        ) {
            self.contextSize = contextSize
            self.threads = threads
            self.gpuLayers = gpuLayers
            self.useMMap = useMMap
        }

        func toJSON() -> String {
            let dict: [String: Any] = [
                "context_size": contextSize,
                "threads": threads,
                "gpu_layers": gpuLayers,
                "use_mmap": useMMap
            ]

            guard let data = try? JSONSerialization.data(withJSONObject: dict),
                  let json = String(data: data, encoding: .utf8) else {
                return "{}"
            }

            return json
        }
    }

    /// Initialize runtime with configuration
    public init(configuration: Configuration = .default) throws {
        guard let handle = ra_llamacpp_create() else {
            throw RunAnywhereError.initializationFailed
        }

        self.handle = handle

        // Apply configuration
        let configJSON = configuration.toJSON()
        let result = ra_llamacpp_configure(handle, configJSON)

        if result != 0 {
            ra_llamacpp_destroy(handle)
            throw RunAnywhereError.configurationFailed
        }
    }

    deinit {
        ra_llamacpp_destroy(handle)
    }

    /// Load a GGUF model from file path
    public func loadModel(path: String) async throws {
        let result = ra_llamacpp_load_model(handle, path)

        if result != 0 {
            throw RunAnywhereError.modelLoadFailed
        }

        // Warm up Metal shaders
        ra_llamacpp_warm_up(handle)
    }

    /// Unload currently loaded model
    public func unloadModel() {
        ra_llamacpp_unload_model(handle)
    }

    /// Check if model is loaded
    public var isModelLoaded: Bool {
        ra_llamacpp_is_loaded(handle) == 1
    }

    /// Run inference synchronously
    public func generate(
        prompt: String,
        maxTokens: Int = 100,
        temperature: Float = 0.7
    ) async throws -> InferenceResult {
        return try await withCheckedThrowingContinuation { continuation in
            var resultPtr: UnsafeMutablePointer<CChar>?
            let status = ra_llamacpp_infer(
                handle,
                prompt,
                Int32(maxTokens),
                temperature,
                &resultPtr
            )

            guard status == 0, let resultPtr = resultPtr else {
                continuation.resume(throwing: RunAnywhereError.inferenceFailed)
                return
            }

            defer { ra_free_string(resultPtr) }

            let resultJSON = String(cString: resultPtr)

            do {
                let result = try InferenceResult.fromJSON(resultJSON)
                continuation.resume(returning: result)
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }

    /// Run streaming inference
    public func generateStream(
        prompt: String,
        maxTokens: Int = 100,
        temperature: Float = 0.7,
        onToken: @escaping (String) -> Void
    ) async {
        await withCheckedContinuation { continuation in
            let context = StreamContext(
                onToken: onToken,
                continuation: continuation
            )

            let contextPtr = Unmanaged.passRetained(context).toOpaque()

            ra_llamacpp_infer_stream(
                handle,
                prompt,
                Int32(maxTokens),
                temperature,
                { tokenPtr, userDataPtr in
                    guard let tokenPtr = tokenPtr,
                          let userDataPtr = userDataPtr else { return }

                    let token = String(cString: tokenPtr)
                    let context = Unmanaged<StreamContext>.fromOpaque(userDataPtr).takeUnretainedValue()
                    context.onToken(token)
                },
                contextPtr
            )

            // Clean up context
            Unmanaged<StreamContext>.fromOpaque(contextPtr).release()
            continuation.resume()
        }
    }

    /// Cancel ongoing inference
    public func cancelInference() {
        ra_llamacpp_cancel(handle)
    }

    /// Get current memory usage in bytes
    public var memoryUsage: Int {
        Int(ra_llamacpp_memory_usage(handle))
    }

    /// Get device type being used
    public var deviceType: String {
        String(cString: ra_llamacpp_device_type(handle))
    }

    /// Set telemetry handler
    public func setTelemetryHandler(_ handler: @escaping (TelemetryEvent) -> Void) {
        self.telemetryHandler = handler

        let contextPtr = Unmanaged.passRetained(self).toOpaque()

        ra_llamacpp_set_telemetry_callback(
            handle,
            { eventPtr, userDataPtr in
                guard let eventPtr = eventPtr,
                      let userDataPtr = userDataPtr else { return }

                let eventJSON = String(cString: eventPtr)
                let runtime = Unmanaged<LlamaCPPRuntime>.fromOpaque(userDataPtr).takeUnretainedValue()

                if let event = try? TelemetryEvent.fromJSON(eventJSON) {
                    runtime.telemetryHandler?(event)
                }
            },
            contextPtr
        )
    }
}

// MARK: - Supporting Types

private class StreamContext {
    let onToken: (String) -> Void
    let continuation: CheckedContinuation<Void, Never>

    init(
        onToken: @escaping (String) -> Void,
        continuation: CheckedContinuation<Void, Never>
    ) {
        self.onToken = onToken
        self.continuation = continuation
    }
}

public struct InferenceResult: Codable {
    public let status: Int
    public let output: String
    public let errorMessage: String
    public let tokensGenerated: Int
    public let latencyMs: Int
    public let tokensPerSecond: Float
    public let memoryUsedMb: Float

    enum CodingKeys: String, CodingKey {
        case status
        case output
        case errorMessage = "error_message"
        case tokensGenerated = "tokens_generated"
        case latencyMs = "latency_ms"
        case tokensPerSecond = "tokens_per_second"
        case memoryUsedMb = "memory_used_mb"
    }

    static func fromJSON(_ json: String) throws -> InferenceResult {
        let data = json.data(using: .utf8)!
        return try JSONDecoder().decode(InferenceResult.self, from: data)
    }
}

public struct TelemetryEvent: Codable {
    public let eventType: String
    public let backendName: String
    public let deviceModel: String
    public let osVersion: String
    public let timestampMs: Int64
    public let sessionId: String
    public let modelId: String
    public let data: [String: AnyCodable]

    enum CodingKeys: String, CodingKey {
        case eventType = "event_type"
        case backendName = "backend_name"
        case deviceModel = "device_model"
        case osVersion = "os_version"
        case timestampMs = "timestamp_ms"
        case sessionId = "session_id"
        case modelId = "model_id"
        case data
    }

    static func fromJSON(_ json: String) throws -> TelemetryEvent {
        let data = json.data(using: .utf8)!
        return try JSONDecoder().decode(TelemetryEvent.self, from: data)
    }
}

// Helper for decoding dynamic JSON
public struct AnyCodable: Codable {
    public let value: Any

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()

        if let int = try? container.decode(Int.self) {
            value = int
        } else if let double = try? container.decode(Double.self) {
            value = double
        } else if let string = try? container.decode(String.self) {
            value = string
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else {
            value = NSNull()
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()

        switch value {
        case let int as Int:
            try container.encode(int)
        case let double as Double:
            try container.encode(double)
        case let string as String:
            try container.encode(string)
        case let bool as Bool:
            try container.encode(bool)
        default:
            try container.encodeNil()
        }
    }
}

public enum RunAnywhereError: Error {
    case initializationFailed
    case configurationFailed
    case modelLoadFailed
    case inferenceFailed
    case invalidResult
}
```

---

### CMake Build System

**File:** `src/backends/llamacpp/CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.22)
project(RunAnywhereLlamaCPP VERSION 1.0.0)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Platform detection
if(IOS OR CMAKE_SYSTEM_NAME STREQUAL "iOS")
    set(RA_PLATFORM_IOS TRUE)
    message(STATUS "Building for iOS")
elseif(ANDROID)
    set(RA_PLATFORM_ANDROID TRUE)
    message(STATUS "Building for Android")
elseif(APPLE)
    set(RA_PLATFORM_MACOS TRUE)
    message(STATUS "Building for macOS")
endif()

#===============================================================================
# Backend Implementation
#===============================================================================

add_library(runanywhere_llamacpp_backend STATIC
    backend/llamacpp_backend.cpp
    ${PROJECT_SOURCE_DIR}/../../common/telemetry.cpp
)

target_include_directories(runanywhere_llamacpp_backend
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}
        ${PROJECT_SOURCE_DIR}/../../common
    PRIVATE
        ${PROJECT_SOURCE_DIR}/../../../third_party/llama.cpp
        ${PROJECT_SOURCE_DIR}/../../../third_party/json/include
)

# Link llama.cpp
target_link_libraries(runanywhere_llamacpp_backend
    PRIVATE
        llama
)

# Platform-specific settings
if(RA_PLATFORM_IOS OR RA_PLATFORM_MACOS)
    # Enable Metal
    target_compile_definitions(runanywhere_llamacpp_backend PRIVATE
        GGML_USE_METAL
    )
    target_link_libraries(runanywhere_llamacpp_backend PRIVATE
        "-framework Foundation"
        "-framework Metal"
        "-framework MetalKit"
    )
endif()

#===============================================================================
# Platform Bridges
#===============================================================================

if(RA_PLATFORM_IOS OR RA_PLATFORM_MACOS)
    # iOS/macOS Bridge
    add_library(runanywhere_llamacpp_bridge STATIC
        bridge/ios/llamacpp_bridge.cpp
    )

    target_link_libraries(runanywhere_llamacpp_bridge
        PUBLIC
            runanywhere_llamacpp_backend
    )

    target_include_directories(runanywhere_llamacpp_bridge
        PUBLIC
            ${CMAKE_CURRENT_SOURCE_DIR}/bridge/ios
    )

    # Combine into final library
    add_library(runanywhere_llamacpp STATIC
        $<TARGET_OBJECTS:runanywhere_llamacpp_backend>
        $<TARGET_OBJECTS:runanywhere_llamacpp_bridge>
    )

    target_link_libraries(runanywhere_llamacpp
        PUBLIC
            llama
            "-framework Foundation"
            "-framework Metal"
            "-framework MetalKit"
    )

elseif(RA_PLATFORM_ANDROID)
    # Android JNI Bridge
    add_library(runanywhere_llamacpp SHARED
        bridge/android/llamacpp_jni.cpp
    )

    target_link_libraries(runanywhere_llamacpp
        PUBLIC
            runanywhere_llamacpp_backend
            llama
            log
            android
    )
endif()

#===============================================================================
# Installation
#===============================================================================

# Install headers for XCFramework
install(FILES
    bridge/ios/llamacpp_bridge.h
    DESTINATION include/runanywhere
)

# Set output name
set_target_properties(runanywhere_llamacpp PROPERTIES
    OUTPUT_NAME "runanywhere_llamacpp"
    VERSION ${PROJECT_VERSION}
)
```

**File:** `CMakeLists.txt` (root)

```cmake
cmake_minimum_required(VERSION 3.22)
project(RunAnywhereCore VERSION 1.0.0 LANGUAGES CXX C)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Options
option(RA_BUILD_LLAMACPP "Build LlamaCPP backend" ON)
option(RA_BUILD_COREML "Build CoreML backend" OFF)
option(RA_BUILD_TFLITE "Build TFLite backend" OFF)

# Auto-enable platform-specific backends
if(IOS OR APPLE)
    set(RA_BUILD_COREML ON CACHE BOOL "" FORCE)
endif()

if(ANDROID)
    set(RA_BUILD_TFLITE ON CACHE BOOL "" FORCE)
endif()

#===============================================================================
# Third-party dependencies
#===============================================================================

# llama.cpp (git submodule)
if(RA_BUILD_LLAMACPP)
    set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)

    if(IOS OR APPLE)
        set(LLAMA_METAL ON CACHE BOOL "" FORCE)
    endif()

    add_subdirectory(third_party/llama.cpp)
endif()

# nlohmann/json (header-only)
set(JSON_BuildTests OFF CACHE BOOL "" FORCE)
add_subdirectory(third_party/json)

#===============================================================================
# Backends
#===============================================================================

if(RA_BUILD_LLAMACPP)
    add_subdirectory(src/backends/llamacpp)
endif()

if(RA_BUILD_COREML)
    add_subdirectory(src/backends/coreml)
endif()

if(RA_BUILD_TFLITE)
    add_subdirectory(src/backends/tflite)
endif()
```

---

### Build Scripts

**File:** `scripts/build-ios-llamacpp.sh`

```bash
#!/bin/bash
set -e

VERSION="1.0.0"
BUILD_TYPE="${BUILD_TYPE:-Release}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
OUTPUT_DIR="$PROJECT_DIR/dist/ios"

echo "🔨 Building RunAnywhereLlamaCPP for iOS (v${VERSION})"

# Clean previous builds
rm -rf "$PROJECT_DIR/build/ios-llamacpp-"* "$OUTPUT_DIR/RunAnywhereLlamaCPP.xcframework"
mkdir -p "$OUTPUT_DIR"

#===============================================================================
# Build for iOS Device (arm64)
#===============================================================================

echo "📱 Building for iOS device (arm64)..."

cmake -B "$PROJECT_DIR/build/ios-llamacpp-device" \
    -G Xcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=14.0 \
    -DCMAKE_BUILD_TYPE=$BUILD_TYPE \
    -DRA_BUILD_LLAMACPP=ON \
    -DRA_BUILD_COREML=OFF \
    -DRA_BUILD_TFLITE=OFF \
    "$PROJECT_DIR"

cmake --build "$PROJECT_DIR/build/ios-llamacpp-device" \
    --config $BUILD_TYPE \
    --parallel

#===============================================================================
# Build for iOS Simulator (arm64 + x86_64)
#===============================================================================

echo "🖥️  Building for iOS simulator (arm64 + x86_64)..."

cmake -B "$PROJECT_DIR/build/ios-llamacpp-simulator" \
    -G Xcode \
    -DCMAKE_SYSTEM_NAME=iOS \
    -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
    -DCMAKE_OSX_SYSROOT=iphonesimulator \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=14.0 \
    -DCMAKE_BUILD_TYPE=$BUILD_TYPE \
    -DRA_BUILD_LLAMACPP=ON \
    -DRA_BUILD_COREML=OFF \
    -DRA_BUILD_TFLITE=OFF \
    "$PROJECT_DIR"

cmake --build "$PROJECT_DIR/build/ios-llamacpp-simulator" \
    --config $BUILD_TYPE \
    --parallel

#===============================================================================
# Create XCFramework
#===============================================================================

echo "📦 Creating RunAnywhereLlamaCPP.xcframework..."

xcodebuild -create-xcframework \
    -library "$PROJECT_DIR/build/ios-llamacpp-device/src/backends/llamacpp/$BUILD_TYPE-iphoneos/librunanywhere_llamacpp.a" \
    -headers "$PROJECT_DIR/src/backends/llamacpp/bridge/ios" \
    -library "$PROJECT_DIR/build/ios-llamacpp-simulator/src/backends/llamacpp/$BUILD_TYPE-iphonesimulator/librunanywhere_llamacpp.a" \
    -headers "$PROJECT_DIR/src/backends/llamacpp/bridge/ios" \
    -output "$OUTPUT_DIR/RunAnywhereLlamaCPP.xcframework"

#===============================================================================
# Create zip + checksum
#===============================================================================

echo "📦 Creating release archive..."

cd "$OUTPUT_DIR"
zip -r "RunAnywhereLlamaCPP-${VERSION}.xcframework.zip" RunAnywhereLlamaCPP.xcframework
shasum -a 256 "RunAnywhereLlamaCPP-${VERSION}.xcframework.zip" > "RunAnywhereLlamaCPP-${VERSION}.xcframework.zip.sha256"

echo "✅ Build complete!"
echo "📍 Output: $OUTPUT_DIR/RunAnywhereLlamaCPP-${VERSION}.xcframework.zip"
echo "📊 Size: $(du -h "$OUTPUT_DIR/RunAnywhereLlamaCPP-${VERSION}.xcframework.zip" | cut -f1)"
echo "🔒 SHA256: $(cat "$OUTPUT_DIR/RunAnywhereLlamaCPP-${VERSION}.xcframework.zip.sha256")"
```

**File:** `scripts/build-android-llamacpp.sh`

```bash
#!/bin/bash
set -e

VERSION="1.0.0"
BUILD_TYPE="${BUILD_TYPE:-Release}"
NDK_PATH="${ANDROID_NDK:-$ANDROID_HOME/ndk/26.1.10909125}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
OUTPUT_DIR="$PROJECT_DIR/dist/android"

echo "🔨 Building RunAnywhereLlamaCPP for Android (v${VERSION})"

if [ ! -d "$NDK_PATH" ]; then
    echo "❌ Android NDK not found at: $NDK_PATH"
    echo "Set ANDROID_NDK environment variable"
    exit 1
fi

# Clean
rm -rf "$PROJECT_DIR/build/android-llamacpp-"*
mkdir -p "$OUTPUT_DIR/jniLibs"

# ABIs to build
ABIS=("arm64-v8a" "x86_64")

for ABI in "${ABIS[@]}"; do
    echo "📱 Building for ${ABI}..."

    cmake -B "$PROJECT_DIR/build/android-llamacpp-${ABI}" \
        -DCMAKE_TOOLCHAIN_FILE="$NDK_PATH/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI=$ABI \
        -DANDROID_PLATFORM=android-24 \
        -DANDROID_STL=c++_shared \
        -DCMAKE_BUILD_TYPE=$BUILD_TYPE \
        -DRA_BUILD_LLAMACPP=ON \
        -DRA_BUILD_COREML=OFF \
        -DRA_BUILD_TFLITE=OFF \
        "$PROJECT_DIR"

    cmake --build "$PROJECT_DIR/build/android-llamacpp-${ABI}" \
        --config $BUILD_TYPE \
        --parallel

    # Copy .so files
    mkdir -p "$OUTPUT_DIR/jniLibs/${ABI}"
    cp "$PROJECT_DIR/build/android-llamacpp-${ABI}/src/backends/llamacpp/librunanywhere_llamacpp.so" \
       "$OUTPUT_DIR/jniLibs/${ABI}/"
done

echo "✅ Build complete!"
echo "📍 Output: $OUTPUT_DIR/jniLibs/"
ls -lh "$OUTPUT_DIR/jniLibs/"*/
```

---

## Testing Strategy

### Unit Tests

**File:** `src/backends/llamacpp/tests/llamacpp_test.cpp`

```cpp
#include "backend/llamacpp_backend.h"
#include <cassert>
#include <iostream>

using namespace runanywhere;

void test_backend_creation() {
    std::cout << "Testing backend creation..." << std::endl;

    LlamaCPPBackend backend;
    assert(backend.get_type() == BackendType::LLAMA_CPP);
    assert(backend.get_name() == "llama.cpp");
    assert(!backend.is_model_loaded());

    std::cout << "✅ Backend creation test passed" << std::endl;
}

void test_capabilities() {
    std::cout << "Testing capabilities..." << std::endl;

    LlamaCPPBackend backend;
    auto caps = backend.get_capabilities();

    assert(caps.backend_type == BackendType::LLAMA_CPP);
    assert(caps.supports_streaming);
    assert(caps.supports_quantization);
    assert(!caps.supported_quantizations.empty());

    std::cout << "✅ Capabilities test passed" << std::endl;
}

void test_model_load() {
    std::cout << "Testing model load..." << std::endl;

    // NOTE: Requires actual model file for full test
    // This is a placeholder

    LlamaCPPBackend backend;

    // Should fail with non-existent file
    bool success = backend.load_model("/nonexistent/model.gguf");
    assert(!success);
    assert(!backend.is_model_loaded());

    std::cout << "✅ Model load test passed" << std::endl;
}

int main() {
    std::cout << "Running LlamaCPP backend tests..." << std::endl;

    test_backend_creation();
    test_capabilities();
    test_model_load();

    std::cout << "✅ All tests passed!" << std::endl;
    return 0;
}
```

### Integration Tests (Swift)

**File:** `Tests/RunAnywhereLlamaCPPTests/RuntimeTests.swift`

```swift
import XCTest
@testable import RunAnywhereLlamaCPP

final class LlamaCPPRuntimeTests: XCTestCase {

    func testRuntimeCreation() throws {
        let runtime = try LlamaCPPRuntime()
        XCTAssertFalse(runtime.isModelLoaded)
    }

    func testRuntimeWithCustomConfig() throws {
        let config = LlamaCPPRuntime.Configuration(
            contextSize: 4096,
            threads: 8,
            gpuLayers: 32
        )

        let runtime = try LlamaCPPRuntime(configuration: config)
        XCTAssertFalse(runtime.isModelLoaded)
    }

    func testMemoryUsage() throws {
        let runtime = try LlamaCPPRuntime()
        let memoryUsage = runtime.memoryUsage

        // Before loading model, should be minimal
        XCTAssertLessThan(memoryUsage, 100 * 1024 * 1024) // < 100 MB
    }

    func testDeviceType() throws {
        let runtime = try LlamaCPPRuntime()
        let deviceType = runtime.deviceType

        #if targetEnvironment(simulator)
        XCTAssertEqual(deviceType, "cpu")
        #else
        // On real device, should use Metal
        XCTAssertTrue(deviceType == "gpu" || deviceType == "cpu")
        #endif
    }

    // NOTE: Full inference test requires a model file
    // Add this when you have a test model:
    //
    // func testInference() async throws {
    //     let runtime = try LlamaCPPRuntime()
    //     try await runtime.loadModel(path: Bundle.module.path(forResource: "test-model", ofType: "gguf")!)
    //
    //     let result = try await runtime.generate(
    //         prompt: "Hello",
    //         maxTokens: 10
    //     )
    //
    //     XCTAssertFalse(result.output.isEmpty)
    //     XCTAssertGreaterThan(result.tokensGenerated, 0)
    // }
}
```

---

## Release Process

### Version 1.0.0 Release Checklist

```markdown
# v1.0.0 Release Checklist

## Pre-release (1 week before)

### Code
- [ ] All backends compile successfully
  - [ ] iOS LlamaCPP
  - [ ] iOS CoreML
  - [ ] Android LlamaCPP
  - [ ] Android TFLite
- [ ] All unit tests pass
- [ ] Integration tests pass
- [ ] No memory leaks (Instruments/Address Sanitizer)
- [ ] Code review completed

### Documentation
- [ ] API documentation complete
- [ ] Integration guides written
- [ ] Example apps working
- [ ] README updated
- [ ] CHANGELOG.md created

### Infrastructure
- [ ] CI/CD pipelines working
- [ ] CDN configured
- [ ] Binary signing certificates valid
- [ ] Release scripts tested

## Release Day

### Build
- [ ] Create git tag: `git tag -a v1.0.0 -m "Release v1.0.0"`
- [ ] Push tag: `git push origin v1.0.0`
- [ ] Wait for CI to build binaries
- [ ] Verify binary sizes:
  - [ ] RunAnywhereLlamaCPP.xcframework < 60 MB
  - [ ] RunAnywhereCoreML.xcframework < 5 MB
- [ ] Verify checksums match

### Distribution
- [ ] Upload to CDN
- [ ] Test download URLs
- [ ] Publish public SDK repos:
  - [ ] runanywhere-swift v1.0.0
  - [ ] runanywhere-android v1.0.0
- [ ] Test SPM installation
- [ ] Test Gradle installation

### Announcement
- [ ] Blog post published
- [ ] Twitter announcement
- [ ] Email to beta users
- [ ] Update website

## Post-release (first 48 hours)

### Monitoring
- [ ] Check crash reports (zero tolerance for crashes)
- [ ] Monitor telemetry data
- [ ] Check GitHub issues
- [ ] Response time < 2 hours for critical issues

### Metrics
- [ ] Track downloads
- [ ] Track integration attempts
- [ ] Gather feedback
```

---

## Phase 2 Preparation

### Data Collection for Policy Engine

**What to collect in Phase 1:**

```cpp
// Already implemented in telemetry.cpp
struct InferenceMetrics {
    std::string backend_type;        // "llamacpp", "coreml"
    std::string device_model;        // "iPhone15,2", "SM-G998B"
    std::string os_version;          // "17.2", "14"

    int64_t latency_ms;              // How long inference took
    int tokens_generated;            // Output length
    float tokens_per_second;         // Performance metric

    size_t memory_used_mb;           // Resource usage
    float battery_drain_percent;    // Power consumption
    bool thermal_throttled;          // Did device overheat?

    std::string model_id;            // Which model was used
    size_t model_size_mb;            // Model file size
    std::string quantization;        // Q4_K_M, F16, etc.
};
```

**Server-side analytics:**

After 3 months, you'll have data like:

```sql
-- Which backend is fastest on iPhone 15 Pro?
SELECT backend_type, AVG(latency_ms)
FROM inference_metrics
WHERE device_model = 'iPhone15,2'
GROUP BY backend_type;

-- Result: CoreML is 3x faster than LlamaCPP on ANE
-- → Policy: Always use CoreML on iPhone 15+

-- Does quantization matter?
SELECT quantization, AVG(latency_ms), AVG(tokens_per_second)
FROM inference_metrics
WHERE backend_type = 'llamacpp'
GROUP BY quantization;

-- Result: Q4_K_M is 95% as fast as F16 but uses 4x less RAM
-- → Policy: Prefer Q4_K_M on devices with < 6GB RAM
```

**This data informs Phase 2 policy rules!**

---

### Hooks for Policy Engine

**Already built into Phase 1:**

1. **Common Interface**: All backends implement `BackendInterface`
   - Policy engine can call any backend uniformly

2. **Capability Introspection**: `get_capabilities()` returns what backend can do
   - Policy engine knows which backends support what

3. **Device Detection**: Already collecting device info in telemetry
   - Can be extracted into standalone `DeviceDetector` class

4. **Telemetry Callbacks**: Backends report events
   - Policy engine can monitor performance and adapt

**Phase 2 just adds:**

```cpp
// New in Phase 2
class PolicyEngine {
    BackendType select_backend(
        const ModelManifest& manifest,
        const DeviceCapabilities& device
    ) {
        // Use data collected in Phase 1 to decide!
        // "iPhone 15 + CoreML model → use CoreML"
        // "Old Android + low RAM → use LlamaCPP CPU"
    }
};
```

---

## SDK Consumption Patterns

**Context**: The ONNX backend (and all future backends) must integrate seamlessly with the existing Swift and Kotlin Multiplatform SDKs. This section documents the established patterns discovered from analyzing the production SDKs.

### Swift SDK Architecture

**Location**: `EXTERNAL/runanywhere-sdks/sdk/runanywhere-swift/`

The Swift SDK follows a **plugin-based architecture** using the `UnifiedFrameworkAdapter` pattern for backend registration.

#### Key Pattern: UnifiedFrameworkAdapter

**File**: `Sources/RunAnywhere/Core/Protocols/UnifiedFrameworkAdapter.swift`

```swift
public protocol UnifiedFrameworkAdapter {
    var framework: LLMFramework { get }
    var supportedModalities: Set<FrameworkModality> { get }
    var supportedFormats: [ModelFormat] { get }

    func canHandle(model: ModelInfo) -> Bool
    func createService(for modality: FrameworkModality) -> Any?
    func loadModel(_ model: ModelInfo, for modality: FrameworkModality) async throws -> Any
    func onRegistration()
    func cleanup()
}
```

#### ONNX is Already Defined

**File**: `Sources/RunAnywhere/Core/Models/Framework/LLMFramework.swift`

```swift
public enum LLMFramework: String, CaseIterable, Codable {
    case coreML = "CoreML"
    case tensorFlowLite = "TFLite"
    case onnx = "ONNX"  // ← Already supported!
    case llamaCpp = "LlamaCpp"
    case mlx = "MLX"
    case executorch = "ExecuTorch"
    case mediapipe = "MediaPipe"

    public var displayName: String {
        switch self {
        case .onnx: return "ONNX Runtime"
        // ...
        }
    }
}
```

#### Module Structure Pattern

The Swift SDK organizes backends as separate Swift packages that depend on binary frameworks:

**Example**: `Modules/LLMSwift/Package.swift`

```swift
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "LLMSwift",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [
        .library(name: "LLMSwift", targets: ["LLMSwift"])
    ],
    dependencies: [
        .package(url: "https://github.com/ml-explore/mlx-swift", from: "0.15.8")
    ],
    targets: [
        .target(
            name: "LLMSwift",
            dependencies: [
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXRandom", package: "mlx-swift"),
                .product(name: "MLXNN", package: "mlx-swift"),
                .product(name: "MLXOptimizers", package: "mlx-swift"),
                .product(name: "MLXFFT", package: "mlx-swift"),
                .product(name: "MLXLinalg", package: "mlx-swift")
            ]
        )
    ]
)
```

**For ONNX, the pattern will be:**

```swift
// Modules/ONNXRuntime/Package.swift
// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ONNXRuntime",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [
        .library(name: "ONNXRuntime", targets: ["ONNXRuntime"])
    ],
    dependencies: [],
    targets: [
        .target(
            name: "ONNXRuntime",
            dependencies: ["ONNXRuntimeBinary"]
        ),
        .binaryTarget(
            name: "ONNXRuntimeBinary",
            path: "../../Binaries/RunAnywhereONNX.xcframework"
        )
    ]
)
```

#### Adapter Implementation Pattern

**File**: `Modules/LLMSwift/Sources/LLMSwift/LLMSwiftAdapter.swift` (example)

```swift
import Foundation
import RunAnywhere

public final class ONNXAdapter: UnifiedFrameworkAdapter {
    public var framework: LLMFramework { .onnx }

    public var supportedModalities: Set<FrameworkModality> {
        [.textGeneration, .chat, .embedding]
    }

    public var supportedFormats: [ModelFormat] {
        [.onnx]  // .onnx format defined in ModelFormat enum
    }

    public func canHandle(model: ModelInfo) -> Bool {
        model.framework == .onnx && supportedFormats.contains(model.format)
    }

    public func createService(for modality: FrameworkModality) -> Any? {
        switch modality {
        case .textGeneration:
            return ONNXTextGenerationService()
        case .chat:
            return ONNXChatService()
        case .embedding:
            return ONNXEmbeddingService()
        default:
            return nil
        }
    }

    public func loadModel(_ model: ModelInfo, for modality: FrameworkModality) async throws -> Any {
        // Calls C bridge functions
        let handle = ra_onnx_create()
        guard handle != nil else {
            throw ONNXError.initializationFailed
        }

        let result = ra_onnx_load_model(handle, model.path)
        guard result == 0 else {
            throw ONNXError.modelLoadFailed
        }

        return ONNXModel(handle: handle!, modality: modality)
    }

    public func onRegistration() {
        print("✅ ONNX Runtime adapter registered")
    }

    public func cleanup() {
        // Cleanup resources
    }
}
```

#### Registration Pattern

**File**: Main Swift SDK uses `ModuleInitializer` pattern

```swift
// In app startup or SDK initialization
import RunAnywhere
import ONNXRuntime

// Register ONNX adapter
let onnxAdapter = ONNXAdapter()
RunAnywhere.shared.registerFramework(onnxAdapter)
```

---

### Kotlin SDK Architecture

**Location**: `EXTERNAL/runanywhere-sdks/sdk/runanywhere-kotlin/`

The Kotlin SDK uses **ModuleRegistry** pattern with JNI integration for Android native code.

#### Key Pattern: ModuleRegistry

**File**: `src/commonMain/kotlin/com/runanywhere/sdk/core/ModuleRegistry.kt`

```kotlin
object ModuleRegistry {
    private val _llmProviders = mutableListOf<LLMServiceProvider>()
    private val _ttsProviders = mutableListOf<TTSServiceProvider>()
    private val _asrProviders = mutableListOf<ASRServiceProvider>()

    val llmProviders: List<LLMServiceProvider> get() = _llmProviders.toList()

    fun registerLLM(provider: LLMServiceProvider) {
        synchronized(_llmProviders) {
            if (!_llmProviders.contains(provider)) {
                _llmProviders.add(provider)
                println("✅ Registered LLM provider: ${provider.name}")
            }
        }
    }

    fun getLLMProvider(name: String): LLMServiceProvider? {
        return _llmProviders.find { it.name == name }
    }
}
```

#### JNI Integration Pattern

The Kotlin SDK follows the **whisper-jni** pattern for native integration:

**File**: `native/whisper-jni/CMakeLists.txt` (reference pattern)

```cmake
cmake_minimum_required(VERSION 3.18)
project(whisper-jni)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Find JNI
find_package(JNI REQUIRED)
include_directories(${JNI_INCLUDE_DIRS})

# Add whisper.cpp as subdirectory
add_subdirectory(whisper.cpp)

# Create JNI library
add_library(whisper-jni SHARED
    src/whisper_jni.cpp
)

target_include_directories(whisper-jni PRIVATE
    whisper.cpp/include
    ${JNI_INCLUDE_DIRS}
)

target_link_libraries(whisper-jni
    whisper
    ${JNI_LIBRARIES}
)
```

**For ONNX, the pattern will be:**

```cmake
# native/onnx-jni/CMakeLists.txt
cmake_minimum_required(VERSION 3.18)
project(onnx-jni)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Find JNI
find_package(JNI REQUIRED)
include_directories(${JNI_INCLUDE_DIRS})

# Link ONNX Runtime backend from runanywhere-core
add_subdirectory(${RUNANYWHERE_CORE_PATH}/src/backends/onnx onnx_backend)

# Create JNI library
add_library(onnx-jni SHARED
    src/onnx_jni.cpp
)

target_include_directories(onnx-jni PRIVATE
    ${RUNANYWHERE_CORE_PATH}/src/backends/onnx/bridge/android
    ${JNI_INCLUDE_DIRS}
)

target_link_libraries(onnx-jni
    runanywhere_onnx_backend
    ${JNI_LIBRARIES}
)
```

#### JNI Wrapper Implementation

**File**: `native/onnx-jni/src/onnx_jni.cpp`

```cpp
#include <jni.h>
#include "onnx_bridge.h"  // C bridge from runanywhere-core

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_runanywhere_onnx_ONNXRuntime_nativeCreate(JNIEnv* env, jobject thiz) {
    ra_onnx_handle handle = ra_onnx_create();
    return reinterpret_cast<jlong>(handle);
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_onnx_ONNXRuntime_nativeLoadModel(
    JNIEnv* env,
    jobject thiz,
    jlong handle,
    jstring path
) {
    const char* pathStr = env->GetStringUTFChars(path, nullptr);

    int result = ra_onnx_load_model(
        reinterpret_cast<ra_onnx_handle>(handle),
        pathStr
    );

    env->ReleaseStringUTFChars(path, pathStr);
    return result;
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_onnx_ONNXRuntime_nativeInfer(
    JNIEnv* env,
    jobject thiz,
    jlong handle,
    jstring prompt,
    jint maxTokens,
    jfloat temperature
) {
    const char* promptStr = env->GetStringUTFChars(prompt, nullptr);

    char* resultPtr = nullptr;
    int status = ra_onnx_infer(
        reinterpret_cast<ra_onnx_handle>(handle),
        promptStr,
        maxTokens,
        temperature,
        &resultPtr
    );

    env->ReleaseStringUTFChars(prompt, promptStr);

    if (status != 0 || resultPtr == nullptr) {
        return nullptr;
    }

    jstring result = env->NewStringUTF(resultPtr);
    ra_free_string(resultPtr);

    return result;
}

JNIEXPORT void JNICALL
Java_com_runanywhere_onnx_ONNXRuntime_nativeDestroy(
    JNIEnv* env,
    jobject thiz,
    jlong handle
) {
    ra_onnx_destroy(reinterpret_cast<ra_onnx_handle>(handle));
}

} // extern "C"
```

#### Kotlin Service Provider Implementation

**File**: `modules/runanywhere-onnx-runtime/src/main/kotlin/com/runanywhere/onnx/ONNXServiceProvider.kt`

```kotlin
package com.runanywhere.onnx

import com.runanywhere.sdk.core.LLMServiceProvider
import com.runanywhere.sdk.models.LLMRequest
import com.runanywhere.sdk.models.LLMResponse

class ONNXServiceProvider : LLMServiceProvider {
    override val name = "ONNX"
    override val version = "1.0.0"

    private var runtime: ONNXRuntime? = null

    override suspend fun initialize(config: Map<String, Any>): Result<Unit> {
        return try {
            runtime = ONNXRuntime()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun loadModel(path: String): Result<Unit> {
        return try {
            runtime?.loadModel(path)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun generate(request: LLMRequest): Result<LLMResponse> {
        return try {
            val result = runtime?.infer(
                prompt = request.prompt,
                maxTokens = request.maxTokens ?: 100,
                temperature = request.temperature ?: 0.7f
            )

            result?.let {
                Result.success(LLMResponse(text = it))
            } ?: Result.failure(Exception("Inference failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun cleanup() {
        runtime?.destroy()
        runtime = null
    }
}
```

#### Module Registration

**File**: Module initialization in Kotlin SDK

```kotlin
// In library initialization or companion object
import com.runanywhere.sdk.core.ModuleRegistry
import com.runanywhere.onnx.ONNXServiceProvider

// Register ONNX provider
ModuleRegistry.registerLLM(ONNXServiceProvider())
```

---

### Module Structure for ONNX Backend

Based on existing patterns, here's how ONNX modules should be structured:

#### Swift SDK Module

```
Modules/ONNXRuntime/
├── Package.swift                           # Swift package manifest
├── Sources/
│   └── ONNXRuntime/
│       ├── ONNXAdapter.swift              # UnifiedFrameworkAdapter implementation
│       ├── ONNXRuntime.swift              # Swift wrapper for C bridge
│       ├── Services/
│       │   ├── ONNXTextGenerationService.swift
│       │   ├── ONNXChatService.swift
│       │   └── ONNXEmbeddingService.swift
│       └── Models/
│           ├── ONNXModel.swift
│           └── ONNXError.swift
└── Binaries/
    └── RunAnywhereONNX.xcframework/      # Built from runanywhere-core
```

#### Kotlin SDK Module

```
modules/runanywhere-onnx-runtime/
├── build.gradle.kts                        # Gradle build configuration
├── src/
│   ├── main/
│   │   ├── kotlin/com/runanywhere/onnx/
│   │   │   ├── ONNXServiceProvider.kt    # LLMServiceProvider implementation
│   │   │   ├── ONNXRuntime.kt            # Kotlin wrapper for JNI
│   │   │   └── ONNXError.kt
│   │   └── jniLibs/
│   │       └── arm64-v8a/libonnx-jni.so  # Built from native/onnx-jni
│   └── androidTest/
└── native/
    └── onnx-jni/
        ├── CMakeLists.txt                  # JNI build configuration
        └── src/
            └── onnx_jni.cpp                # JNI wrapper calling C bridge
```

---

### Build Integration Strategy

#### For Swift SDK

1. **Build XCFramework** (in runanywhere-core):
```bash
./scripts/build-ios-onnx.sh
# Output: build/ios/RunAnywhereONNX.xcframework
```

2. **Copy to SDK Module**:
```bash
cp -r build/ios/RunAnywhereONNX.xcframework \
    ../runanywhere-sdks/sdk/runanywhere-swift/Modules/ONNXRuntime/Binaries/
```

3. **Reference in Package.swift**:
```swift
.binaryTarget(
    name: "ONNXRuntimeBinary",
    path: "Binaries/RunAnywhereONNX.xcframework"
)
```

#### For Kotlin SDK

1. **Build JNI Library** (in runanywhere-kotlin):
```bash
cd native/onnx-jni
cmake -B build -DRUNANYWHERE_CORE_PATH=/path/to/runanywhere-core
cmake --build build
# Output: build/libonnx-jni.so
```

2. **Copy to Module**:
```bash
cp build/libonnx-jni.so \
    ../modules/runanywhere-onnx-runtime/src/main/jniLibs/arm64-v8a/
```

3. **Maven Distribution** (future):
```gradle
publishing {
    publications {
        maven(MavenPublication) {
            groupId = 'com.runanywhere'
            artifactId = 'onnx-runtime'
            version = '1.0.0'
        }
    }
}
```

---

### Key Takeaways for ONNX Implementation

1. ✅ **Swift SDK**: Implement `UnifiedFrameworkAdapter` protocol
   - ONNX is already defined in `LLMFramework` enum
   - Follow the LLMSwift module pattern
   - Use binary target for XCFramework

2. ✅ **Kotlin SDK**: Implement `LLMServiceProvider` interface
   - Register with `ModuleRegistry`
   - Follow whisper-jni pattern for native integration
   - Use CMake + JNI for Android builds

3. ✅ **Modular**: Each backend is a separate module
   - Swift: Separate Swift package
   - Kotlin: Separate Gradle module
   - Both depend on C bridge from runanywhere-core

4. ✅ **No Flutter SDK Yet**: Will need to create from scratch following Swift/Kotlin patterns
   - Use Dart FFI to call C bridge
   - Follow similar adapter pattern

5. ✅ **Binary Distribution**:
   - iOS: XCFramework shipped via Swift Package binary target
   - Android: .so files in jniLibs, future Maven artifact
   - Both reference same runanywhere-core C bridge

---

## SDK Support Matrix

### Confirmed Working SDKs

All of these SDKs will work with the C/C++ core because they all support calling C functions:

| SDK | Platform | Bridge Method | Status | Complexity |
|-----|----------|---------------|--------|------------|
| **Swift** | iOS, macOS | C imports | ✅ Documented | Easy |
| **Kotlin** | Android | JNI | ✅ Documented | Easy |
| **Flutter** | iOS, Android, Desktop | Dart FFI | ✅ Works | Medium |
| **Kotlin Multiplatform** | iOS + Android | cinterop + JNI | ✅ Works | Medium |
| **React Native** | iOS, Android | Native Modules | ✅ Works | Medium |
| **Unity** | iOS, Android | P/Invoke | ✅ Works | Easy |
| **WebAssembly** | Browser | Emscripten | ⚠️ Needs separate build | Hard |

### Adding Flutter Support (Optional Week 7-8)

**Public Flutter plugin structure:**

```
runanywhere_flutter/
├── pubspec.yaml
├── lib/
│   ├── runanywhere_llamacpp.dart        # Public API
│   └── src/
│       ├── bindings.dart                 # FFI bindings to C
│       └── runtime.dart                  # High-level wrapper
├── ios/
│   └── Frameworks/
│       └── RunAnywhereLlamaCPP.xcframework   # Your binary
├── android/
│   └── src/main/jniLibs/
│       └── arm64-v8a/
│           └── librunanywhere_llamacpp.so    # Your binary
└── example/
    └── lib/main.dart
```

**Dart FFI bindings:**

```dart
import 'dart:ffi';
import 'package:ffi/ffi.dart';

final DynamicLibrary nativeLib = Platform.isAndroid
    ? DynamicLibrary.open('librunanywhere_llamacpp.so')
    : DynamicLibrary.process();

// Bind to your C functions
final create = nativeLib
    .lookup<NativeFunction<Pointer Function()>>('ra_llamacpp_create')
    .asFunction<Pointer Function()>();
```

**Developer usage:**

```dart
import 'package:runanywhere_llamacpp/runanywhere_llamacpp.dart';

final runtime = LlamaCPPRuntime();
await runtime.loadModel('assets/model.gguf');
final result = await runtime.generate('Hello!');
```

### Adding Kotlin Multiplatform Support (Optional Week 9-10)

**Shared interface (commonMain):**

```kotlin
expect class LlamaCPPRuntime() {
    fun loadModel(path: String)
    fun generate(prompt: String): String
}
```

**iOS implementation (iosMain):**

```kotlin
import kotlinx.cinterop.*
import runanywhere.cinterop.*  // Generated from C headers

actual class LlamaCPPRuntime {
    private val handle = ra_llamacpp_create()!!

    actual fun loadModel(path: String) {
        ra_llamacpp_load_model(handle, path)
    }
}
```

**Android implementation (androidMain):**

```kotlin
actual class LlamaCPPRuntime {
    private var handle: Long = 0

    init {
        System.loadLibrary("runanywhere_llamacpp")
        handle = nativeCreate()
    }

    private external fun nativeCreate(): Long
}
```

**Same code works on both platforms!**

### Key Insight: C is the Universal Bridge

**All languages can call C:**

```
Swift      → imports C headers
Kotlin     → JNI wraps C
Dart       → FFI binds to C
JavaScript → Native Modules wrap C
C#         → P/Invoke calls C
Python     → ctypes/cffi calls C
```

**Your C++ core exposes C API:**

```c
extern "C" {
    ra_llamacpp_handle ra_llamacpp_create();
    int ra_llamacpp_load_model(ra_llamacpp_handle, const char*);
    // ...
}
```

**This works everywhere!**

---

## Summary

This plan gives you:

1. ✅ **Clear structure**: 12-week timeline with weekly milestones
2. ✅ **Complete code**: Full implementations of LlamaCPP backend + bridge + Swift SDK
3. ✅ **Build system**: CMake configs and shell scripts
4. ✅ **Testing**: Unit and integration tests
5. ✅ **Release process**: CI/CD and distribution
6. ✅ **Phase 2 ready**: Telemetry and interfaces for future policy engine

**Next Steps:**

1. Set up private `runanywhere-core` repository
2. Add llama.cpp as git submodule
3. Start implementing `LlamaCPPBackend` class (Week 1)
4. Follow week-by-week plan

**You're ready to start coding! 🚀**
