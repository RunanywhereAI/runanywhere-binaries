# RunAnywhere Core

> Private C++ core library providing unified ML inference across ONNX Runtime, LlamaCPP, and CoreML backends with multi-modality support.

[![Platform](https://img.shields.io/badge/platform-iOS%20%7C%20Android%20%7C%20macOS%20%7C%20Linux-blue)](https://github.com/RunanywhereAI)
[![License](https://img.shields.io/badge/license-Private-red)](LICENSE)
[![Build](https://img.shields.io/badge/build-CMake-green)](BUILD.md)

## 🎯 Overview

RunAnywhere Core is the foundational C/C++ library that powers the RunAnywhere SDK family. It provides a unified, cross-platform API for running machine learning models on-device across multiple inference backends.

### Key Features

- **🔄 Multi-Backend Support**: ONNX Runtime, LlamaCPP, CoreML, TensorFlow Lite, ExecuTorch
- **🎤 Multi-Modality**: Speech-to-Text (ASR), Text-to-Speech (TTS), Text Generation (LLM)
- **📱 Cross-Platform**: iOS, Android, macOS, Linux with consistent C API
- **⚡ High Performance**: Native C++ implementation with platform-specific optimizations
- **🔌 Clean Integration**: Simple C API for easy binding to Swift, Kotlin, and other languages
- **📊 Built-in Telemetry**: Performance monitoring and device capability detection

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│           Platform SDKs (Swift, Kotlin)             │
│  (runanywhere-swift, runanywhere-kotlin, ...)       │
└───────────────────┬─────────────────────────────────┘
                    │ C API
┌───────────────────┴─────────────────────────────────┐
│              RunAnywhere Core (C++)                  │
│  ┌──────────────────────────────────────────────┐   │
│  │        Common Infrastructure                 │   │
│  │  • Telemetry  • Device Info  • Utilities    │   │
│  └──────────────────────────────────────────────┘   │
│  ┌──────────┬──────────┬──────────┬──────────┐      │
│  │  ONNX    │ LlamaCPP │  CoreML  │ TFLite   │      │
│  │ Runtime  │          │          │          │      │
│  │ Backend  │ Backend  │ Backend  │ Backend  │      │
│  └────┬─────┴────┬─────┴────┬─────┴────┬─────┘      │
└───────┼──────────┼──────────┼──────────┼────────────┘
        │          │          │          │
   ┌────┴───┐ ┌───┴────┐ ┌───┴────┐ ┌──┴──────┐
   │ ONNX   │ │ llama  │ │ Core   │ │ TFLite  │
   │Runtime │ │  .cpp  │ │   ML   │ │         │
   └────────┘ └────────┘ └────────┘ └─────────┘
```

## 🚀 Quick Start

### Prerequisites

- **CMake** 3.22 or later
- **C++17** compatible compiler
- **Platform-specific tools**:
  - iOS/macOS: Xcode 14+
  - Android: Android NDK r25+
  - Linux: GCC 9+ or Clang 10+

### Building

```bash
# Download ONNX Runtime dependency (iOS only, first time)
cd /path/to/runanywhere-core
./scripts/download-onnx-ios.sh

# Build for iOS (creates XCFramework)
./scripts/build-ios-onnx.sh

# The built XCFramework will be in dist/RunAnywhereONNX.xcframework
```

### Integration

Copy the built XCFramework to your Swift/Kotlin SDK:

```bash
# For Swift SDK
cp -r dist/RunAnywhereONNX.xcframework \
  /path/to/runanywhere-swift/XCFrameworks/
```

See [BUILD.md](BUILD.md) for detailed build instructions.

## 📚 Documentation

- **[Quick Start Guide](docs/QUICK_START.md)** - Get running in 5 minutes
- **[ONNX Runtime Setup](docs/ONNX_RUNTIME_SETUP.md)** - Detailed ONNX integration guide
- **[Modality Support](docs/MODALITY_SUPPORT.md)** - Multi-modality API documentation
- **[Implementation Status](docs/IMPLEMENTATION_STATUS.md)** - Current implementation progress
- **[Scripts Documentation](scripts/README.md)** - Build scripts reference
- **[Architecture](plans/private-core-architecture.md)** - System design and architecture

## 🔧 Build Scripts

| Script | Purpose |
|--------|---------|
| `scripts/download-onnx-ios.sh` | Download ONNX Runtime iOS dependency |
| `scripts/build-ios-onnx.sh` | Build ONNX Runtime XCFramework for iOS |

See [scripts/README.md](scripts/README.md) for detailed documentation.

## 📁 Repository Structure

```
runanywhere-core/
├── cmake/                 # CMake modules for dependency management
├── docs/                  # Documentation
├── include/               # Public C API headers
├── plans/                 # Architecture and planning docs
├── scripts/               # Build automation scripts
├── src/
│   ├── backends/         # Backend implementations
│   │   └── onnx/        # ONNX Runtime backend
│   │       ├── backend/ # Core C++ implementation
│   │       └── bridge/  # Platform bridges (iOS/Android)
│   └── common/          # Shared utilities
├── third_party/          # External dependencies (downloaded)
│   ├── json/            # nlohmann/json (submodule)
│   └── onnxruntime-ios/ # ONNX Runtime (downloaded via script)
├── BUILD.md             # Build instructions
└── README.md            # This file
```

## 🎯 Supported Backends

| Backend | Status | Platforms | Modalities |
|---------|--------|-----------|------------|
| **ONNX Runtime** | ✅ Implemented | iOS, Android, macOS, Linux | ASR, TTS, LLM |
| **LlamaCPP** | 🚧 Planned | iOS, Android, macOS, Linux | LLM |
| **CoreML** | 🚧 Planned | iOS, macOS | ASR, TTS, LLM |
| **TensorFlow Lite** | 🚧 Planned | iOS, Android, Linux | ASR, Vision |
| **ExecuTorch** | 🚧 Planned | iOS, Android | LLM |

## 🎤 Supported Modalities

- **Speech-to-Text (ASR)**: Convert spoken audio to text
- **Text-to-Speech (TTS)**: Generate natural speech from text
- **Text Generation (LLM)**: Large language model inference

## 🛠️ Development

### Prerequisites for Development

```bash
# macOS/iOS development
brew install cmake ninja

# Install Xcode Command Line Tools
xcode-select --install
```

### Building for Different Platforms

#### iOS
```bash
./scripts/download-onnx-ios.sh  # First time only
./scripts/build-ios-onnx.sh
```

#### Android
```bash
# Coming soon
```

#### macOS
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(sysctl -n hw.ncpu)
```

#### Linux
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
```

## 🧪 Testing

```bash
# Build with tests enabled
cmake .. -DBUILD_TESTS=ON
make
ctest --output-on-failure
```

## 📝 License

This is private, proprietary software. All rights reserved.

See [LICENSE](LICENSE) for details.

## 🤝 Contributing

This is a private repository. For RunAnywhere team members:

1. Create a feature branch from `develop`
2. Follow the code style (C++17, Google C++ Style Guide)
3. Write tests for new functionality
4. Submit a Pull Request

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

## 📞 Support

For issues and questions:
- **Internal Team**: Slack #runanywhere-core channel
- **Bug Reports**: GitHub Issues (private repo)
- **Documentation**: See `docs/` directory

## 🔗 Related Projects

- **[runanywhere-swift](../sdks/sdk/runanywhere-swift)** - Swift SDK for iOS/macOS
- **[runanywhere-kotlin](../sdks/sdk/runanywhere-kotlin)** - Kotlin SDK for Android
- **[runanywhere-examples](../sdks/examples)** - Example applications

## 📊 Project Status

Current implementation status:
- ✅ ONNX Runtime backend (iOS)
- ✅ Multi-modality support (ASR, TTS, LLM)
- ✅ iOS XCFramework build pipeline
- ✅ Swift SDK integration
- 🚧 Android support
- 🚧 Additional backends

See [IMPLEMENTATION_STATUS.md](IMPLEMENTATION_STATUS.md) for detailed progress.

---

**Made with ❤️ by the RunAnywhere Team**
