#ifndef RUNANYWHERE_WHISPERCPP_BACKEND_H
#define RUNANYWHERE_WHISPERCPP_BACKEND_H

/**
 * WhisperCPP Backend - Speech-to-Text via whisper.cpp
 *
 * This backend uses whisper.cpp for on-device speech recognition with GGML Whisper models.
 *
 * Supported Capabilities:
 * - STT: Batch transcription and streaming via whisper.cpp
 *   - Language detection (98 languages)
 *   - Translation to English
 *   - Word-level timestamps
 */

#include <whisper.h>

#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "capabilities/backend.h"
#include "capabilities/stt.h"
#include "capabilities/types.h"

namespace runanywhere {

// =============================================================================
// FORWARD DECLARATIONS
// =============================================================================

class WhisperCppSTT;

// =============================================================================
// WHISPERCPP BACKEND
// =============================================================================

class WhisperCppBackend : public Backend {
   public:
    WhisperCppBackend();
    ~WhisperCppBackend() override;

    // Backend interface
    BackendInfo get_info() const override;
    bool initialize(const nlohmann::json& config = {}) override;
    bool is_initialized() const override;
    void cleanup() override;

    ra_device_type get_device_type() const override;
    size_t get_memory_usage() const override;

    // Get number of threads to use
    int get_num_threads() const { return num_threads_; }

    // Check if GPU is enabled
    bool is_gpu_enabled() const { return use_gpu_; }

   private:
    void create_capabilities();

    bool initialized_ = false;
    nlohmann::json config_;
    int num_threads_ = 0;
    bool use_gpu_ = true;
    mutable std::mutex mutex_;
};

// =============================================================================
// STREAMING STATE
// =============================================================================

struct WhisperStreamState {
    whisper_state* state = nullptr;
    std::vector<float> audio_buffer;
    std::string language;
    bool input_finished = false;
    int sample_rate = 16000;  // WHISPER_SAMPLE_RATE
};

// =============================================================================
// STT CAPABILITY (WHISPER)
// =============================================================================

class WhisperCppSTT : public ISTT {
   public:
    explicit WhisperCppSTT(WhisperCppBackend* backend);
    ~WhisperCppSTT() override;

    // ICapability
    bool is_ready() const override;

    // ISTT interface - Model management
    bool load_model(const std::string& model_path, STTModelType model_type = STTModelType::WHISPER,
                    const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;
    STTModelType get_model_type() const override;

    // Batch transcription
    STTResult transcribe(const STTRequest& request) override;

    // Streaming support
    bool supports_streaming() const override;
    std::string create_stream(const nlohmann::json& config = {}) override;
    bool feed_audio(const std::string& stream_id, const std::vector<float>& samples,
                    int sample_rate) override;
    bool is_stream_ready(const std::string& stream_id) override;
    STTResult decode(const std::string& stream_id) override;
    bool is_endpoint(const std::string& stream_id) override;
    void input_finished(const std::string& stream_id) override;
    void reset_stream(const std::string& stream_id) override;
    void destroy_stream(const std::string& stream_id) override;

    // Control
    void cancel() override;
    std::vector<std::string> get_supported_languages() const override;

   private:
    // Internal transcription
    STTResult transcribe_internal(const std::vector<float>& audio, const std::string& language,
                                  bool detect_language, bool translate, bool word_timestamps);

    // Audio resampling (simple linear interpolation)
    std::vector<float> resample_to_16khz(const std::vector<float>& samples, int source_rate);

    // Generate unique stream ID
    std::string generate_stream_id();

    WhisperCppBackend* backend_;
    whisper_context* ctx_ = nullptr;

    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};

    std::string model_path_;
    nlohmann::json model_config_;

    // Streaming state management
    std::unordered_map<std::string, std::unique_ptr<WhisperStreamState>> streams_;
    int stream_counter_ = 0;

    mutable std::mutex mutex_;
};

// =============================================================================
// BACKEND FACTORY & REGISTRATION
// =============================================================================

// Export macro for shared library builds (needed for Android)
#if defined(_WIN32)
#define RA_WHISPERCPP_EXPORT __declspec(dllexport)
#elif defined(__GNUC__) || defined(__clang__)
#define RA_WHISPERCPP_EXPORT __attribute__((visibility("default")))
#else
#define RA_WHISPERCPP_EXPORT
#endif

/**
 * Creates a new WhisperCPP backend instance.
 *
 * This factory function is called by the bridge to create backend instances.
 * The registration is done by the bridge itself to avoid singleton issues
 * across shared libraries.
 */
RA_WHISPERCPP_EXPORT std::unique_ptr<Backend> create_whispercpp_backend();

/**
 * Explicitly registers the WhisperCPP backend with the BackendRegistry.
 *
 * NOTE: For shared library builds (Android), prefer calling create_whispercpp_backend()
 * from the bridge and letting the bridge register it. This function calls
 * BackendRegistry::instance() which may create a separate singleton in each .so.
 *
 * For static library builds (iOS), this function works correctly.
 */
RA_WHISPERCPP_EXPORT void register_whispercpp_backend();

}  // namespace runanywhere

// =============================================================================
// C-LINKAGE API (for runanywhere-commons)
// =============================================================================

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Opaque handle types for C API
 */
typedef struct ra_whispercpp_handle_t* ra_whispercpp_handle;
typedef struct ra_whispercpp_stream_handle_t* ra_whispercpp_stream_handle;

/**
 * WhisperCpp configuration for model loading
 */
typedef struct ra_whispercpp_config {
    int num_threads;           // 0 = auto-detect
    int use_gpu;               // Enable GPU acceleration (Metal on iOS/macOS)
    const char* language;      // Target language (e.g., "en", "auto" for detection)
    int translate_to_english;  // Translate non-English to English
} ra_whispercpp_config_t;

/**
 * Audio buffer for STT operations
 */
typedef struct ra_whispercpp_audio_buffer {
    const float* samples;  // PCM float samples (-1.0 to 1.0)
    int num_samples;       // Number of samples
    int sample_rate;       // Sample rate (will be resampled to 16kHz if needed)
} ra_whispercpp_audio_buffer_t;

/**
 * Word-level timestamp information
 */
typedef struct ra_whispercpp_word {
    char* text;         // Word text
    int64_t start_ms;   // Start time in milliseconds
    int64_t end_ms;     // End time in milliseconds
    float probability;  // Word confidence
} ra_whispercpp_word_t;

/**
 * Transcription result
 */
typedef struct ra_whispercpp_result {
    char* text;                   // Full transcribed text (caller must free)
    char* detected_language;      // Detected language code (optional)
    float language_probability;   // Language detection confidence
    ra_whispercpp_word_t* words;  // Word-level timestamps (optional, may be NULL)
    int num_words;                // Number of words in array
    int64_t duration_ms;          // Audio duration in milliseconds
} ra_whispercpp_result_t;

/**
 * Streaming callback for partial results
 */
typedef void (*ra_whispercpp_stream_callback)(const char* partial_text, int is_final,
                                              void* user_data);

/**
 * Creates a new WhisperCpp service instance.
 * @param model_path Path to the GGML Whisper model file
 * @param config Configuration options (can be NULL for defaults)
 * @param out_handle Output handle on success
 * @return 0 on success, negative error code on failure
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_create(const char* model_path,
                                              const ra_whispercpp_config_t* config,
                                              ra_whispercpp_handle* out_handle);

/**
 * Destroys a WhisperCpp service instance.
 * @param handle Handle to destroy
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_destroy(ra_whispercpp_handle handle);

/**
 * Transcribes audio to text (batch mode).
 * @param handle Service handle
 * @param audio Audio buffer containing PCM samples
 * @param word_timestamps Enable word-level timestamps
 * @param out_result Output result structure
 * @return 0 on success, negative error code on failure
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_transcribe(ra_whispercpp_handle handle,
                                                  const ra_whispercpp_audio_buffer_t* audio,
                                                  int word_timestamps,
                                                  ra_whispercpp_result_t* out_result);

/**
 * Creates a streaming session for real-time transcription.
 * @param handle Service handle
 * @param config Optional streaming configuration (can be NULL)
 * @param out_stream Output stream handle
 * @return 0 on success, negative error code on failure
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_stream_create(ra_whispercpp_handle handle,
                                                     const ra_whispercpp_config_t* config,
                                                     ra_whispercpp_stream_handle* out_stream);

/**
 * Feeds audio samples to a streaming session.
 * @param stream Stream handle
 * @param audio Audio buffer
 * @return 0 on success, negative error code on failure
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_stream_feed(ra_whispercpp_stream_handle stream,
                                                   const ra_whispercpp_audio_buffer_t* audio);

/**
 * Signals that audio input is finished.
 * @param stream Stream handle
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_stream_finish(ra_whispercpp_stream_handle stream);

/**
 * Decodes accumulated audio in the stream.
 * @param stream Stream handle
 * @param out_result Output result structure
 * @return 0 on success, negative error code on failure
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_stream_decode(ra_whispercpp_stream_handle stream,
                                                     ra_whispercpp_result_t* out_result);

/**
 * Resets a streaming session for reuse.
 * @param stream Stream handle
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_stream_reset(ra_whispercpp_stream_handle stream);

/**
 * Destroys a streaming session.
 * @param stream Stream handle
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_stream_destroy(ra_whispercpp_stream_handle stream);

/**
 * Cancels an ongoing transcription.
 * @param handle Service handle
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_cancel(ra_whispercpp_handle handle);

/**
 * Checks if the model is ready.
 * @param handle Service handle
 * @return 1 if ready, 0 otherwise
 */
RA_WHISPERCPP_EXPORT int ra_whispercpp_is_ready(ra_whispercpp_handle handle);

/**
 * Gets supported languages as JSON array.
 * @param handle Service handle
 * @return JSON string (caller must free) or NULL on error
 */
RA_WHISPERCPP_EXPORT char* ra_whispercpp_get_languages(ra_whispercpp_handle handle);

/**
 * Frees a transcription result structure.
 * @param result Result to free
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_free_result(ra_whispercpp_result_t* result);

/**
 * Frees a string allocated by WhisperCpp functions.
 * @param str String to free
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_free_string(char* str);

/**
 * Returns the default configuration values.
 * @param out_config Output configuration structure
 */
RA_WHISPERCPP_EXPORT void ra_whispercpp_get_default_config(ra_whispercpp_config_t* out_config);

#ifdef __cplusplus
}
#endif

#endif  // RUNANYWHERE_WHISPERCPP_BACKEND_H
