#ifndef RUNANYWHERE_ONNX_BACKEND_H
#define RUNANYWHERE_ONNX_BACKEND_H

/**
 * ONNX Backend - Capability-based implementation
 *
 * This backend uses ONNX Runtime for general ML inference and
 * Sherpa-ONNX for speech-specific tasks (STT, TTS, VAD, Diarization).
 *
 * Supported Capabilities:
 * - TEXT_GENERATION: Via ONNX LLM models (ORT GenAI)
 * - EMBEDDINGS: Via ONNX embedding models
 * - STT: Via Whisper (batch) + Sherpa-ONNX Zipformer (streaming)
 * - TTS: Via Sherpa-ONNX Piper/VITS
 * - VAD: Via Sherpa-ONNX Silero VAD
 * - DIARIZATION: Via Sherpa-ONNX speaker models
 */

#include <onnxruntime_c_api.h>

#include <atomic>
#include <chrono>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "capabilities/backend.h"
#include "capabilities/types.h"

// Sherpa-ONNX C API for TTS/STT
#if SHERPA_ONNX_AVAILABLE
#include <sherpa-onnx/c-api/c-api.h>
#endif

namespace runanywhere {

// =============================================================================
// SIMPLE DEVICE INFO (inline for now)
// =============================================================================

struct DeviceInfo {
    ra_device_type device_type = RA_DEVICE_CPU;
    std::string device_name;
    std::string platform;
    size_t available_memory = 0;
    int cpu_cores = 0;
};

// =============================================================================
// SIMPLE TELEMETRY (inline for now)
// =============================================================================

using TelemetryCallback = std::function<void(const std::string& event_json)>;

class TelemetryCollector {
   public:
    void set_callback(TelemetryCallback callback) { callback_ = callback; }

    void emit(const std::string& event_type, const nlohmann::json& data = {}) {
        if (callback_) {
            nlohmann::json event = {
                {"type", event_type},
                {"data", data},
                {"timestamp", std::chrono::system_clock::now().time_since_epoch().count()}};
            callback_(event.dump());
        }
    }

   private:
    TelemetryCallback callback_;
};

// =============================================================================
// FORWARD DECLARATIONS
// =============================================================================

class ONNXTextGeneration;
class ONNXEmbeddings;
class ONNXSTT;
class ONNXTTS;
class ONNXVAD;
class ONNXDiarization;

// =============================================================================
// ONNX BACKEND
// =============================================================================

class ONNXBackendNew : public Backend {
   public:
    ONNXBackendNew();
    ~ONNXBackendNew() override;

    // Backend interface
    BackendInfo get_info() const override;
    bool initialize(const nlohmann::json& config = {}) override;
    bool is_initialized() const override;
    void cleanup() override;

    ra_device_type get_device_type() const override;
    size_t get_memory_usage() const override;

    // Get ONNX Runtime API (for capability implementations)
    const OrtApi* get_ort_api() const { return ort_api_; }
    OrtEnv* get_ort_env() const { return ort_env_; }

    // Get device info
    const DeviceInfo& get_device_info() const { return device_info_; }

    // Set telemetry callback
    void set_telemetry_callback(TelemetryCallback callback);

   private:
    bool initialize_ort();
    void create_capabilities();

    bool initialized_ = false;
    const OrtApi* ort_api_ = nullptr;
    OrtEnv* ort_env_ = nullptr;
    nlohmann::json config_;
    DeviceInfo device_info_;
    TelemetryCollector telemetry_;
    mutable std::mutex mutex_;
};

// =============================================================================
// CAPABILITY IMPLEMENTATIONS
// =============================================================================

class ONNXTextGeneration : public ITextGeneration {
   public:
    explicit ONNXTextGeneration(ONNXBackendNew* backend);
    ~ONNXTextGeneration() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;

    TextGenerationResult generate(const TextGenerationRequest& request) override;
    bool generate_stream(const TextGenerationRequest& request,
                         TextStreamCallback callback) override;
    void cancel() override;
    nlohmann::json get_model_info() const override;

   private:
    ONNXBackendNew* backend_;
    OrtSession* session_ = nullptr;
    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};
    std::string model_path_;
    nlohmann::json model_config_;
    mutable std::mutex mutex_;
};

class ONNXEmbeddings : public IEmbeddings {
   public:
    explicit ONNXEmbeddings(ONNXBackendNew* backend);
    ~ONNXEmbeddings() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;

    EmbeddingResult embed(const EmbeddingRequest& request) override;
    BatchEmbeddingResult embed_batch(const std::vector<std::string>& texts) override;
    int get_dimensions() const override;

   private:
    ONNXBackendNew* backend_;
    OrtSession* session_ = nullptr;
    bool model_loaded_ = false;
    int dimensions_ = 0;
    mutable std::mutex mutex_;
};

class ONNXSTT : public ISTT {
   public:
    explicit ONNXSTT(ONNXBackendNew* backend);
    ~ONNXSTT() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, STTModelType model_type = STTModelType::WHISPER,
                    const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;
    STTModelType get_model_type() const override;

    STTResult transcribe(const STTRequest& request) override;
    bool supports_streaming() const override;

    std::string create_stream(const nlohmann::json& config = {}) override;
    bool feed_audio(const std::string& stream_id, const std::vector<float>& samples,
                    int sample_rate) override;
    bool is_stream_ready(const std::string& stream_id) override;
    STTResult decode(const std::string& stream_id) override;
    bool is_endpoint(const std::string& stream_id) override;
    void input_finished(const std::string& stream_id) override;
    void reset_stream(const std::string& stream_id) override;
    void destroy_stream(const std::string& stream_id) override;

    void cancel() override;
    std::vector<std::string> get_supported_languages() const override;

   private:
    ONNXBackendNew* backend_;
    OrtSession* whisper_session_ = nullptr;
#if SHERPA_ONNX_AVAILABLE
    const SherpaOnnxOfflineRecognizer* sherpa_recognizer_ = nullptr;
    // Map stream_id -> SherpaOnnxOfflineStream*
    std::unordered_map<std::string, const SherpaOnnxOfflineStream*> sherpa_streams_;
#else
    void* sherpa_recognizer_ = nullptr;
#endif
    STTModelType model_type_ = STTModelType::WHISPER;
    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};
    std::unordered_map<std::string, void*> streams_;
    int stream_counter_ = 0;
    std::string model_dir_;  // Directory containing model files
    std::string language_;   // Language for transcription
    mutable std::mutex mutex_;
};

class ONNXTTS : public ITTS {
   public:
    explicit ONNXTTS(ONNXBackendNew* backend);
    ~ONNXTTS() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, TTSModelType model_type = TTSModelType::PIPER,
                    const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;
    TTSModelType get_model_type() const override;

    TTSResult synthesize(const TTSRequest& request) override;
    bool synthesize_stream(const TTSRequest& request, TTSStreamCallback callback) override;
    bool supports_streaming() const override;

    void cancel() override;
    std::vector<VoiceInfo> get_voices() const override;
    std::string get_default_voice(const std::string& language) const override;

   private:
    ONNXBackendNew* backend_;
#if SHERPA_ONNX_AVAILABLE
    const SherpaOnnxOfflineTts* sherpa_tts_ = nullptr;
#else
    void* sherpa_tts_ = nullptr;
#endif
    TTSModelType model_type_ = TTSModelType::PIPER;
    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};
    std::atomic<int> active_synthesis_count_{0};  // Track active synthesis operations
    std::vector<VoiceInfo> voices_;
    std::string model_dir_;    // Directory containing model files
    int sample_rate_ = 22050;  // Default sample rate for VITS models
    mutable std::mutex mutex_;
};

class ONNXVAD : public IVAD {
   public:
    explicit ONNXVAD(ONNXBackendNew* backend);
    ~ONNXVAD() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path, VADModelType model_type = VADModelType::SILERO,
                    const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;

    bool configure_vad(const VADConfig& config) override;
    VADResult process(const std::vector<float>& audio_samples, int sample_rate) override;
    std::vector<SpeechSegment> detect_segments(const std::vector<float>& audio_samples,
                                               int sample_rate) override;

    std::string create_stream(const VADConfig& config = {}) override;
    VADResult feed_audio(const std::string& stream_id, const std::vector<float>& samples,
                         int sample_rate) override;
    void destroy_stream(const std::string& stream_id) override;

    void reset() override;
    VADConfig get_vad_config() const override;

   private:
    ONNXBackendNew* backend_;
    void* sherpa_vad_ = nullptr;
    VADConfig config_;
    bool model_loaded_ = false;
    mutable std::mutex mutex_;
};

class ONNXDiarization : public IDiarization {
   public:
    explicit ONNXDiarization(ONNXBackendNew* backend);
    ~ONNXDiarization() override;

    bool is_ready() const override;
    bool load_model(const std::string& model_path,
                    DiarizationModelType model_type = DiarizationModelType::SHERPA,
                    const nlohmann::json& config = {}) override;
    bool is_model_loaded() const override;
    bool unload_model() override;

    DiarizationResult diarize(const DiarizationRequest& request) override;
    std::vector<float> extract_embedding(const std::vector<float>& audio_samples,
                                         int sample_rate) override;
    float compare_speakers(const std::vector<float>& embedding1,
                           const std::vector<float>& embedding2) override;

    void cancel() override;

   private:
    ONNXBackendNew* backend_;
    void* sherpa_speaker_ = nullptr;
    bool model_loaded_ = false;
    std::atomic<bool> cancel_requested_{false};
    mutable std::mutex mutex_;
};

// =============================================================================
// BACKEND FACTORY & REGISTRATION
// =============================================================================

// Export macro for shared library builds (needed for Android)
#if defined(_WIN32)
#define RA_ONNX_EXPORT __declspec(dllexport)
#elif defined(__GNUC__) || defined(__clang__)
#define RA_ONNX_EXPORT __attribute__((visibility("default")))
#else
#define RA_ONNX_EXPORT
#endif

/**
 * Creates a new ONNX backend instance.
 *
 * This factory function is called by the bridge to create backend instances.
 * The registration is done by the bridge itself to avoid singleton issues
 * across shared libraries.
 */
RA_ONNX_EXPORT std::unique_ptr<Backend> create_onnx_backend();

/**
 * Explicitly registers the ONNX backend with the BackendRegistry.
 *
 * NOTE: For shared library builds (Android), prefer calling create_onnx_backend()
 * from the bridge and letting the bridge register it. This function calls
 * BackendRegistry::instance() which may create a separate singleton in each .so.
 *
 * For static library builds (iOS), this function works correctly.
 */
void register_onnx_backend();

}  // namespace runanywhere

// =============================================================================
// C-LINKAGE API (for runanywhere-commons)
// =============================================================================

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Opaque handle types for C API
 */
typedef struct ra_onnx_stt_handle_t* ra_onnx_stt_handle;
typedef struct ra_onnx_tts_handle_t* ra_onnx_tts_handle;
typedef struct ra_onnx_vad_handle_t* ra_onnx_vad_handle;

// =============================================================================
// STT (Speech-to-Text) C API
// =============================================================================

/**
 * STT configuration for model loading
 */
typedef struct ra_onnx_stt_config {
    int num_threads;       // 0 = auto-detect
    const char* language;  // Target language (e.g., "en", "auto" for detection)
    int use_gpu;           // Enable GPU acceleration (CoreML on iOS/macOS)
} ra_onnx_stt_config_t;

/**
 * Audio buffer for STT operations
 */
typedef struct ra_onnx_audio_buffer {
    const float* samples;  // PCM float samples (-1.0 to 1.0)
    int num_samples;       // Number of samples
    int sample_rate;       // Sample rate (e.g., 16000)
} ra_onnx_audio_buffer_t;

/**
 * Transcription result
 */
typedef struct ra_onnx_stt_result {
    char* text;               // Transcribed text (caller must free with ra_onnx_free_string)
    char* detected_language;  // Detected language code (optional, may be NULL)
    float confidence;         // Confidence score (0.0 - 1.0)
    int64_t duration_ms;      // Audio duration in milliseconds
} ra_onnx_stt_result_t;

/**
 * Creates a new ONNX STT service instance.
 * @param model_path Path to the model directory
 * @param config Configuration options (can be NULL for defaults)
 * @param out_handle Output handle on success
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_stt_create(const char* model_path, const ra_onnx_stt_config_t* config,
                                      ra_onnx_stt_handle* out_handle);

/**
 * Destroys an ONNX STT service instance.
 * @param handle Handle to destroy
 */
RA_ONNX_EXPORT void ra_onnx_stt_destroy(ra_onnx_stt_handle handle);

/**
 * Transcribes audio to text.
 * @param handle Service handle
 * @param audio Audio buffer containing PCM samples
 * @param out_result Output result structure
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_stt_transcribe(ra_onnx_stt_handle handle,
                                          const ra_onnx_audio_buffer_t* audio,
                                          ra_onnx_stt_result_t* out_result);

/**
 * Cancels an ongoing transcription.
 * @param handle Service handle
 */
RA_ONNX_EXPORT void ra_onnx_stt_cancel(ra_onnx_stt_handle handle);

/**
 * Checks if the STT model is ready.
 * @param handle Service handle
 * @return 1 if ready, 0 otherwise
 */
RA_ONNX_EXPORT int ra_onnx_stt_is_ready(ra_onnx_stt_handle handle);

/**
 * Frees an STT result structure.
 * @param result Result to free
 */
RA_ONNX_EXPORT void ra_onnx_stt_free_result(ra_onnx_stt_result_t* result);

// =============================================================================
// TTS (Text-to-Speech) C API
// =============================================================================

/**
 * TTS configuration for model loading
 */
typedef struct ra_onnx_tts_config {
    int num_threads;      // 0 = auto-detect
    int sample_rate;      // Output sample rate (0 = model default, usually 22050)
    float speaking_rate;  // Speaking rate multiplier (1.0 = normal)
} ra_onnx_tts_config_t;

/**
 * Synthesis result
 */
typedef struct ra_onnx_tts_result {
    float* samples;       // PCM float samples (caller must free with ra_onnx_free_samples)
    int num_samples;      // Number of samples
    int sample_rate;      // Sample rate of output audio
    int64_t duration_ms;  // Duration in milliseconds
} ra_onnx_tts_result_t;

/**
 * Streaming callback for TTS synthesis
 */
typedef void (*ra_onnx_tts_stream_callback)(const float* samples, int num_samples, int is_final,
                                            void* user_data);

/**
 * Creates a new ONNX TTS service instance.
 * @param model_path Path to the model directory
 * @param config Configuration options (can be NULL for defaults)
 * @param out_handle Output handle on success
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_tts_create(const char* model_path, const ra_onnx_tts_config_t* config,
                                      ra_onnx_tts_handle* out_handle);

/**
 * Destroys an ONNX TTS service instance.
 * @param handle Handle to destroy
 */
RA_ONNX_EXPORT void ra_onnx_tts_destroy(ra_onnx_tts_handle handle);

/**
 * Synthesizes text to audio.
 * @param handle Service handle
 * @param text Text to synthesize
 * @param voice Voice identifier (can be NULL for default)
 * @param out_result Output result structure
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_tts_synthesize(ra_onnx_tts_handle handle, const char* text,
                                          const char* voice, ra_onnx_tts_result_t* out_result);

/**
 * Synthesizes text to audio with streaming callback.
 * @param handle Service handle
 * @param text Text to synthesize
 * @param voice Voice identifier (can be NULL for default)
 * @param callback Function called for each audio chunk
 * @param user_data User data passed to callback
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_tts_synthesize_stream(ra_onnx_tts_handle handle, const char* text,
                                                 const char* voice,
                                                 ra_onnx_tts_stream_callback callback,
                                                 void* user_data);

/**
 * Cancels an ongoing synthesis.
 * @param handle Service handle
 */
RA_ONNX_EXPORT void ra_onnx_tts_cancel(ra_onnx_tts_handle handle);

/**
 * Checks if the TTS model is ready.
 * @param handle Service handle
 * @return 1 if ready, 0 otherwise
 */
RA_ONNX_EXPORT int ra_onnx_tts_is_ready(ra_onnx_tts_handle handle);

/**
 * Gets available voices as JSON array.
 * @param handle Service handle
 * @return JSON string (caller must free with ra_onnx_free_string) or NULL on error
 */
RA_ONNX_EXPORT char* ra_onnx_tts_get_voices(ra_onnx_tts_handle handle);

/**
 * Frees a TTS result structure.
 * @param result Result to free
 */
RA_ONNX_EXPORT void ra_onnx_tts_free_result(ra_onnx_tts_result_t* result);

// =============================================================================
// VAD (Voice Activity Detection) C API
// =============================================================================

/**
 * VAD configuration
 */
typedef struct ra_onnx_vad_config {
    float threshold;          // Speech probability threshold (default: 0.5)
    int min_silence_ms;       // Minimum silence duration to mark end of speech
    int min_speech_ms;        // Minimum speech duration to detect
    int window_size_samples;  // Processing window size (default: 512 for 16kHz)
} ra_onnx_vad_config_t;

/**
 * VAD result for a single frame
 */
typedef struct ra_onnx_vad_result {
    float speech_probability;  // Probability that frame contains speech (0.0 - 1.0)
    int is_speech;             // 1 if speech detected, 0 otherwise
    int64_t start_sample;      // Start sample index of detected speech segment
    int64_t end_sample;        // End sample index (0 if speech ongoing)
} ra_onnx_vad_result_t;

/**
 * Creates a new ONNX VAD service instance.
 * @param model_path Path to the VAD model file
 * @param config Configuration options (can be NULL for defaults)
 * @param out_handle Output handle on success
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_vad_create(const char* model_path, const ra_onnx_vad_config_t* config,
                                      ra_onnx_vad_handle* out_handle);

/**
 * Destroys an ONNX VAD service instance.
 * @param handle Handle to destroy
 */
RA_ONNX_EXPORT void ra_onnx_vad_destroy(ra_onnx_vad_handle handle);

/**
 * Processes audio and returns VAD result.
 * @param handle Service handle
 * @param audio Audio buffer (must be 16kHz mono)
 * @param out_result Output result structure
 * @return 0 on success, negative error code on failure
 */
RA_ONNX_EXPORT int ra_onnx_vad_process(ra_onnx_vad_handle handle,
                                       const ra_onnx_audio_buffer_t* audio,
                                       ra_onnx_vad_result_t* out_result);

/**
 * Resets VAD internal state.
 * @param handle Service handle
 */
RA_ONNX_EXPORT void ra_onnx_vad_reset(ra_onnx_vad_handle handle);

/**
 * Checks if the VAD model is ready.
 * @param handle Service handle
 * @return 1 if ready, 0 otherwise
 */
RA_ONNX_EXPORT int ra_onnx_vad_is_ready(ra_onnx_vad_handle handle);

/**
 * Returns the default VAD configuration.
 * @param out_config Output configuration structure
 */
RA_ONNX_EXPORT void ra_onnx_vad_get_default_config(ra_onnx_vad_config_t* out_config);

// =============================================================================
// Common Utility Functions
// =============================================================================

/**
 * Frees a string allocated by ONNX functions.
 * @param str String to free
 */
RA_ONNX_EXPORT void ra_onnx_free_string(char* str);

/**
 * Frees audio samples allocated by ONNX functions.
 * @param samples Samples to free
 */
RA_ONNX_EXPORT void ra_onnx_free_samples(float* samples);

#ifdef __cplusplus
}
#endif

#endif  // RUNANYWHERE_ONNX_BACKEND_H
