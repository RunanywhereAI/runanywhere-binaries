/**
 * RunAnywhere Unified Bridge Implementation
 *
 * This bridges the C++ capability-based backends to a C API
 * that can be consumed by iOS (Swift), Android (JNI), and Flutter (Dart FFI).
 */

#include "runanywhere_bridge.h"

#include "capabilities/backend.h"

// Backend headers - conditionally included based on build flags
#ifdef RA_ONNX_ENABLED
#include "backends/onnx/onnx_backend.h"
#endif

#ifdef RA_LLAMACPP_ENABLED
#include "backends/llamacpp/llamacpp_backend.h"
#endif

#ifdef RA_WHISPERCPP_ENABLED
#include "backends/whispercpp/whispercpp_backend.h"
#endif

#include <cerrno>
#include <cstring>
#include <iostream>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <unordered_map>
#include <vector>

#ifdef __ANDROID__
#include <android/log.h>
#endif

// Archive extraction support
// HAS_LIBARCHIVE is defined by CMake when libarchive is found
#ifdef HAS_LIBARCHIVE
// Use our compatibility header which provides the minimal libarchive declarations
// This works for both iOS (which has libarchive.tbd but no headers) and other platforms
#include "libarchive_compat.h"
#endif

// =============================================================================
// BACKEND REGISTRATION
// =============================================================================

// Ensure all backends are registered before use.
// This is needed because C++ static initializers in static libraries
// are not guaranteed to run when linked into iOS/macOS apps.
//
// IMPORTANT: For shared library builds (Android), we call BackendRegistry::instance()
// directly from the bridge and use the factory functions from each backend.
// This ensures all singleton access happens in the bridge library, avoiding
// the ODR violation where each .so gets its own static singleton instance.
static void ensure_backends_registered() {
    static bool initialized = false;
    if (!initialized) {
        auto& registry = runanywhere::BackendRegistry::instance();

#ifdef RA_ONNX_ENABLED
        registry.register_backend("onnx", runanywhere::create_onnx_backend);
#endif

#ifdef RA_LLAMACPP_ENABLED
        registry.register_backend("llamacpp", runanywhere::create_llamacpp_backend);
#endif

#ifdef RA_WHISPERCPP_ENABLED
        registry.register_backend("whispercpp", runanywhere::create_whispercpp_backend);
#endif

        // Add other backend registrations here as needed:
        // registry.register_backend("coreml", runanywhere::create_coreml_backend);
        initialized = true;
    }
}

// Thread-safe last error storage
static thread_local std::string g_last_error;

// Version string
static const char* g_version = "1.0.0";

// Backend name storage for ra_get_available_backends
static std::vector<const char*> g_backend_names;
static std::mutex g_backend_names_mutex;

// =============================================================================
// INTERNAL HELPERS
// =============================================================================

static void set_error(const std::string& error) {
    g_last_error = error;
}

static char* copy_string(const std::string& str) {
    char* result = static_cast<char*>(malloc(str.size() + 1));
    if (!result) {
        return nullptr;
    }
    std::memcpy(result, str.c_str(), str.size() + 1);
    return result;
}

static runanywhere::Backend* get_backend(ra_backend_handle handle) {
    return static_cast<runanywhere::Backend*>(handle);
}

static runanywhere::CapabilityType to_capability_type(ra_capability_type type) {
    switch (type) {
        case RA_CAP_TEXT_GENERATION:
            return runanywhere::CapabilityType::TEXT_GENERATION;
        case RA_CAP_EMBEDDINGS:
            return runanywhere::CapabilityType::EMBEDDINGS;
        case RA_CAP_STT:
            return runanywhere::CapabilityType::STT;
        case RA_CAP_TTS:
            return runanywhere::CapabilityType::TTS;
        case RA_CAP_VAD:
            return runanywhere::CapabilityType::VAD;
        case RA_CAP_DIARIZATION:
            return runanywhere::CapabilityType::DIARIZATION;
        default:
            return runanywhere::CapabilityType::TEXT_GENERATION;
    }
}

// =============================================================================
// BACKEND LIFECYCLE
// =============================================================================

const char** ra_get_available_backends(int* count) {
    // Ensure backends are registered before querying
    ensure_backends_registered();

    std::lock_guard<std::mutex> lock(g_backend_names_mutex);

    auto names = runanywhere::BackendRegistry::instance().get_available_backends();

    // Free previously allocated strings to prevent memory leak
    for (const char* ptr : g_backend_names) {
        free(const_cast<char*>(ptr));
    }
    g_backend_names.clear();

    for (const auto& name : names) {
        // Store as static strings (leaked intentionally for simplicity)
        char* copy = static_cast<char*>(malloc(name.size() + 1));
        if (!copy) {
            set_error("Memory allocation failed");
            if (count)
                *count = 0;
            return nullptr;
        }
        std::memcpy(copy, name.c_str(), name.size() + 1);
        g_backend_names.push_back(copy);
    }

    if (count) {
        *count = static_cast<int>(g_backend_names.size());
    }
    return g_backend_names.data();
}

ra_backend_handle ra_create_backend(const char* backend_name) {
    // Ensure backends are registered before creating
    ensure_backends_registered();

    if (!backend_name) {
        set_error("Backend name cannot be null");
        return nullptr;
    }

    auto backend = runanywhere::BackendRegistry::instance().create(backend_name);
    if (!backend) {
        set_error("Unknown backend: " + std::string(backend_name));
        return nullptr;
    }

    return backend.release();
}

ra_result_code ra_initialize(ra_backend_handle handle, const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend) {
        set_error("Invalid backend handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (const std::exception& e) {
            set_error("Invalid JSON config: " + std::string(e.what()));
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    if (!backend->initialize(config)) {
        set_error("Failed to initialize backend");
        return RA_ERROR_INIT_FAILED;
    }

    return RA_SUCCESS;
}

bool ra_is_initialized(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    return backend && backend->is_initialized();
}

void ra_destroy(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (backend) {
        backend->cleanup();
        delete backend;
    }
}

char* ra_get_backend_info(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend) {
        return nullptr;
    }

    auto info = backend->get_info();
    nlohmann::json j = {{"name", info.name},
                        {"version", info.version},
                        {"description", info.description},
                        {"capabilities", nlohmann::json::array()},
                        {"metadata", info.metadata}};

    for (auto cap : info.supported_capabilities) {
        j["capabilities"].push_back(runanywhere::capability_to_string(cap));
    }

    return copy_string(j.dump());
}

bool ra_supports_capability(ra_backend_handle handle, ra_capability_type capability) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    return backend->supports(to_capability_type(capability));
}

int ra_get_capabilities(ra_backend_handle handle, ra_capability_type* capabilities, int max_count) {
    auto* backend = get_backend(handle);
    if (!backend || !capabilities || max_count <= 0)
        return 0;

    auto caps = backend->get_supported_capabilities();
    int count = std::min(static_cast<int>(caps.size()), max_count);

    for (int i = 0; i < count; ++i) {
        switch (caps[i]) {
            case runanywhere::CapabilityType::TEXT_GENERATION:
                capabilities[i] = RA_CAP_TEXT_GENERATION;
                break;
            case runanywhere::CapabilityType::EMBEDDINGS:
                capabilities[i] = RA_CAP_EMBEDDINGS;
                break;
            case runanywhere::CapabilityType::STT:
                capabilities[i] = RA_CAP_STT;
                break;
            case runanywhere::CapabilityType::TTS:
                capabilities[i] = RA_CAP_TTS;
                break;
            case runanywhere::CapabilityType::VAD:
                capabilities[i] = RA_CAP_VAD;
                break;
            case runanywhere::CapabilityType::DIARIZATION:
                capabilities[i] = RA_CAP_DIARIZATION;
                break;
            default:
                break;
        }
    }

    return count;
}

ra_device_type ra_get_device(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_DEVICE_UNKNOWN;
    return backend->get_device_type();
}

size_t ra_get_memory_usage(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return 0;
    return backend->get_memory_usage();
}

// =============================================================================
// TEXT GENERATION
// =============================================================================

ra_result_code ra_text_load_model(ra_backend_handle handle, const char* model_path,
                                  const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap) {
        set_error("Backend does not support text generation");
        return RA_ERROR_NOT_IMPLEMENTED;
    }

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    if (!cap->load_model(model_path, config)) {
        set_error("Failed to load text generation model");
        return RA_ERROR_MODEL_LOAD_FAILED;
    }

    return RA_SUCCESS;
}

bool ra_text_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_text_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_text_generate(ra_backend_handle handle, const char* prompt,
                                const char* system_prompt, int max_tokens, float temperature,
                                char** result_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!prompt || !result_json)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::TextGenerationRequest request;
    request.prompt = prompt;
    if (system_prompt)
        request.system_prompt = system_prompt;
    request.max_tokens = max_tokens;
    request.temperature = temperature;

    try {
        auto result = cap->generate(request);
        *result_json = copy_string(result.to_json().dump());
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

ra_result_code ra_text_generate_stream(ra_backend_handle handle, const char* prompt,
                                       const char* system_prompt, int max_tokens, float temperature,
                                       ra_text_stream_callback callback, void* user_data) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!prompt || !callback)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::TextGenerationRequest request;
    request.prompt = prompt;
    if (system_prompt)
        request.system_prompt = system_prompt;
    request.max_tokens = max_tokens;
    request.temperature = temperature;

    try {
        bool success =
            cap->generate_stream(request, [callback, user_data](const std::string& token) {
                return callback(token.c_str(), user_data);
            });
        return success ? RA_SUCCESS : RA_ERROR_INFERENCE_FAILED;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

void ra_text_cancel(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (cap)
        cap->cancel();
}

int ra_text_get_context_length(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return 0;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap || !cap->is_model_loaded())
        return 0;

    // Get model info and extract context_size
    auto info = cap->get_model_info();
    if (info.contains("context_size")) {
        return info["context_size"].get<int>();
    }
    return 0;
}

char* ra_text_get_model_info(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return nullptr;

    auto* cap = backend->get_capability<runanywhere::ITextGeneration>();
    if (!cap || !cap->is_model_loaded())
        return nullptr;

    auto info = cap->get_model_info();
    return copy_string(info.dump());
}

// =============================================================================
// EMBEDDINGS
// =============================================================================

ra_result_code ra_embed_load_model(ra_backend_handle handle, const char* model_path,
                                   const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    return cap->load_model(model_path, config) ? RA_SUCCESS : RA_ERROR_MODEL_LOAD_FAILED;
}

bool ra_embed_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_embed_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;
    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_embed_text(ra_backend_handle handle, const char* text, float** embedding,
                             int* dimensions) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!text || !embedding || !dimensions)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::EmbeddingRequest request;
    request.text = text;

    try {
        auto result = cap->embed(request);
        *dimensions = result.dimensions;

        float* vec = static_cast<float*>(malloc(result.embedding.size() * sizeof(float)));
        std::memcpy(vec, result.embedding.data(), result.embedding.size() * sizeof(float));
        *embedding = vec;

        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

ra_result_code ra_embed_batch(ra_backend_handle handle, const char** texts, int num_texts,
                              float*** embeddings, int* dimensions) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!texts || !embeddings || !dimensions || num_texts <= 0)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    std::vector<std::string> text_vec;
    for (int i = 0; i < num_texts; ++i) {
        text_vec.push_back(texts[i] ? texts[i] : "");
    }

    try {
        auto result = cap->embed_batch(text_vec);
        *dimensions = result.dimensions;

        float** vecs = static_cast<float**>(malloc(num_texts * sizeof(float*)));
        for (int i = 0; i < num_texts; ++i) {
            vecs[i] = static_cast<float*>(malloc(result.dimensions * sizeof(float)));
            std::memcpy(vecs[i], result.embeddings[i].data(), result.dimensions * sizeof(float));
        }
        *embeddings = vecs;

        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

int ra_embed_get_dimensions(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return 0;
    auto* cap = backend->get_capability<runanywhere::IEmbeddings>();
    return cap ? cap->get_dimensions() : 0;
}

void ra_free_embedding(float* embedding) {
    free(embedding);
}

void ra_free_embeddings(float** embeddings, int count) {
    if (!embeddings)
        return;
    for (int i = 0; i < count; ++i) {
        free(embeddings[i]);
    }
    free(embeddings);
}

// =============================================================================
// SPEECH-TO-TEXT (STT)
// =============================================================================

static runanywhere::STTModelType parse_stt_model_type(const char* type) {
    if (!type)
        return runanywhere::STTModelType::WHISPER;
    std::string t = type;
    if (t == "whisper")
        return runanywhere::STTModelType::WHISPER;
    if (t == "zipformer")
        return runanywhere::STTModelType::ZIPFORMER;
    if (t == "paraformer")
        return runanywhere::STTModelType::PARAFORMER;
    if (t == "transducer")
        return runanywhere::STTModelType::TRANSDUCER;
    return runanywhere::STTModelType::CUSTOM;
}

ra_result_code ra_stt_load_model(ra_backend_handle handle, const char* model_path,
                                 const char* model_type, const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    auto type = parse_stt_model_type(model_type);
    return cap->load_model(model_path, type, config) ? RA_SUCCESS : RA_ERROR_MODEL_LOAD_FAILED;
}

bool ra_stt_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::ISTT>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_stt_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;
    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_stt_transcribe(ra_backend_handle handle, const float* audio_samples,
                                 size_t num_samples, int sample_rate, const char* language,
                                 char** result_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!audio_samples || !result_json)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::STTRequest request;
    request.audio_samples.assign(audio_samples, audio_samples + num_samples);
    request.sample_rate = sample_rate;
    if (language)
        request.language = language;

    try {
        auto result = cap->transcribe(request);
        *result_json = copy_string(result.to_json().dump());
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

bool ra_stt_supports_streaming(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::ISTT>();
    return cap && cap->supports_streaming();
}

// Stream management with internal maps
// Forward map: stream_id (string) -> opaque handle (void*)
// Reverse map: opaque handle (void*) -> stream_id (string)
static std::unordered_map<std::string, ra_stream_handle> g_stt_streams;
static std::unordered_map<intptr_t, std::string> g_stt_stream_ids;  // Reverse lookup
static std::mutex g_stt_streams_mutex;
static int g_stt_stream_counter = 0;

// Helper to get stream_id from opaque handle
static std::string get_stream_id(ra_stream_handle stream) {
    std::lock_guard<std::mutex> lock(g_stt_streams_mutex);
    intptr_t handle_val = reinterpret_cast<intptr_t>(stream);
    auto it = g_stt_stream_ids.find(handle_val);
    if (it != g_stt_stream_ids.end()) {
        return it->second;
    }
    return "";
}

ra_stream_handle ra_stt_create_stream(ra_backend_handle handle, const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return nullptr;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return nullptr;

    // Note: We allow stream creation even for non-streaming models
    // This enables batch processing through the stream interface

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return nullptr;
        }
    }

    std::string stream_id = cap->create_stream(config);
    if (stream_id.empty())
        return nullptr;

    std::lock_guard<std::mutex> lock(g_stt_streams_mutex);
    // Use a simple integer as the opaque handle
    intptr_t handle_val = ++g_stt_stream_counter;
    // NOLINTNEXTLINE(performance-no-int-to-ptr) - Intentional C API handle conversion
    void* stream_handle = reinterpret_cast<void*>(handle_val);

    // Store both forward and reverse mappings
    g_stt_streams[stream_id] = stream_handle;
    g_stt_stream_ids[handle_val] = stream_id;

    return stream_handle;
}

ra_result_code ra_stt_feed_audio(ra_backend_handle handle, ra_stream_handle stream,
                                 const float* samples, size_t num_samples, int sample_rate) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!samples || num_samples == 0)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty()) {
        set_error("Invalid stream handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::vector<float> audio_samples(samples, samples + num_samples);
    bool success = cap->feed_audio(stream_id, audio_samples, sample_rate);

    return success ? RA_SUCCESS : RA_ERROR_INFERENCE_FAILED;
}

bool ra_stt_is_ready(ra_backend_handle handle, ra_stream_handle stream) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return false;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty())
        return false;

    return cap->is_stream_ready(stream_id);
}

ra_result_code ra_stt_decode(ra_backend_handle handle, ra_stream_handle stream,
                             char** result_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!result_json)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty()) {
        set_error("Invalid stream handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    try {
        auto result = cap->decode(stream_id);
        *result_json = copy_string(result.to_json().dump());
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

bool ra_stt_is_endpoint(ra_backend_handle handle, ra_stream_handle stream) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return false;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty())
        return false;

    return cap->is_endpoint(stream_id);
}

void ra_stt_input_finished(ra_backend_handle handle, ra_stream_handle stream) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty())
        return;

    cap->input_finished(stream_id);
}

void ra_stt_reset_stream(ra_backend_handle handle, ra_stream_handle stream) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty())
        return;

    cap->reset_stream(stream_id);
}

void ra_stt_destroy_stream(ra_backend_handle handle, ra_stream_handle stream) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;

    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (!cap)
        return;

    std::string stream_id = get_stream_id(stream);
    if (stream_id.empty())
        return;

    // Cleanup the stream in the capability
    cap->destroy_stream(stream_id);

    // Remove from our tracking maps
    std::lock_guard<std::mutex> lock(g_stt_streams_mutex);
    intptr_t handle_val = reinterpret_cast<intptr_t>(stream);
    g_stt_streams.erase(stream_id);
    g_stt_stream_ids.erase(handle_val);
}

void ra_stt_cancel(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;
    auto* cap = backend->get_capability<runanywhere::ISTT>();
    if (cap)
        cap->cancel();
}

// =============================================================================
// TEXT-TO-SPEECH (TTS)
// =============================================================================

static runanywhere::TTSModelType parse_tts_model_type(const char* type) {
    if (!type)
        return runanywhere::TTSModelType::PIPER;
    std::string t = type;
    if (t == "piper")
        return runanywhere::TTSModelType::PIPER;
    if (t == "kitten")
        return runanywhere::TTSModelType::PIPER;  // KittenTTS uses same VITS config as Piper
    if (t == "vits")
        return runanywhere::TTSModelType::PIPER;  // VITS models use PIPER type
    if (t == "coqui")
        return runanywhere::TTSModelType::COQUI;
    if (t == "bark")
        return runanywhere::TTSModelType::BARK;
    if (t == "espeak")
        return runanywhere::TTSModelType::ESPEAK;
    return runanywhere::TTSModelType::CUSTOM;
}

ra_result_code ra_tts_load_model(ra_backend_handle handle, const char* model_path,
                                 const char* model_type, const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    auto type = parse_tts_model_type(model_type);
    return cap->load_model(model_path, type, config) ? RA_SUCCESS : RA_ERROR_MODEL_LOAD_FAILED;
}

bool ra_tts_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::ITTS>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_tts_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;
    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_tts_synthesize(ra_backend_handle handle, const char* text, const char* voice_id,
                                 float speed_rate, float pitch_shift, float** audio_samples,
                                 size_t* num_samples, int* sample_rate) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!text || !audio_samples || !num_samples || !sample_rate)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::TTSRequest request;
    request.text = text;
    if (voice_id)
        request.voice_id = voice_id;
    request.speed_rate = speed_rate;
    request.pitch_shift = pitch_shift;

    try {
        auto result = cap->synthesize(request);

        float* samples = static_cast<float*>(malloc(result.audio_samples.size() * sizeof(float)));
        std::memcpy(samples, result.audio_samples.data(),
                    result.audio_samples.size() * sizeof(float));

        *audio_samples = samples;
        *num_samples = result.audio_samples.size();
        *sample_rate = result.sample_rate;

        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

ra_result_code ra_tts_synthesize_stream(ra_backend_handle handle, const char* text,
                                        const char* voice_id, float speed_rate, float pitch_shift,
                                        ra_tts_stream_callback callback, void* user_data) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!text || !callback)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (!cap || !cap->supports_streaming())
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::TTSRequest request;
    request.text = text;
    if (voice_id)
        request.voice_id = voice_id;
    request.speed_rate = speed_rate;
    request.pitch_shift = pitch_shift;

    try {
        bool success = cap->synthesize_stream(
            request, [callback, user_data](const std::vector<float>& chunk, bool is_final) {
                return callback(chunk.data(), chunk.size(), is_final, user_data);
            });
        return success ? RA_SUCCESS : RA_ERROR_INFERENCE_FAILED;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

bool ra_tts_supports_streaming(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::ITTS>();
    return cap && cap->supports_streaming();
}

char* ra_tts_get_voices(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return nullptr;

    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (!cap)
        return nullptr;

    auto voices = cap->get_voices();
    nlohmann::json j = nlohmann::json::array();
    for (const auto& v : voices) {
        j.push_back({{"id", v.id},
                     {"name", v.name},
                     {"language", v.language},
                     {"gender", v.gender},
                     {"description", v.description},
                     {"sample_rate", v.sample_rate}});
    }

    return copy_string(j.dump());
}

void ra_tts_cancel(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;
    auto* cap = backend->get_capability<runanywhere::ITTS>();
    if (cap)
        cap->cancel();
}

void ra_free_audio(float* audio_samples) {
    free(audio_samples);
}

// =============================================================================
// VOICE ACTIVITY DETECTION (VAD)
// =============================================================================

ra_result_code ra_vad_load_model(ra_backend_handle handle, const char* model_path,
                                 const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::IVAD>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    return cap->load_model(model_path ? model_path : "", runanywhere::VADModelType::SILERO, config)
               ? RA_SUCCESS
               : RA_ERROR_MODEL_LOAD_FAILED;
}

bool ra_vad_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::IVAD>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_vad_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    auto* cap = backend->get_capability<runanywhere::IVAD>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;
    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_vad_process(ra_backend_handle handle, const float* samples, size_t num_samples,
                              int sample_rate, bool* is_speech, float* probability) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!samples || !is_speech || !probability)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::IVAD>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    std::vector<float> audio(samples, samples + num_samples);

    try {
        auto result = cap->process(audio, sample_rate);
        *is_speech = result.is_speech;
        *probability = result.probability;
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

ra_result_code ra_vad_detect_segments(ra_backend_handle handle, const float* samples,
                                      size_t num_samples, int sample_rate, char** result_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!samples || !result_json)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::IVAD>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    std::vector<float> audio(samples, samples + num_samples);

    try {
        auto segments = cap->detect_segments(audio, sample_rate);
        nlohmann::json j = nlohmann::json::array();
        for (const auto& seg : segments) {
            j.push_back({{"start_ms", seg.start_time_ms},
                         {"end_ms", seg.end_time_ms},
                         {"confidence", seg.confidence}});
        }
        *result_json = copy_string(j.dump());
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

ra_stream_handle ra_vad_create_stream(ra_backend_handle handle, const char* config_json) {
    (void)handle;       // Suppress unused parameter warning
    (void)config_json;  // Suppress unused parameter warning
    // TODO: Implement
    return nullptr;
}

ra_result_code ra_vad_feed_stream(ra_backend_handle handle, ra_stream_handle stream,
                                  const float* samples, size_t num_samples, int sample_rate,
                                  bool* is_speech, float* probability) {
    (void)handle;       // Suppress unused parameter warning
    (void)stream;       // Suppress unused parameter warning
    (void)samples;      // Suppress unused parameter warning
    (void)num_samples;  // Suppress unused parameter warning
    (void)sample_rate;  // Suppress unused parameter warning
    (void)is_speech;    // Suppress unused parameter warning
    (void)probability;  // Suppress unused parameter warning
    // TODO: Implement
    return RA_ERROR_NOT_IMPLEMENTED;
}

void ra_vad_destroy_stream(ra_backend_handle handle, ra_stream_handle stream) {
    (void)handle;  // Suppress unused parameter warning
    (void)stream;  // Suppress unused parameter warning
    // TODO: Implement
}

void ra_vad_reset(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;
    auto* cap = backend->get_capability<runanywhere::IVAD>();
    if (cap)
        cap->reset();
}

// =============================================================================
// SPEAKER DIARIZATION
// =============================================================================

ra_result_code ra_diarize_load_model(ra_backend_handle handle, const char* model_path,
                                     const char* config_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;

    auto* cap = backend->get_capability<runanywhere::IDiarization>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    nlohmann::json config;
    if (config_json != nullptr && config_json[0] != '\0') {
        try {
            config = nlohmann::json::parse(config_json);
        } catch (...) {
            return RA_ERROR_INVALID_PARAMS;
        }
    }

    return cap->load_model(model_path, runanywhere::DiarizationModelType::SHERPA, config)
               ? RA_SUCCESS
               : RA_ERROR_MODEL_LOAD_FAILED;
}

bool ra_diarize_is_model_loaded(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return false;
    auto* cap = backend->get_capability<runanywhere::IDiarization>();
    return cap && cap->is_model_loaded();
}

ra_result_code ra_diarize_unload_model(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    auto* cap = backend->get_capability<runanywhere::IDiarization>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;
    return cap->unload_model() ? RA_SUCCESS : RA_ERROR_UNKNOWN;
}

ra_result_code ra_diarize(ra_backend_handle handle, const float* samples, size_t num_samples,
                          int sample_rate, int min_speakers, int max_speakers, char** result_json) {
    auto* backend = get_backend(handle);
    if (!backend)
        return RA_ERROR_INVALID_HANDLE;
    if (!samples || !result_json)
        return RA_ERROR_INVALID_PARAMS;

    auto* cap = backend->get_capability<runanywhere::IDiarization>();
    if (!cap)
        return RA_ERROR_NOT_IMPLEMENTED;

    runanywhere::DiarizationRequest request;
    request.audio_samples.assign(samples, samples + num_samples);
    request.sample_rate = sample_rate;
    request.min_speakers = min_speakers;
    request.max_speakers = max_speakers;

    try {
        auto result = cap->diarize(request);
        *result_json = copy_string(result.to_json().dump());
        return RA_SUCCESS;
    } catch (const std::exception& e) {
        set_error(e.what());
        return RA_ERROR_INFERENCE_FAILED;
    }
}

void ra_diarize_cancel(ra_backend_handle handle) {
    auto* backend = get_backend(handle);
    if (!backend)
        return;
    auto* cap = backend->get_capability<runanywhere::IDiarization>();
    if (cap)
        cap->cancel();
}

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

void ra_free_string(char* str) {
    free(str);
}

ra_result_code ra_extract_archive(const char* archive_path, const char* dest_dir) {
#ifdef HAS_LIBARCHIVE
    if (!archive_path || !dest_dir) {
        set_error("Invalid parameters for archive extraction");
        return RA_ERROR_INVALID_PARAMS;
    }

    std::cout << "[RA_ARCHIVE] Extracting: " << archive_path << " -> " << dest_dir << std::endl;

    // Create destination directory if it doesn't exist (recursive mkdir)
    // Use POSIX mkdir() instead of system() for iOS compatibility
    {
        std::string path(dest_dir);
        size_t pos = 0;
        while ((pos = path.find('/', pos + 1)) != std::string::npos) {
            std::string subdir = path.substr(0, pos);
            if (!subdir.empty()) {
                if (mkdir(subdir.c_str(), 0755) != 0 && errno != EEXIST) {
                    set_error("Failed to create intermediate directory: " + subdir);
                    return RA_ERROR_IO;
                }
            }
        }
        // Create the final directory
        if (mkdir(path.c_str(), 0755) != 0 && errno != EEXIST) {
            set_error("Failed to create destination directory");
            return RA_ERROR_IO;
        }
    }

    // Initialize archive reader
    struct archive* a = archive_read_new();
    if (!a) {
        set_error("Failed to create archive reader");
        return RA_ERROR_OUT_OF_MEMORY;
    }

    // Support all common formats
    archive_read_support_filter_all(a);  // gzip, bzip2, xz, lz4, zstd, etc.
    archive_read_support_format_all(a);  // tar, zip, etc.

    // Initialize disk writer
    struct archive* ext = archive_write_disk_new();
    if (!ext) {
        archive_read_free(a);
        set_error("Failed to create disk writer");
        return RA_ERROR_OUT_OF_MEMORY;
    }

    // Set extraction options
    int flags =
        ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_ACL | ARCHIVE_EXTRACT_FFLAGS;
    archive_write_disk_set_options(ext, flags);
    archive_write_disk_set_standard_lookup(ext);

    // Open archive
    int r = archive_read_open_filename(a, archive_path, 10240);
    if (r != ARCHIVE_OK) {
        std::string err = "Failed to open archive: ";
        err += archive_error_string(a);
        set_error(err);
        archive_read_free(a);
        archive_write_free(ext);
        return RA_ERROR_IO;
    }

    std::cout << "[RA_ARCHIVE] Archive opened successfully" << std::endl;

    // Extract entries
    struct archive_entry* entry;
    int file_count = 0;
    std::string dest_dir_str(dest_dir);

    while (archive_read_next_header(a, &entry) == ARCHIVE_OK) {
        // Get the entry pathname
        const char* current_file = archive_entry_pathname(entry);

        // Construct full output path
        std::string full_path = dest_dir_str + "/" + current_file;
        archive_entry_set_pathname(entry, full_path.c_str());

        // Write header
        r = archive_write_header(ext, entry);
        if (r != ARCHIVE_OK) {
            std::cerr << "[RA_ARCHIVE] Warning: Failed to write header for " << current_file << ": "
                      << archive_error_string(ext) << std::endl;
        } else {
            // Copy data
            const void* buff;
            size_t size;
            la_int64_t offset;

            while (archive_read_data_block(a, &buff, &size, &offset) == ARCHIVE_OK) {
                if (archive_write_data_block(ext, buff, size, offset) != ARCHIVE_OK) {
                    std::cerr << "[RA_ARCHIVE] Warning: Write error for " << current_file
                              << std::endl;
                    break;
                }
            }

            archive_write_finish_entry(ext);
            file_count++;
        }
    }

    // Cleanup
    archive_read_close(a);
    archive_read_free(a);
    archive_write_close(ext);
    archive_write_free(ext);

    std::cout << "[RA_ARCHIVE] Extracted " << file_count << " files successfully" << std::endl;

    return RA_SUCCESS;
#else
    (void)archive_path;
    (void)dest_dir;
    set_error("Archive extraction not available (libarchive not linked)");
    return RA_ERROR_NOT_IMPLEMENTED;
#endif
}

const char* ra_get_last_error(void) {
    return g_last_error.c_str();
}

const char* ra_get_version(void) {
    return g_version;
}
