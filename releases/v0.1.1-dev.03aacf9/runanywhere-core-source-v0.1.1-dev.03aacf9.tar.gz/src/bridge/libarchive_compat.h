/**
 * Minimal libarchive compatibility header for iOS
 *
 * iOS includes libarchive.tbd but not the headers.
 * This provides the minimal declarations needed for our archive extraction code.
 */

#ifndef LIBARCHIVE_COMPAT_H
#define LIBARCHIVE_COMPAT_H

#include <stddef.h>
#include <stdint.h>

#include <sys/types.h>

// libarchive uses la_int64_t for offsets
typedef int64_t la_int64_t;

#ifdef __cplusplus
extern "C" {
#endif

// Opaque types
struct archive;
struct archive_entry;

// Return values
#define ARCHIVE_OK 0
#define ARCHIVE_EOF 1
#define ARCHIVE_RETRY (-10)
#define ARCHIVE_WARN (-20)
#define ARCHIVE_FAILED (-25)
#define ARCHIVE_FATAL (-30)

// Extraction flags
#define ARCHIVE_EXTRACT_TIME (0x0004)
#define ARCHIVE_EXTRACT_PERM (0x0002)
#define ARCHIVE_EXTRACT_ACL (0x0020)
#define ARCHIVE_EXTRACT_FFLAGS (0x0040)

// Archive reader functions
struct archive* archive_read_new(void);
int archive_read_support_filter_all(struct archive*);
int archive_read_support_format_all(struct archive*);
int archive_read_open_filename(struct archive*, const char* filename, size_t block_size);
int archive_read_next_header(struct archive*, struct archive_entry**);
int archive_read_data_block(struct archive*, const void** buff, size_t* size, la_int64_t* offset);
int archive_read_close(struct archive*);
int archive_read_free(struct archive*);

// Archive writer (disk) functions
struct archive* archive_write_disk_new(void);
int archive_write_disk_set_options(struct archive*, int flags);
int archive_write_disk_set_standard_lookup(struct archive*);
int archive_write_header(struct archive*, struct archive_entry*);
int archive_write_data_block(struct archive*, const void* buff, size_t size, off_t offset);
int archive_write_finish_entry(struct archive*);
int archive_write_close(struct archive*);
int archive_write_free(struct archive*);

// Archive entry functions
const char* archive_entry_pathname(struct archive_entry*);
void archive_entry_set_pathname(struct archive_entry*, const char* pathname);

// Error handling
const char* archive_error_string(struct archive*);

#ifdef __cplusplus
}
#endif

#endif  // LIBARCHIVE_COMPAT_H
