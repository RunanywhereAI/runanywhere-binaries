/**
 * RunAnywhere JNI Bridge
 *
 * This is the JNI layer that wraps the C API (runanywhere_bridge.h) for Android.
 * It provides a thin wrapper that exposes all C API functions via JNI.
 *
 * Package: com.runanywhere.sdk.native.bridge
 * Class: RunAnywhereBridge
 *
 * Design principles:
 * 1. Thin wrapper - minimal logic, just data conversion
 * 2. Direct mapping to C API functions
 * 3. Consistent error handling via exceptions
 * 4. Memory safety with proper cleanup
 */

#include <dlfcn.h>
#include <jni.h>

#include <android/log.h>
#include <cstring>
#include <string>
#include <vector>

#include "../runanywhere_bridge.h"

#define TAG "RunAnywhereJNI"
#define LOGi(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGe(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGw(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

// =============================================================================
// Helper Functions
// =============================================================================

static void throwException(JNIEnv* env, const char* className, const char* message) {
    jclass exClass = env->FindClass(className);
    if (exClass != nullptr) {
        env->ThrowNew(exClass, message);
    }
}

static void throwRuntimeException(JNIEnv* env, const char* message) {
    throwException(env, "java/lang/RuntimeException", message);
}

static void throwIllegalStateException(JNIEnv* env, const char* message) {
    throwException(env, "java/lang/IllegalStateException", message);
}

static void throwIllegalArgumentException(JNIEnv* env, const char* message) {
    throwException(env, "java/lang/IllegalArgumentException", message);
}

// Convert ra_result_code to exception if needed
static bool checkResult(JNIEnv* env, ra_result_code result) {
    if (result == RA_SUCCESS) {
        return true;
    }

    const char* errorMsg = ra_get_last_error();
    if (errorMsg == nullptr || strlen(errorMsg) == 0) {
        errorMsg = "Unknown error";
    }

    switch (result) {
        case RA_ERROR_INVALID_PARAMS:
            throwIllegalArgumentException(env, errorMsg);
            break;
        case RA_ERROR_INVALID_HANDLE:
            throwIllegalStateException(env, errorMsg);
            break;
        default:
            throwRuntimeException(env, errorMsg);
            break;
    }
    return false;
}

// Helper to get C string from jstring (returns empty string if null)
static std::string getCString(JNIEnv* env, jstring str) {
    if (str == nullptr) {
        return "";
    }
    const char* chars = env->GetStringUTFChars(str, nullptr);
    std::string result(chars);
    env->ReleaseStringUTFChars(str, chars);
    return result;
}

// Helper to get nullable C string pointer
static const char* getNullableCString(JNIEnv* env, jstring str, std::string& storage) {
    if (str == nullptr) {
        return nullptr;
    }
    storage = getCString(env, str);
    return storage.c_str();
}

// =============================================================================
// JNI Functions - Backend Lifecycle
// =============================================================================

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeCreateBackend(JNIEnv* env,
                                                                             jclass clazz,
                                                                             jstring backendName) {
    std::string name = getCString(env, backendName);
    LOGi("Creating backend: %s", name.c_str());

    ra_backend_handle handle = ra_create_backend(name.c_str());
    if (handle == nullptr) {
        throwRuntimeException(env, "Failed to create backend");
        return 0;
    }

    return reinterpret_cast<jlong>(handle);
}

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeInitialize(
    JNIEnv* env, jclass clazz, jlong handle, jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    ra_result_code result = ra_initialize(reinterpret_cast<ra_backend_handle>(handle), config);

    if (result != RA_SUCCESS) {
        LOGe("Initialize failed: %s", ra_get_last_error());
    }

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeIsInitialized(JNIEnv* env,
                                                                             jclass clazz,
                                                                             jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_is_initialized(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDestroy(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        LOGi("Destroying backend");
        ra_destroy(reinterpret_cast<ra_backend_handle>(handle));
    }
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetBackendInfo(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    char* info = ra_get_backend_info(reinterpret_cast<ra_backend_handle>(handle));
    if (info == nullptr) {
        return env->NewStringUTF("{}");
    }

    jstring result = env->NewStringUTF(info);
    ra_free_string(info);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSupportsCapability(JNIEnv* env,
                                                                                  jclass clazz,
                                                                                  jlong handle,
                                                                                  jint capability) {
    if (handle == 0)
        return JNI_FALSE;

    return ra_supports_capability(reinterpret_cast<ra_backend_handle>(handle),
                                  static_cast<ra_capability_type>(capability))
               ? JNI_TRUE
               : JNI_FALSE;
}

JNIEXPORT jintArray JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetCapabilities(JNIEnv* env,
                                                                               jclass clazz,
                                                                               jlong handle) {
    if (handle == 0) {
        return env->NewIntArray(0);
    }

    ra_capability_type capabilities[10];
    int count = ra_get_capabilities(reinterpret_cast<ra_backend_handle>(handle), capabilities, 10);

    jintArray result = env->NewIntArray(count);
    if (count > 0) {
        jint* jcaps = new jint[count];
        for (int i = 0; i < count; i++) {
            jcaps[i] = static_cast<jint>(capabilities[i]);
        }
        env->SetIntArrayRegion(result, 0, count, jcaps);
        delete[] jcaps;
    }
    return result;
}

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetDevice(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle == 0)
        return RA_DEVICE_CPU;
    return static_cast<jint>(ra_get_device(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jlong JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetMemoryUsage(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle) {
    if (handle == 0)
        return 0;
    return static_cast<jlong>(ra_get_memory_usage(reinterpret_cast<ra_backend_handle>(handle)));
}

// =============================================================================
// JNI Functions - Text Generation
// =============================================================================

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTextLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string path = getCString(env, modelPath);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    LOGi("Loading text model from: %s", path.c_str());

    ra_result_code result =
        ra_text_load_model(reinterpret_cast<ra_backend_handle>(handle), path.c_str(), config);

    if (result != RA_SUCCESS) {
        LOGe("Text model load failed: %s", ra_get_last_error());
    }

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTextIsModelLoaded(JNIEnv* env,
                                                                                 jclass clazz,
                                                                                 jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_text_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                                : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTextUnloadModel(JNIEnv* env,
                                                                               jclass clazz,
                                                                               jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_text_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTextGenerate(
    JNIEnv* env, jclass clazz, jlong handle, jstring prompt, jstring systemPrompt, jint maxTokens,
    jfloat temperature) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    std::string promptStr = getCString(env, prompt);
    std::string systemStorage;
    const char* system = getNullableCString(env, systemPrompt, systemStorage);

    char* resultJson = nullptr;
    ra_result_code result =
        ra_text_generate(reinterpret_cast<ra_backend_handle>(handle), promptStr.c_str(), system,
                         maxTokens, temperature, &resultJson);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    if (resultJson == nullptr) {
        return env->NewStringUTF("{}");
    }

    jstring jresult = env->NewStringUTF(resultJson);
    ra_free_string(resultJson);
    return jresult;
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTextCancel(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        ra_text_cancel(reinterpret_cast<ra_backend_handle>(handle));
    }
}

// =============================================================================
// JNI Functions - Speech-to-Text (STT)
// =============================================================================

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring modelType,
    jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string path = getCString(env, modelPath);
    std::string type = getCString(env, modelType);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    LOGi("Loading STT model from: %s (type: %s)", path.c_str(), type.c_str());

    ra_result_code result = ra_stt_load_model(reinterpret_cast<ra_backend_handle>(handle),
                                              path.c_str(), type.c_str(), config);

    if (result != RA_SUCCESS) {
        LOGe("STT model load failed: %s", ra_get_last_error());
    }

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTIsModelLoaded(JNIEnv* env,
                                                                                jclass clazz,
                                                                                jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_stt_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                               : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTUnloadModel(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_stt_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTTranscribe(
    JNIEnv* env, jclass clazz, jlong handle, jfloatArray audioSamples, jint sampleRate,
    jstring language) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    jsize numSamples = env->GetArrayLength(audioSamples);
    jfloat* samples = env->GetFloatArrayElements(audioSamples, nullptr);

    std::string langStorage;
    const char* lang = getNullableCString(env, language, langStorage);

    char* resultJson = nullptr;
    ra_result_code result =
        ra_stt_transcribe(reinterpret_cast<ra_backend_handle>(handle), samples,
                          static_cast<size_t>(numSamples), sampleRate, lang, &resultJson);

    env->ReleaseFloatArrayElements(audioSamples, samples, JNI_ABORT);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    if (resultJson == nullptr) {
        return env->NewStringUTF("{}");
    }

    jstring jresult = env->NewStringUTF(resultJson);
    ra_free_string(resultJson);
    return jresult;
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTSupportsStreaming(JNIEnv* env,
                                                                                    jclass clazz,
                                                                                    jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_stt_supports_streaming(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                                  : JNI_FALSE;
}

JNIEXPORT jlong JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTCreateStream(JNIEnv* env,
                                                                               jclass clazz,
                                                                               jlong handle,
                                                                               jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return 0;
    }

    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    ra_stream_handle stream =
        ra_stt_create_stream(reinterpret_cast<ra_backend_handle>(handle), config);

    return reinterpret_cast<jlong>(stream);
}

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTFeedAudio(
    JNIEnv* env, jclass clazz, jlong handle, jlong streamHandle, jfloatArray audioSamples,
    jint sampleRate) {
    if (handle == 0 || streamHandle == 0) {
        return RA_ERROR_INVALID_HANDLE;
    }

    jsize numSamples = env->GetArrayLength(audioSamples);
    jfloat* samples = env->GetFloatArrayElements(audioSamples, nullptr);

    ra_result_code result = ra_stt_feed_audio(reinterpret_cast<ra_backend_handle>(handle),
                                              reinterpret_cast<ra_stream_handle>(streamHandle),
                                              samples, static_cast<size_t>(numSamples), sampleRate);

    env->ReleaseFloatArrayElements(audioSamples, samples, JNI_ABORT);
    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTIsReady(JNIEnv* env, jclass clazz,
                                                                          jlong handle,
                                                                          jlong streamHandle) {
    if (handle == 0 || streamHandle == 0)
        return JNI_FALSE;

    return ra_stt_is_ready(reinterpret_cast<ra_backend_handle>(handle),
                           reinterpret_cast<ra_stream_handle>(streamHandle))
               ? JNI_TRUE
               : JNI_FALSE;
}

JNIEXPORT jstring JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTDecode(
    JNIEnv* env, jclass clazz, jlong handle, jlong streamHandle) {
    if (handle == 0 || streamHandle == 0) {
        return env->NewStringUTF("{}");
    }

    char* resultJson = nullptr;
    ra_result_code result =
        ra_stt_decode(reinterpret_cast<ra_backend_handle>(handle),
                      reinterpret_cast<ra_stream_handle>(streamHandle), &resultJson);

    if (result != RA_SUCCESS || resultJson == nullptr) {
        return env->NewStringUTF("{}");
    }

    jstring jresult = env->NewStringUTF(resultJson);
    ra_free_string(resultJson);
    return jresult;
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTIsEndpoint(JNIEnv* env,
                                                                             jclass clazz,
                                                                             jlong handle,
                                                                             jlong streamHandle) {
    if (handle == 0 || streamHandle == 0)
        return JNI_FALSE;

    return ra_stt_is_endpoint(reinterpret_cast<ra_backend_handle>(handle),
                              reinterpret_cast<ra_stream_handle>(streamHandle))
               ? JNI_TRUE
               : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTInputFinished(
    JNIEnv* env, jclass clazz, jlong handle, jlong streamHandle) {
    if (handle != 0 && streamHandle != 0) {
        ra_stt_input_finished(reinterpret_cast<ra_backend_handle>(handle),
                              reinterpret_cast<ra_stream_handle>(streamHandle));
    }
}

JNIEXPORT void JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTResetStream(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle,
                                                                              jlong streamHandle) {
    if (handle != 0 && streamHandle != 0) {
        ra_stt_reset_stream(reinterpret_cast<ra_backend_handle>(handle),
                            reinterpret_cast<ra_stream_handle>(streamHandle));
    }
}

JNIEXPORT void JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTDestroyStream(
    JNIEnv* env, jclass clazz, jlong handle, jlong streamHandle) {
    if (handle != 0 && streamHandle != 0) {
        ra_stt_destroy_stream(reinterpret_cast<ra_backend_handle>(handle),
                              reinterpret_cast<ra_stream_handle>(streamHandle));
    }
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeSTTCancel(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        ra_stt_cancel(reinterpret_cast<ra_backend_handle>(handle));
    }
}

// =============================================================================
// JNI Functions - Text-to-Speech (TTS)
// =============================================================================

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring modelType,
    jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string path = getCString(env, modelPath);
    std::string type = getCString(env, modelType);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    LOGi("Loading TTS model from: %s (type: %s)", path.c_str(), type.c_str());

    ra_result_code result = ra_tts_load_model(reinterpret_cast<ra_backend_handle>(handle),
                                              path.c_str(), type.c_str(), config);

    if (result != RA_SUCCESS) {
        LOGe("TTS model load failed: %s", ra_get_last_error());
    }

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSIsModelLoaded(JNIEnv* env,
                                                                                jclass clazz,
                                                                                jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_tts_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                               : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSUnloadModel(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_tts_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jobject JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSSynthesize(
    JNIEnv* env, jclass clazz, jlong handle, jstring text, jstring voiceId, jfloat speedRate,
    jfloat pitchShift) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    std::string textStr = getCString(env, text);
    std::string voiceStorage;
    const char* voice = getNullableCString(env, voiceId, voiceStorage);

    float* samples = nullptr;
    size_t numSamples = 0;
    int sampleRate = 0;

    ra_result_code result =
        ra_tts_synthesize(reinterpret_cast<ra_backend_handle>(handle), textStr.c_str(), voice,
                          speedRate, pitchShift, &samples, &numSamples, &sampleRate);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    // Create NativeTTSSynthesisResult object (in com.runanywhere.sdk.native.bridge package)
    jclass resultClass =
        env->FindClass("com/runanywhere/sdk/native/bridge/NativeTTSSynthesisResult");
    if (resultClass == nullptr) {
        LOGe("NativeTTSSynthesisResult class not found");
        ra_free_audio(samples);
        return nullptr;
    }

    jmethodID constructor = env->GetMethodID(resultClass, "<init>", "([FI)V");
    if (constructor == nullptr) {
        LOGe("NativeTTSSynthesisResult constructor not found");
        ra_free_audio(samples);
        return nullptr;
    }

    // Create float array
    jfloatArray jsamples = env->NewFloatArray(static_cast<jsize>(numSamples));
    if (numSamples > 0 && samples != nullptr) {
        env->SetFloatArrayRegion(jsamples, 0, static_cast<jsize>(numSamples), samples);
    }
    ra_free_audio(samples);

    return env->NewObject(resultClass, constructor, jsamples, sampleRate);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSSupportsStreaming(JNIEnv* env,
                                                                                    jclass clazz,
                                                                                    jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_tts_supports_streaming(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                                  : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSGetVoices(JNIEnv* env,
                                                                            jclass clazz,
                                                                            jlong handle) {
    if (handle == 0) {
        return env->NewStringUTF("[]");
    }

    char* voicesJson = ra_tts_get_voices(reinterpret_cast<ra_backend_handle>(handle));
    if (voicesJson == nullptr) {
        return env->NewStringUTF("[]");
    }

    jstring result = env->NewStringUTF(voicesJson);
    ra_free_string(voicesJson);
    return result;
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeTTSCancel(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        ra_tts_cancel(reinterpret_cast<ra_backend_handle>(handle));
    }
}

// =============================================================================
// JNI Functions - Voice Activity Detection (VAD)
// =============================================================================

JNIEXPORT jint JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string pathStorage;
    const char* path = getNullableCString(env, modelPath, pathStorage);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    ra_result_code result =
        ra_vad_load_model(reinterpret_cast<ra_backend_handle>(handle), path, config);

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADIsModelLoaded(JNIEnv* env,
                                                                                jclass clazz,
                                                                                jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_vad_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                               : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADUnloadModel(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_vad_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jobject JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADProcess(
    JNIEnv* env, jclass clazz, jlong handle, jfloatArray audioSamples, jint sampleRate) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    jsize numSamples = env->GetArrayLength(audioSamples);
    jfloat* samples = env->GetFloatArrayElements(audioSamples, nullptr);

    bool isSpeech = false;
    float probability = 0.0f;

    ra_result_code result =
        ra_vad_process(reinterpret_cast<ra_backend_handle>(handle), samples,
                       static_cast<size_t>(numSamples), sampleRate, &isSpeech, &probability);

    env->ReleaseFloatArrayElements(audioSamples, samples, JNI_ABORT);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    // Create NativeVADResult object (in com.runanywhere.sdk.native.bridge package)
    jclass resultClass = env->FindClass("com/runanywhere/sdk/native/bridge/NativeVADResult");
    if (resultClass == nullptr) {
        return nullptr;
    }

    jmethodID constructor = env->GetMethodID(resultClass, "<init>", "(ZF)V");
    if (constructor == nullptr) {
        return nullptr;
    }

    return env->NewObject(resultClass, constructor, isSpeech ? JNI_TRUE : JNI_FALSE, probability);
}

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADDetectSegments(
    JNIEnv* env, jclass clazz, jlong handle, jfloatArray audioSamples, jint sampleRate) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    jsize numSamples = env->GetArrayLength(audioSamples);
    jfloat* samples = env->GetFloatArrayElements(audioSamples, nullptr);

    char* resultJson = nullptr;
    ra_result_code result =
        ra_vad_detect_segments(reinterpret_cast<ra_backend_handle>(handle), samples,
                               static_cast<size_t>(numSamples), sampleRate, &resultJson);

    env->ReleaseFloatArrayElements(audioSamples, samples, JNI_ABORT);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    if (resultJson == nullptr) {
        return env->NewStringUTF("[]");
    }

    jstring jresult = env->NewStringUTF(resultJson);
    ra_free_string(resultJson);
    return jresult;
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeVADReset(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        ra_vad_reset(reinterpret_cast<ra_backend_handle>(handle));
    }
}

// =============================================================================
// JNI Functions - Embeddings
// =============================================================================

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeEmbedLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string path = getCString(env, modelPath);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    ra_result_code result =
        ra_embed_load_model(reinterpret_cast<ra_backend_handle>(handle), path.c_str(), config);

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeEmbedIsModelLoaded(JNIEnv* env,
                                                                                  jclass clazz,
                                                                                  jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_embed_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                                 : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeEmbedUnloadModel(JNIEnv* env,
                                                                                jclass clazz,
                                                                                jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_embed_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jfloatArray JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeEmbedText(JNIEnv* env, jclass clazz,
                                                                         jlong handle,
                                                                         jstring text) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    std::string textStr = getCString(env, text);

    float* embedding = nullptr;
    int dimensions = 0;

    ra_result_code result = ra_embed_text(reinterpret_cast<ra_backend_handle>(handle),
                                          textStr.c_str(), &embedding, &dimensions);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    if (embedding == nullptr || dimensions <= 0) {
        return env->NewFloatArray(0);
    }

    jfloatArray jembedding = env->NewFloatArray(dimensions);
    env->SetFloatArrayRegion(jembedding, 0, dimensions, embedding);
    ra_free_embedding(embedding);

    return jembedding;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeEmbedGetDimensions(JNIEnv* env,
                                                                                  jclass clazz,
                                                                                  jlong handle) {
    if (handle == 0)
        return 0;
    return ra_embed_get_dimensions(reinterpret_cast<ra_backend_handle>(handle));
}

// =============================================================================
// JNI Functions - Diarization
// =============================================================================

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDiarizeLoadModel(
    JNIEnv* env, jclass clazz, jlong handle, jstring modelPath, jstring configJson) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return RA_ERROR_INVALID_HANDLE;
    }

    std::string path = getCString(env, modelPath);
    std::string configStorage;
    const char* config = getNullableCString(env, configJson, configStorage);

    ra_result_code result =
        ra_diarize_load_model(reinterpret_cast<ra_backend_handle>(handle), path.c_str(), config);

    return static_cast<jint>(result);
}

JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDiarizeIsModelLoaded(JNIEnv* env,
                                                                                    jclass clazz,
                                                                                    jlong handle) {
    if (handle == 0)
        return JNI_FALSE;
    return ra_diarize_is_model_loaded(reinterpret_cast<ra_backend_handle>(handle)) ? JNI_TRUE
                                                                                   : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDiarizeUnloadModel(JNIEnv* env,
                                                                                  jclass clazz,
                                                                                  jlong handle) {
    if (handle == 0)
        return RA_ERROR_INVALID_HANDLE;
    return static_cast<jint>(ra_diarize_unload_model(reinterpret_cast<ra_backend_handle>(handle)));
}

JNIEXPORT jstring JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDiarize(
    JNIEnv* env, jclass clazz, jlong handle, jfloatArray audioSamples, jint sampleRate,
    jint minSpeakers, jint maxSpeakers) {
    if (handle == 0) {
        throwIllegalArgumentException(env, "Invalid handle");
        return nullptr;
    }

    jsize numSamples = env->GetArrayLength(audioSamples);
    jfloat* samples = env->GetFloatArrayElements(audioSamples, nullptr);

    char* resultJson = nullptr;
    ra_result_code result = ra_diarize(reinterpret_cast<ra_backend_handle>(handle), samples,
                                       static_cast<size_t>(numSamples), sampleRate, minSpeakers,
                                       maxSpeakers, &resultJson);

    env->ReleaseFloatArrayElements(audioSamples, samples, JNI_ABORT);

    if (result != RA_SUCCESS) {
        checkResult(env, result);
        return nullptr;
    }

    if (resultJson == nullptr) {
        return env->NewStringUTF("{}");
    }

    jstring jresult = env->NewStringUTF(resultJson);
    ra_free_string(resultJson);
    return jresult;
}

JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeDiarizeCancel(
    JNIEnv* env, jclass clazz, jlong handle) {
    if (handle != 0) {
        ra_diarize_cancel(reinterpret_cast<ra_backend_handle>(handle));
    }
}

// =============================================================================
// JNI Functions - Utility
// =============================================================================

JNIEXPORT jstring JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetLastError(JNIEnv* env,
                                                                            jclass clazz) {
    const char* error = ra_get_last_error();
    if (error == nullptr || strlen(error) == 0) {
        return env->NewStringUTF("");
    }
    return env->NewStringUTF(error);
}

JNIEXPORT jstring JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetVersion(
    JNIEnv* env, jclass clazz) {
    const char* version = ra_get_version();
    if (version == nullptr) {
        return env->NewStringUTF("unknown");
    }
    return env->NewStringUTF(version);
}

JNIEXPORT jint JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeExtractArchive(JNIEnv* env,
                                                                              jclass clazz,
                                                                              jstring archivePath,
                                                                              jstring destDir) {
    std::string archive = getCString(env, archivePath);
    std::string dest = getCString(env, destDir);

    return static_cast<jint>(ra_extract_archive(archive.c_str(), dest.c_str()));
}

JNIEXPORT jobjectArray JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeGetAvailableBackends(JNIEnv* env,
                                                                                    jclass clazz) {
    int count = 0;
    const char** backends = ra_get_available_backends(&count);

    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray result = env->NewObjectArray(count, stringClass, nullptr);

    for (int i = 0; i < count; i++) {
        jstring str = env->NewStringUTF(backends[i]);
        env->SetObjectArrayElement(result, i, str);
        env->DeleteLocalRef(str);
    }

    return result;
}

}  // extern "C"

// =============================================================================
// JNI Functions - Library Loading with RTLD_GLOBAL
// =============================================================================

/**
 * Load a native library with RTLD_GLOBAL flag to make symbols globally visible.
 * This is required for ONNX Runtime so that libsherpa-onnx-c-api.so can find
 * OrtGetApiBase and other symbols from libonnxruntime.so.
 *
 * @param libraryName The library name without "lib" prefix and ".so" suffix
 * @return true if loaded successfully, false otherwise
 */
JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereBridge_nativeLoadLibraryWithGlobal(
    JNIEnv* env, jclass clazz, jstring libraryName) {
    std::string name = getCString(env, libraryName);
    std::string libPath = "lib" + name + ".so";

    // Try to load with RTLD_GLOBAL flag
    // RTLD_GLOBAL makes symbols available to subsequently loaded libraries
    void* handle = dlopen(libPath.c_str(), RTLD_NOW | RTLD_GLOBAL);

    if (handle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load %s with RTLD_GLOBAL: %s", libPath.c_str(),
             error ? error : "unknown error");
        return JNI_FALSE;
    }

    LOGi("Successfully loaded %s with RTLD_GLOBAL", libPath.c_str());
    // Note: We don't close the handle here - it should remain loaded
    return JNI_TRUE;
}
