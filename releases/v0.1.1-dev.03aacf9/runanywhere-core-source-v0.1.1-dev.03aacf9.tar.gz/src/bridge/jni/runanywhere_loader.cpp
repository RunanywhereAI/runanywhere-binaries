/**
 * RunAnywhere Library Loader
 *
 * This is a minimal JNI library with NO dependencies that provides
 * functions to load other native libraries with RTLD_GLOBAL.
 *
 * Purpose:
 * When loading ONNX libraries on Android, libsherpa-onnx-c-api.so needs
 * OrtGetApiBase from libonnxruntime.so. Android's System.loadLibrary()
 * doesn't use RTLD_GLOBAL, and uses a different namespace than dlopen().
 *
 * This loader solves the problem by loading ALL libraries from native code
 * using dlopen() with RTLD_GLOBAL, ensuring they're in the same namespace
 * and symbols are globally visible.
 *
 * Package: com.runanywhere.sdk.native.bridge
 * Class: RunAnywhereLoader
 */

#include <dlfcn.h>
#include <jni.h>

#include <android/log.h>
#include <string>

#define TAG "RunAnywhereLoader"
#define LOGi(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGe(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGw(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

// Store handles to keep libraries loaded
static void* g_onnxHandle = nullptr;
static void* g_sherpaHandle = nullptr;
static void* g_bridgeHandle = nullptr;
static void* g_jniHandle = nullptr;
static std::string g_nativeLibDir;

extern "C" {

/**
 * Set the native library directory path.
 * This is called from Java with the app's native library directory.
 */
JNIEXPORT void JNICALL Java_com_runanywhere_sdk_native_bridge_RunAnywhereLoader_nativeSetLibraryDir(
    JNIEnv* env, jclass clazz, jstring libraryDir) {
    if (libraryDir == nullptr) {
        LOGe("libraryDir is null");
        return;
    }

    const char* dir = env->GetStringUTFChars(libraryDir, nullptr);
    if (dir != nullptr) {
        g_nativeLibDir = std::string(dir);
        env->ReleaseStringUTFChars(libraryDir, dir);
        LOGi("Native library directory set to: %s", g_nativeLibDir.c_str());
    }
}

/**
 * Load a native library with RTLD_GLOBAL flag to make symbols globally visible.
 */
JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereLoader_nativeLoadLibraryGlobal(
    JNIEnv* env, jclass clazz, jstring libraryName) {
    if (libraryName == nullptr) {
        LOGe("libraryName is null");
        return JNI_FALSE;
    }

    const char* name = env->GetStringUTFChars(libraryName, nullptr);
    if (name == nullptr) {
        LOGe("Failed to get library name string");
        return JNI_FALSE;
    }

    std::string libName(name);
    env->ReleaseStringUTFChars(libraryName, name);

    // Build full path using the native library directory
    std::string fullPath;
    if (!g_nativeLibDir.empty()) {
        fullPath = g_nativeLibDir + "/lib" + libName + ".so";
    } else {
        // Fallback to just the library name (might not work)
        fullPath = "lib" + libName + ".so";
    }

    LOGi("Loading %s with RTLD_GLOBAL", fullPath.c_str());

    // RTLD_NOW: resolve all symbols immediately
    // RTLD_GLOBAL: make symbols available to subsequently loaded libraries
    void* handle = dlopen(fullPath.c_str(), RTLD_NOW | RTLD_GLOBAL);

    if (handle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load %s: %s", fullPath.c_str(), error ? error : "unknown");
        return JNI_FALSE;
    }

    // Store handle based on library name
    if (libName == "onnxruntime") {
        g_onnxHandle = handle;
    } else if (libName == "sherpa-onnx-c-api") {
        g_sherpaHandle = handle;
    } else if (libName == "runanywhere_bridge") {
        g_bridgeHandle = handle;
    } else if (libName == "runanywhere_jni") {
        g_jniHandle = handle;
    }

    LOGi("Successfully loaded %s with RTLD_GLOBAL", fullPath.c_str());
    return JNI_TRUE;
}

/**
 * Load all ONNX-related libraries in the correct order.
 * This ensures all libraries are in the same namespace with global symbols.
 */
JNIEXPORT jboolean JNICALL
Java_com_runanywhere_sdk_native_bridge_RunAnywhereLoader_nativeLoadOnnxLibraries(JNIEnv* env,
                                                                                 jclass clazz) {
    if (g_nativeLibDir.empty()) {
        LOGe("Native library directory not set. Call nativeSetLibraryDir first.");
        return JNI_FALSE;
    }

    LOGi("Loading ONNX libraries in dependency order...");

    // 1. Load onnxruntime first - exports OrtGetApiBase
    std::string onnxPath = g_nativeLibDir + "/libonnxruntime.so";
    g_onnxHandle = dlopen(onnxPath.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (g_onnxHandle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load libonnxruntime.so: %s", error ? error : "unknown");
        return JNI_FALSE;
    }
    LOGi("Loaded libonnxruntime.so with RTLD_GLOBAL");

    // 2. Load sherpa-onnx-c-api - needs OrtGetApiBase from onnxruntime
    std::string sherpaPath = g_nativeLibDir + "/libsherpa-onnx-c-api.so";
    g_sherpaHandle = dlopen(sherpaPath.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (g_sherpaHandle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load libsherpa-onnx-c-api.so: %s", error ? error : "unknown");
        return JNI_FALSE;
    }
    LOGi("Loaded libsherpa-onnx-c-api.so with RTLD_GLOBAL");

    // 3. Load runanywhere_bridge
    std::string bridgePath = g_nativeLibDir + "/librunanywhere_bridge.so";
    g_bridgeHandle = dlopen(bridgePath.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (g_bridgeHandle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load librunanywhere_bridge.so: %s", error ? error : "unknown");
        return JNI_FALSE;
    }
    LOGi("Loaded librunanywhere_bridge.so with RTLD_GLOBAL");

    // 4. Load runanywhere_jni
    std::string jniPath = g_nativeLibDir + "/librunanywhere_jni.so";
    g_jniHandle = dlopen(jniPath.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (g_jniHandle == nullptr) {
        const char* error = dlerror();
        LOGe("Failed to load librunanywhere_jni.so: %s", error ? error : "unknown");
        return JNI_FALSE;
    }
    LOGi("Loaded librunanywhere_jni.so with RTLD_GLOBAL");

    LOGi("All ONNX libraries loaded successfully!");
    return JNI_TRUE;
}

}  // extern "C"
