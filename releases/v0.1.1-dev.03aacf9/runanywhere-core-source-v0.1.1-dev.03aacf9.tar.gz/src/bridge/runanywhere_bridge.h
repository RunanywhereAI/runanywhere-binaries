#ifndef RUNANYWHERE_BRIDGE_H
#define RUNANYWHERE_BRIDGE_H

/**
 * RunAnywhere Unified Bridge API
 *
 * This is the main C API that all platforms (iOS, Android, Flutter) use to
 * interact with ML backends. It provides a capability-based interface where
 * backends (ONNX, LlamaCpp, CoreML, etc.) can implement any subset of capabilities.
 *
 * Supported Capabilities:
 * - TEXT_GENERATION: LLM text generation
 * - EMBEDDINGS: Text/image embeddings
 * - STT: Speech-to-text (ASR)
 * - TTS: Text-to-speech
 * - VAD: Voice activity detection
 * - DIARIZATION: Speaker diarization
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// =============================================================================
// EXPORT MACROS - For shared library symbol visibility (Flutter FFI)
// =============================================================================

#ifndef RA_API
#if defined(_WIN32) || defined(__CYGWIN__)
#ifdef RA_BUILD_SHARED
#define RA_API __declspec(dllexport)
#else
#define RA_API __declspec(dllimport)
#endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#define RA_API __attribute__((visibility("default")))
#else
#define RA_API
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

// =============================================================================
// COMMON TYPES - All shared types are now in types.h
// =============================================================================

// Include types from the canonical source (includes ra_capability_type,
// ra_backend_handle, ra_stream_handle, and callback typedefs)
// Note: When built as xcframework, ra_types.h is in same directory
//       When building locally, it's in ../capabilities/
#if __has_include("ra_types.h")
#include "ra_types.h"
#elif __has_include("types.h")
#include "types.h"
#else
#include "../capabilities/types.h"
#endif

// =============================================================================
// BACKEND LIFECYCLE
// =============================================================================

/**
 * Get list of available backend names
 * @param count Output: number of backends
 * @return Array of backend names (caller must NOT free)
 */
RA_API const char** ra_get_available_backends(int* count);

/**
 * Create a backend instance by name
 * @param backend_name Name of backend ("onnx", "llamacpp", "coreml", etc.)
 * @return Handle or NULL on failure
 */
RA_API ra_backend_handle ra_create_backend(const char* backend_name);

/**
 * Initialize a backend with JSON configuration
 * @param handle Backend handle
 * @param config_json JSON configuration string (can be NULL for defaults)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_initialize(ra_backend_handle handle, const char* config_json);

/**
 * Check if backend is initialized
 */
RA_API bool ra_is_initialized(ra_backend_handle handle);

/**
 * Cleanup and destroy a backend
 */
RA_API void ra_destroy(ra_backend_handle handle);

/**
 * Get backend info as JSON
 * @param handle Backend handle
 * @return JSON string (caller must free with ra_free_string)
 */
RA_API char* ra_get_backend_info(ra_backend_handle handle);

/**
 * Check if backend supports a capability
 */
RA_API bool ra_supports_capability(ra_backend_handle handle, ra_capability_type capability);

/**
 * Get all supported capabilities
 * @param handle Backend handle
 * @param capabilities Output array (caller provides)
 * @param max_count Size of capabilities array
 * @return Number of capabilities written
 */
RA_API int ra_get_capabilities(ra_backend_handle handle, ra_capability_type* capabilities,
                               int max_count);

/**
 * Get device type being used
 */
RA_API ra_device_type ra_get_device(ra_backend_handle handle);

/**
 * Get memory usage in bytes
 */
RA_API size_t ra_get_memory_usage(ra_backend_handle handle);

// =============================================================================
// TEXT GENERATION
// =============================================================================

/**
 * Load a text generation model
 * @param handle Backend handle
 * @param model_path Path to model file/directory
 * @param config_json Optional JSON config (can be NULL)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_text_load_model(ra_backend_handle handle, const char* model_path,
                                         const char* config_json);

/**
 * Check if text generation model is loaded
 */
RA_API bool ra_text_is_model_loaded(ra_backend_handle handle);

/**
 * Unload text generation model
 */
RA_API ra_result_code ra_text_unload_model(ra_backend_handle handle);

/**
 * Generate text (synchronous)
 * @param handle Backend handle
 * @param prompt User prompt
 * @param system_prompt System prompt (can be NULL)
 * @param max_tokens Maximum tokens to generate
 * @param temperature Sampling temperature (0.0-2.0)
 * @param result_json Output: JSON result (caller must free with ra_free_string)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_text_generate(ra_backend_handle handle, const char* prompt,
                                       const char* system_prompt, int max_tokens, float temperature,
                                       char** result_json);

/**
 * Generate text with streaming
 * @param handle Backend handle
 * @param prompt User prompt
 * @param system_prompt System prompt (can be NULL)
 * @param max_tokens Maximum tokens to generate
 * @param temperature Sampling temperature
 * @param callback Token callback function
 * @param user_data User data passed to callback
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_text_generate_stream(ra_backend_handle handle, const char* prompt,
                                              const char* system_prompt, int max_tokens,
                                              float temperature, ra_text_stream_callback callback,
                                              void* user_data);

/**
 * Cancel ongoing text generation
 */
RA_API void ra_text_cancel(ra_backend_handle handle);

/**
 * Get the context length of the loaded text generation model
 * @param handle Backend handle
 * @return Context length in tokens, or 0 if model not loaded or error
 */
RA_API int ra_text_get_context_length(ra_backend_handle handle);

/**
 * Get text generation model info as JSON
 * @param handle Backend handle
 * @return JSON string with model info (caller must free with ra_free_string)
 *         Contains: context_size, model_training_context, temperature, etc.
 *         Returns NULL if model not loaded
 */
RA_API char* ra_text_get_model_info(ra_backend_handle handle);

// =============================================================================
// EMBEDDINGS
// =============================================================================

/**
 * Load an embedding model
 */
RA_API ra_result_code ra_embed_load_model(ra_backend_handle handle, const char* model_path,
                                          const char* config_json);

/**
 * Check if embedding model is loaded
 */
RA_API bool ra_embed_is_model_loaded(ra_backend_handle handle);

/**
 * Unload embedding model
 */
RA_API ra_result_code ra_embed_unload_model(ra_backend_handle handle);

/**
 * Generate embedding for text
 * @param handle Backend handle
 * @param text Input text
 * @param embedding Output: embedding vector (caller must free with ra_free_embedding)
 * @param dimensions Output: embedding dimensions
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_embed_text(ra_backend_handle handle, const char* text, float** embedding,
                                    int* dimensions);

/**
 * Generate embeddings for multiple texts
 * @param handle Backend handle
 * @param texts Array of input texts
 * @param num_texts Number of texts
 * @param embeddings Output: array of embedding vectors (caller must free)
 * @param dimensions Output: embedding dimensions
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_embed_batch(ra_backend_handle handle, const char** texts, int num_texts,
                                     float*** embeddings, int* dimensions);

/**
 * Get embedding dimensions
 */
RA_API int ra_embed_get_dimensions(ra_backend_handle handle);

/**
 * Free embedding memory
 */
RA_API void ra_free_embedding(float* embedding);

/**
 * Free batch embeddings
 */
RA_API void ra_free_embeddings(float** embeddings, int count);

// =============================================================================
// SPEECH-TO-TEXT (STT)
// =============================================================================

/**
 * Load an STT model
 * @param handle Backend handle
 * @param model_path Path to model file/directory
 * @param model_type Model type ("whisper", "zipformer", "paraformer")
 * @param config_json Optional JSON config
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_stt_load_model(ra_backend_handle handle, const char* model_path,
                                        const char* model_type, const char* config_json);

/**
 * Check if STT model is loaded
 */
RA_API bool ra_stt_is_model_loaded(ra_backend_handle handle);

/**
 * Unload STT model
 */
RA_API ra_result_code ra_stt_unload_model(ra_backend_handle handle);

/**
 * Transcribe audio (batch mode)
 * @param handle Backend handle
 * @param audio_samples Float32 audio samples [-1.0, 1.0]
 * @param num_samples Number of samples
 * @param sample_rate Sample rate (e.g., 16000)
 * @param language ISO 639-1 language code (can be NULL for auto-detect)
 * @param result_json Output: JSON result (caller must free with ra_free_string)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_stt_transcribe(ra_backend_handle handle, const float* audio_samples,
                                        size_t num_samples, int sample_rate, const char* language,
                                        char** result_json);

/**
 * Check if STT supports streaming
 */
RA_API bool ra_stt_supports_streaming(ra_backend_handle handle);

/**
 * Create STT streaming session
 * @param handle Backend handle
 * @param config_json Optional JSON config
 * @return Stream handle or NULL on failure
 */
RA_API ra_stream_handle ra_stt_create_stream(ra_backend_handle handle, const char* config_json);

/**
 * Feed audio to STT stream
 * @param handle Backend handle
 * @param stream Stream handle
 * @param samples Float32 audio samples
 * @param num_samples Number of samples
 * @param sample_rate Sample rate
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_stt_feed_audio(ra_backend_handle handle, ra_stream_handle stream,
                                        const float* samples, size_t num_samples, int sample_rate);

/**
 * Check if STT decoder is ready
 */
RA_API bool ra_stt_is_ready(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Decode and get current result
 * @param handle Backend handle
 * @param stream Stream handle
 * @param result_json Output: JSON result (caller must free)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_stt_decode(ra_backend_handle handle, ra_stream_handle stream,
                                    char** result_json);

/**
 * Check for end-of-speech (endpoint detection)
 */
RA_API bool ra_stt_is_endpoint(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Signal end of audio input
 */
RA_API void ra_stt_input_finished(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Reset stream for new utterance
 */
RA_API void ra_stt_reset_stream(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Destroy STT stream
 */
RA_API void ra_stt_destroy_stream(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Cancel ongoing transcription
 */
RA_API void ra_stt_cancel(ra_backend_handle handle);

// =============================================================================
// TEXT-TO-SPEECH (TTS)
// =============================================================================

/**
 * Load a TTS model
 * @param handle Backend handle
 * @param model_path Path to model file/directory
 * @param model_type Model type ("piper", "coqui", "bark")
 * @param config_json Optional JSON config
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_tts_load_model(ra_backend_handle handle, const char* model_path,
                                        const char* model_type, const char* config_json);

/**
 * Check if TTS model is loaded
 */
RA_API bool ra_tts_is_model_loaded(ra_backend_handle handle);

/**
 * Unload TTS model
 */
RA_API ra_result_code ra_tts_unload_model(ra_backend_handle handle);

/**
 * Synthesize speech (batch mode)
 * @param handle Backend handle
 * @param text Text to synthesize
 * @param voice_id Voice identifier (can be NULL for default)
 * @param speed_rate Speed rate (1.0 = normal)
 * @param pitch_shift Pitch shift in semitones
 * @param audio_samples Output: float32 audio samples (caller must free with ra_free_audio)
 * @param num_samples Output: number of samples
 * @param sample_rate Output: sample rate
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_tts_synthesize(ra_backend_handle handle, const char* text,
                                        const char* voice_id, float speed_rate, float pitch_shift,
                                        float** audio_samples, size_t* num_samples,
                                        int* sample_rate);

/**
 * Synthesize speech with streaming
 */
RA_API ra_result_code ra_tts_synthesize_stream(ra_backend_handle handle, const char* text,
                                               const char* voice_id, float speed_rate,
                                               float pitch_shift, ra_tts_stream_callback callback,
                                               void* user_data);

/**
 * Check if TTS supports streaming
 */
RA_API bool ra_tts_supports_streaming(ra_backend_handle handle);

/**
 * Get available voices as JSON array
 * @param handle Backend handle
 * @return JSON string (caller must free with ra_free_string)
 */
RA_API char* ra_tts_get_voices(ra_backend_handle handle);

/**
 * Cancel ongoing synthesis
 */
RA_API void ra_tts_cancel(ra_backend_handle handle);

/**
 * Free audio samples
 */
RA_API void ra_free_audio(float* audio_samples);

// =============================================================================
// VOICE ACTIVITY DETECTION (VAD)
// =============================================================================

/**
 * Load a VAD model
 * @param handle Backend handle
 * @param model_path Path to model file (can be NULL for built-in)
 * @param config_json Optional JSON config
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_vad_load_model(ra_backend_handle handle, const char* model_path,
                                        const char* config_json);

/**
 * Check if VAD model is loaded
 */
RA_API bool ra_vad_is_model_loaded(ra_backend_handle handle);

/**
 * Unload VAD model
 */
RA_API ra_result_code ra_vad_unload_model(ra_backend_handle handle);

/**
 * Process audio chunk and get speech probability
 * @param handle Backend handle
 * @param samples Float32 audio samples
 * @param num_samples Number of samples
 * @param sample_rate Sample rate
 * @param is_speech Output: true if speech detected
 * @param probability Output: speech probability [0.0, 1.0]
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_vad_process(ra_backend_handle handle, const float* samples,
                                     size_t num_samples, int sample_rate, bool* is_speech,
                                     float* probability);

/**
 * Detect speech segments in full audio
 * @param handle Backend handle
 * @param samples Float32 audio samples
 * @param num_samples Number of samples
 * @param sample_rate Sample rate
 * @param result_json Output: JSON array of segments (caller must free)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_vad_detect_segments(ra_backend_handle handle, const float* samples,
                                             size_t num_samples, int sample_rate,
                                             char** result_json);

/**
 * Create VAD streaming session
 */
RA_API ra_stream_handle ra_vad_create_stream(ra_backend_handle handle, const char* config_json);

/**
 * Feed audio to VAD stream
 */
RA_API ra_result_code ra_vad_feed_stream(ra_backend_handle handle, ra_stream_handle stream,
                                         const float* samples, size_t num_samples, int sample_rate,
                                         bool* is_speech, float* probability);

/**
 * Destroy VAD stream
 */
RA_API void ra_vad_destroy_stream(ra_backend_handle handle, ra_stream_handle stream);

/**
 * Reset VAD state
 */
RA_API void ra_vad_reset(ra_backend_handle handle);

// =============================================================================
// SPEAKER DIARIZATION
// =============================================================================

/**
 * Load a diarization model
 */
RA_API ra_result_code ra_diarize_load_model(ra_backend_handle handle, const char* model_path,
                                            const char* config_json);

/**
 * Check if diarization model is loaded
 */
RA_API bool ra_diarize_is_model_loaded(ra_backend_handle handle);

/**
 * Unload diarization model
 */
RA_API ra_result_code ra_diarize_unload_model(ra_backend_handle handle);

/**
 * Perform speaker diarization on audio
 * @param handle Backend handle
 * @param samples Float32 audio samples
 * @param num_samples Number of samples
 * @param sample_rate Sample rate
 * @param min_speakers Minimum expected speakers (0 for auto)
 * @param max_speakers Maximum expected speakers (0 for auto)
 * @param result_json Output: JSON result (caller must free)
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_diarize(ra_backend_handle handle, const float* samples, size_t num_samples,
                                 int sample_rate, int min_speakers, int max_speakers,
                                 char** result_json);

/**
 * Cancel ongoing diarization
 */
RA_API void ra_diarize_cancel(ra_backend_handle handle);

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

/**
 * Free a string allocated by the bridge
 */
RA_API void ra_free_string(char* str);

/**
 * Get last error message
 * @return Error message (do NOT free, valid until next call)
 */
RA_API const char* ra_get_last_error(void);

/**
 * Get bridge version
 */
RA_API const char* ra_get_version(void);

/**
 * Extract an archive (tar.bz2, tar.gz, zip) to a destination directory
 * @param archive_path Path to the archive file
 * @param dest_dir Destination directory path
 * @return RA_SUCCESS or error code
 */
RA_API ra_result_code ra_extract_archive(const char* archive_path, const char* dest_dir);

#ifdef __cplusplus
}
#endif

#endif  // RUNANYWHERE_BRIDGE_H
