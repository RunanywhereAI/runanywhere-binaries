# RunAnywhere Flutter Native Library Setup

This directory contains scripts for setting up native libraries for the RunAnywhere Flutter SDK.

## Quick Start

### Remote Mode (Recommended for Production)

Download pre-built binaries from [runanywhere-binaries](https://github.com/RunanywhereAI/runanywhere-binaries):

```bash
# From runanywhere-core directory
./scripts/flutter/setup.sh /path/to/runanywhere-flutter

# Specific version
./scripts/flutter/setup.sh --version 0.0.1-dev.2230b4e /path/to/runanywhere-flutter

# iOS only
./scripts/flutter/setup.sh --platform ios /path/to/runanywhere-flutter
```

### Local Mode (For Development)

Build from source:

```bash
# Build all platforms
./scripts/flutter/setup.sh --mode local /path/to/runanywhere-flutter

# Build specific platform and backend
./scripts/flutter/setup.sh --mode local --platform ios --backend onnx /path/to/runanywhere-flutter
```

## Options

| Option | Values | Default | Description |
|--------|--------|---------|-------------|
| `--mode` | `remote`, `local` | `remote` | Download binaries or build from source |
| `--version` | version string | `latest` | Binary version (remote mode only) |
| `--platform` | `ios`, `android`, `all` | `all` | Target platform |
| `--backend` | `onnx`, `llamacpp`, `all` | `onnx` | Backend to include |

## Binary Distribution

Pre-built binaries are automatically published to [runanywhere-binaries](https://github.com/RunanywhereAI/runanywhere-binaries) via GitHub Actions when:

1. A version tag is pushed (e.g., `v1.0.0`) → Stable release
2. Code is merged to `main` → Dev/prerelease

### Available Artifacts

| Platform | Artifact | Description |
|----------|----------|-------------|
| iOS | `RunAnywhereCore.xcframework.zip` | Unified XCFramework with all backends |
| Android | `RunAnywhereONNX-android.zip` | ONNX Runtime backend for Android |
| Android | `RunAnywhereUnified-android.zip` | All backends for Android |

## Directory Structure After Setup

```
runanywhere-flutter/
├── ios/
│   └── Frameworks/
│       └── RunAnywhereCore.xcframework/   # iOS XCFramework
└── android/
    └── src/main/jniLibs/
        ├── arm64-v8a/
        │   ├── librunanywhere_bridge.so
        │   └── libonnxruntime.so
        ├── armeabi-v7a/
        │   └── ...
        └── x86_64/
            └── ...
```

## Consuming in Flutter

The Flutter SDK's native bindings (`lib/native/`) automatically load the correct library based on platform:

```dart
import 'package:runanywhere/native/native.dart';

// Register native providers
await NativeProviderRegistration.registerAll();

// Or use backend directly
final backend = NativeBackend();
backend.create('onnx');
```

## Troubleshooting

### iOS: XCFramework not found

Make sure the XCFramework is in `ios/Frameworks/`:

```bash
ls -la /path/to/runanywhere-flutter/ios/Frameworks/
```

### Android: Library not loading

Check that .so files exist for your target ABI:

```bash
ls -la /path/to/runanywhere-flutter/android/src/main/jniLibs/arm64-v8a/
```
