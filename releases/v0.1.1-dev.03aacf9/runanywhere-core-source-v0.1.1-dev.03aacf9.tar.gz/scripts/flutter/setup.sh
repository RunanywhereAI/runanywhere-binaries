#!/bin/bash

# =============================================================================
# RunAnywhere Flutter SDK Native Library Setup
#
# This script sets up native libraries for the Flutter SDK.
# It supports two modes:
#   1. REMOTE (default) - Download pre-built binaries from runanywhere-binaries
#   2. LOCAL - Build from source for development
#
# Usage:
#   ./setup.sh [options] <flutter-sdk-path>
#
# Options:
#   --mode <remote|local>   Set mode (default: remote)
#   --version <version>     Binary version to download (default: latest)
#   --platform <platform>   Platform to setup: ios, android, all (default: all)
#   --backend <backend>     Backend: onnx, llamacpp, all (default: onnx)
#   --help                  Show this help message
#
# Examples:
#   ./setup.sh ../sdks/runanywhere-flutter                    # Remote mode, latest version
#   ./setup.sh --mode local ../sdks/runanywhere-flutter       # Build from source
#   ./setup.sh --version 0.0.1-dev.2230b4e ../sdks/runanywhere-flutter
#   ./setup.sh --platform ios ../sdks/runanywhere-flutter
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"

# Default values
MODE="remote"
VERSION="latest"
PLATFORM="all"
BACKEND="onnx"
FLUTTER_SDK_PATH=""

# Binary repository configuration
GITHUB_ORG="RunanywhereAI"
REPO_NAME="runanywhere-binaries"
RELEASES_URL="https://github.com/${GITHUB_ORG}/${REPO_NAME}/releases"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
}

print_step() {
    echo -e "${YELLOW}→ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

show_help() {
    head -30 "$0" | tail -28 | sed 's/^# //' | sed 's/^#//'
    exit 0
}

# =============================================================================
# Parse Arguments
# =============================================================================

while [[ $# -gt 0 ]]; do
    case $1 in
        --mode)
            MODE="$2"
            shift 2
            ;;
        --version)
            VERSION="$2"
            shift 2
            ;;
        --platform)
            PLATFORM="$2"
            shift 2
            ;;
        --backend)
            BACKEND="$2"
            shift 2
            ;;
        --help|-h)
            show_help
            ;;
        -*)
            print_error "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
        *)
            FLUTTER_SDK_PATH="$1"
            shift
            ;;
    esac
done

# Validate Flutter SDK path
if [ -z "$FLUTTER_SDK_PATH" ]; then
    print_error "Flutter SDK path is required"
    echo "Usage: $0 [options] <flutter-sdk-path>"
    echo "Use --help for more information"
    exit 1
fi

# Convert to absolute path
FLUTTER_SDK_PATH="$(cd "$FLUTTER_SDK_PATH" 2>/dev/null && pwd)" || {
    print_error "Flutter SDK path does not exist: $FLUTTER_SDK_PATH"
    exit 1
}

# Verify it's a Flutter SDK
if [ ! -f "$FLUTTER_SDK_PATH/pubspec.yaml" ]; then
    print_error "Not a valid Flutter package: $FLUTTER_SDK_PATH"
    exit 1
fi

print_header "RunAnywhere Flutter Native Setup"
echo "Mode:           ${MODE}"
echo "Version:        ${VERSION}"
echo "Platform:       ${PLATFORM}"
echo "Backend:        ${BACKEND}"
echo "Flutter SDK:    ${FLUTTER_SDK_PATH}"
echo "Core Source:    ${CORE_DIR}"
echo ""

# =============================================================================
# Utility Functions
# =============================================================================

get_latest_version() {
    # Get latest release version that contains RunAnywhereCore (not sherpa-onnx or other releases)
    # We need to filter for releases that have the RunAnywhereCore.xcframework.zip asset
    local releases_json=$(curl -s "https://api.github.com/repos/${GITHUB_ORG}/${REPO_NAME}/releases")
    
    # Find releases that contain RunAnywhereCore.xcframework.zip
    # These are the main runanywhere-core releases, not the sherpa-onnx prebuilt releases
    local latest=$(echo "$releases_json" | grep -B5 "RunAnywhereCore.xcframework.zip" | grep '"tag_name"' | head -1 | sed -E 's/.*"v([^"]+)".*/\1/')
    
    if [ -z "$latest" ]; then
        # Fallback: try releases starting with 'v0.' (skip sherpa-onnx-v* etc)
        latest=$(echo "$releases_json" | grep '"tag_name": "v0\.' | head -1 | sed -E 's/.*"v([^"]+)".*/\1/')
    fi
    
    if [ -z "$latest" ]; then
        # Last resort: use the known good version
        latest="0.0.1-dev.fcf1715"
    fi
    
    echo "$latest"
}

download_file() {
    local url="$1"
    local dest="$2"
    
    print_step "Downloading $(basename "$dest")..."
    
    if command -v curl &> /dev/null; then
        curl -L --progress-bar -o "$dest" "$url"
    elif command -v wget &> /dev/null; then
        wget -q --show-progress -O "$dest" "$url"
    else
        print_error "Neither curl nor wget found. Please install one."
        exit 1
    fi
}

verify_checksum() {
    local file="$1"
    local expected="$2"
    
    if [ -z "$expected" ]; then
        print_warning "No checksum provided, skipping verification"
        return 0
    fi
    
    local actual=$(shasum -a 256 "$file" | awk '{print $1}')
    
    if [ "$actual" = "$expected" ]; then
        print_success "Checksum verified"
        return 0
    else
        print_error "Checksum mismatch!"
        echo "  Expected: $expected"
        echo "  Actual:   $actual"
        return 1
    fi
}

# =============================================================================
# Remote Mode - Download Pre-built Binaries
# =============================================================================

setup_remote() {
    print_header "Setting up from Remote Binaries"
    
    # Resolve version
    if [ "$VERSION" = "latest" ]; then
        print_step "Fetching latest version..."
        VERSION=$(get_latest_version)
        if [ -z "$VERSION" ]; then
            print_error "Could not determine latest version"
            exit 1
        fi
        print_success "Latest version: $VERSION"
    fi
    
    local BASE_URL="${RELEASES_URL}/download/v${VERSION}"
    local TEMP_DIR=$(mktemp -d)
    trap "rm -rf $TEMP_DIR" EXIT
    
    # Setup iOS
    if [[ "$PLATFORM" == "ios" || "$PLATFORM" == "all" ]]; then
        setup_remote_ios "$BASE_URL" "$TEMP_DIR"
    fi
    
    # Setup Android
    if [[ "$PLATFORM" == "android" || "$PLATFORM" == "all" ]]; then
        setup_remote_android "$BASE_URL" "$TEMP_DIR"
    fi
}

setup_remote_ios() {
    local BASE_URL="$1"
    local TEMP_DIR="$2"
    
    print_step "Setting up iOS binaries..."
    
    # Download XCFramework
    local XCFRAMEWORK_ZIP="${TEMP_DIR}/RunAnywhereCore.xcframework.zip"
    local XCFRAMEWORK_URL="${BASE_URL}/RunAnywhereCore.xcframework.zip"
    
    download_file "$XCFRAMEWORK_URL" "$XCFRAMEWORK_ZIP"
    
    # Download checksum
    local CHECKSUM_URL="${BASE_URL}/RunAnywhereCore.xcframework.zip.sha256"
    local CHECKSUM_FILE="${TEMP_DIR}/checksum.sha256"
    curl -sL -o "$CHECKSUM_FILE" "$CHECKSUM_URL" 2>/dev/null || true
    
    if [ -f "$CHECKSUM_FILE" ]; then
        local EXPECTED_CHECKSUM=$(cat "$CHECKSUM_FILE" | awk '{print $1}')
        verify_checksum "$XCFRAMEWORK_ZIP" "$EXPECTED_CHECKSUM"
    fi
    
    # Extract to Flutter SDK
    local DEST_DIR="${FLUTTER_SDK_PATH}/ios/Frameworks"
    mkdir -p "$DEST_DIR"
    
    print_step "Extracting XCFramework..."
    unzip -q -o "$XCFRAMEWORK_ZIP" -d "$DEST_DIR"
    
    print_success "iOS XCFramework installed to $DEST_DIR"
}

setup_remote_android() {
    local BASE_URL="$1"
    local TEMP_DIR="$2"
    
    print_step "Setting up Android binaries..."
    
    # Determine artifact name based on backend
    local ARTIFACT_NAME="RunAnywhereONNX-android"
    if [ "$BACKEND" = "llamacpp" ]; then
        ARTIFACT_NAME="RunAnywhereLlamaCPP-android"
    elif [ "$BACKEND" = "all" ]; then
        ARTIFACT_NAME="RunAnywhereUnified-android"
    fi
    
    local ANDROID_ZIP="${TEMP_DIR}/${ARTIFACT_NAME}.zip"
    local ANDROID_URL="${BASE_URL}/${ARTIFACT_NAME}.zip"
    
    download_file "$ANDROID_URL" "$ANDROID_ZIP"
    
    # Download checksum
    local CHECKSUM_URL="${BASE_URL}/${ARTIFACT_NAME}.zip.sha256"
    local CHECKSUM_FILE="${TEMP_DIR}/android_checksum.sha256"
    curl -sL -o "$CHECKSUM_FILE" "$CHECKSUM_URL" 2>/dev/null || true
    
    if [ -f "$CHECKSUM_FILE" ]; then
        local EXPECTED_CHECKSUM=$(cat "$CHECKSUM_FILE" | awk '{print $1}')
        verify_checksum "$ANDROID_ZIP" "$EXPECTED_CHECKSUM"
    fi
    
    # Extract to Flutter SDK jniLibs
    local DEST_DIR="${FLUTTER_SDK_PATH}/android/src/main/jniLibs"
    mkdir -p "$DEST_DIR"
    
    print_step "Extracting Android libraries..."
    unzip -q -o "$ANDROID_ZIP" -d "$DEST_DIR"
    
    print_success "Android libraries installed to $DEST_DIR"
}

# =============================================================================
# Local Mode - Build from Source
# =============================================================================

setup_local() {
    print_header "Building from Local Source"
    
    # Setup iOS
    if [[ "$PLATFORM" == "ios" || "$PLATFORM" == "all" ]]; then
        build_local_ios
    fi
    
    # Setup Android
    if [[ "$PLATFORM" == "android" || "$PLATFORM" == "all" ]]; then
        build_local_android
    fi
}

build_local_ios() {
    print_step "Building iOS XCFramework..."
    
    local IOS_BUILD_SCRIPT="${CORE_DIR}/scripts/ios/build.sh"
    
    if [ ! -f "$IOS_BUILD_SCRIPT" ]; then
        print_error "iOS build script not found at ${IOS_BUILD_SCRIPT}"
        return 1
    fi
    
    cd "${CORE_DIR}"
    
    local FLAGS=""
    if [[ "$BACKEND" == "onnx" || "$BACKEND" == "all" ]]; then
        FLAGS="${FLAGS} --onnx"
    fi
    if [[ "$BACKEND" == "llamacpp" || "$BACKEND" == "all" ]]; then
        FLAGS="${FLAGS} --llamacpp"
    fi
    
    ./scripts/ios/build.sh ${FLAGS}
    
    # Copy XCFramework to Flutter SDK
    local DEST_DIR="${FLUTTER_SDK_PATH}/ios/Frameworks"
    mkdir -p "${DEST_DIR}"
    
    if [ -d "${CORE_DIR}/dist/RunAnywhereCore.xcframework" ]; then
        rm -rf "${DEST_DIR}/RunAnywhereCore.xcframework"
        cp -R "${CORE_DIR}/dist/RunAnywhereCore.xcframework" "${DEST_DIR}/"
        print_success "iOS XCFramework installed to ${DEST_DIR}"
    else
        print_error "RunAnywhereCore.xcframework not found in dist/"
        return 1
    fi
}

build_local_android() {
    print_step "Building Android native libraries..."
    
    local ANDROID_BUILD_SCRIPT="${CORE_DIR}/scripts/android/build.sh"
    
    if [ ! -f "$ANDROID_BUILD_SCRIPT" ]; then
        print_error "Android build script not found at ${ANDROID_BUILD_SCRIPT}"
        return 1
    fi
    
    cd "${CORE_DIR}"
    
    local BACKEND_FLAG="$BACKEND"
    if [ "$BACKEND" = "all" ]; then
        BACKEND_FLAG="all"
    fi
    
    # Build for all ABIs
    ./scripts/android/build.sh ${BACKEND_FLAG} "arm64-v8a,armeabi-v7a,x86_64"
    
    # Copy .so files to Flutter SDK
    local DEST_BASE="${FLUTTER_SDK_PATH}/android/src/main/jniLibs"
    
    for abi in arm64-v8a armeabi-v7a x86_64; do
        local DEST_DIR="${DEST_BASE}/${abi}"
        mkdir -p "${DEST_DIR}"
        
        # Try unified output first
        local SRC_DIR="${CORE_DIR}/dist/android/unified/${abi}"
        if [ ! -d "${SRC_DIR}" ]; then
            SRC_DIR="${CORE_DIR}/dist/android/${BACKEND}/${abi}"
        fi
        
        if [ -d "${SRC_DIR}" ]; then
            cp "${SRC_DIR}"/*.so "${DEST_DIR}/" 2>/dev/null || true
            print_success "Installed ${abi} libraries"
        else
            print_warning "No libraries found for ${abi}"
        fi
    done
    
    print_success "Android libraries installed to ${DEST_BASE}"
}

# =============================================================================
# Main
# =============================================================================

case "$MODE" in
    remote)
        setup_remote
        ;;
    local)
        setup_local
        ;;
    *)
        print_error "Unknown mode: $MODE"
        echo "Valid modes: remote, local"
        exit 1
        ;;
esac

print_header "Setup Complete!"

echo "Next steps:"
echo "  1. cd ${FLUTTER_SDK_PATH}"
echo "  2. flutter pub get"
echo "  3. Test with a Flutter app"
echo ""

if [ "$MODE" = "remote" ]; then
    echo "Binaries version: v${VERSION}"
    echo "Source: ${RELEASES_URL}/tag/v${VERSION}"
fi
