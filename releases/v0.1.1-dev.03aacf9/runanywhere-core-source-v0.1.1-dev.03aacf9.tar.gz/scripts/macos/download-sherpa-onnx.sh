#!/bin/bash
# Download Sherpa-ONNX macOS static libraries
#
# Downloads pre-built universal (arm64 + x86_64) static libraries from
# the official k2-fsa/sherpa-onnx GitHub releases.
#
# This provides STT, TTS, VAD, and speaker diarization capabilities.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
SHERPA_DIR="${ROOT_DIR}/third_party/sherpa-onnx-macos"

# Load versions from centralized VERSIONS file
source "${SCRIPT_DIR}/../load-versions.sh"

# Use centralized version (fallback to hardcoded if not set)
SHERPA_VERSION="${SHERPA_ONNX_VERSION_MACOS:-1.12.18}"
# Official Sherpa-ONNX macOS release (universal2 = arm64 + x86_64)
DOWNLOAD_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/v${SHERPA_VERSION}/sherpa-onnx-v${SHERPA_VERSION}-osx-universal2-static.tar.bz2"

echo "======================================="
echo "📦 Sherpa-ONNX macOS Downloader"
echo "======================================="
echo ""
echo "Version: ${SHERPA_VERSION}"
echo "Type: Universal static library (arm64 + x86_64)"

# Check if already exists and is valid
if [ -d "${SHERPA_DIR}/lib" ]; then
    if [ -f "${SHERPA_DIR}/lib/libsherpa-onnx-c-api.a" ]; then
        echo ""
        echo "✅ Sherpa-ONNX macOS libraries already exist"
        echo "   Location: ${SHERPA_DIR}"
        echo ""
        echo "   Library: $(du -h ${SHERPA_DIR}/lib/libsherpa-onnx-c-api.a | cut -f1)"
        lipo -info "${SHERPA_DIR}/lib/libsherpa-onnx-c-api.a" 2>/dev/null || true
        echo ""
        echo "To force re-download, remove the directory first:"
        echo "   rm -rf ${SHERPA_DIR}"
        exit 0
    else
        echo "⚠️  Existing directory appears incomplete, re-downloading..."
        rm -rf "${SHERPA_DIR}"
    fi
fi

# Create temp directory for download
TEMP_DIR=$(mktemp -d)
TEMP_ARCHIVE="${TEMP_DIR}/sherpa-onnx-macos.tar.bz2"

echo ""
echo "Downloading from ${DOWNLOAD_URL}..."

# Download
HTTP_CODE=$(curl -L -w "%{http_code}" -o "${TEMP_ARCHIVE}" "${DOWNLOAD_URL}" 2>/dev/null) || true

if [ "${HTTP_CODE}" = "200" ] && [ -f "${TEMP_ARCHIVE}" ] && [ -s "${TEMP_ARCHIVE}" ]; then
    echo "Download complete. Size: $(du -h "${TEMP_ARCHIVE}" | cut -f1)"

    # Extract
    echo "Extracting..."
    mkdir -p "${SHERPA_DIR}"
    tar -xjf "${TEMP_ARCHIVE}" -C "${TEMP_DIR}"

    # Find the extracted directory
    EXTRACTED_DIR=$(find "${TEMP_DIR}" -maxdepth 1 -type d -name "sherpa-onnx-*" | head -1)

    if [ -z "${EXTRACTED_DIR}" ]; then
        echo "Error: Could not find extracted directory"
        ls -la "${TEMP_DIR}"
        rm -rf "${TEMP_DIR}"
        exit 1
    fi

    # Copy lib and include directories
    if [ -d "${EXTRACTED_DIR}/lib" ]; then
        cp -R "${EXTRACTED_DIR}/lib" "${SHERPA_DIR}/"
    else
        echo "Error: lib directory not found in archive"
        rm -rf "${TEMP_DIR}"
        exit 1
    fi

    if [ -d "${EXTRACTED_DIR}/include" ]; then
        cp -R "${EXTRACTED_DIR}/include" "${SHERPA_DIR}/"
    else
        echo "Error: include directory not found in archive"
        rm -rf "${TEMP_DIR}"
        exit 1
    fi

    # Clean up
    rm -rf "${TEMP_DIR}"

    echo ""
    echo "✅ Sherpa-ONNX macOS libraries downloaded to ${SHERPA_DIR}"
    echo ""
    echo "Libraries:"
    ls -lh "${SHERPA_DIR}/lib/"*.a 2>/dev/null | head -10
    echo ""
    echo "Headers:"
    find "${SHERPA_DIR}/include" -name "*.h" | head -10
    echo ""

    # Verify architecture
    echo "Architecture verification:"
    lipo -info "${SHERPA_DIR}/lib/libsherpa-onnx-c-api.a"

else
    echo ""
    echo "⚠️  Download failed (HTTP: ${HTTP_CODE})"
    echo ""
    rm -rf "${TEMP_DIR}"

    echo "=============================================="
    echo "❌ Sherpa-ONNX download failed"
    echo "=============================================="
    echo ""
    echo "Manual download options:"
    echo ""
    echo "1. Download directly from Sherpa-ONNX releases:"
    echo "   ${DOWNLOAD_URL}"
    echo ""
    echo "2. Extract lib/ and include/ to:"
    echo "   ${SHERPA_DIR}/"
    echo ""
    exit 1
fi
