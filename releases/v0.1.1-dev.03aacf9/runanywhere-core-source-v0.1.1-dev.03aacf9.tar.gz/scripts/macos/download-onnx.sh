#!/bin/bash
# Download ONNX Runtime macOS universal2 (arm64 + x86_64)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
ONNX_DIR="${ROOT_DIR}/third_party/onnxruntime-macos"

# Load versions from centralized VERSIONS file
source "${SCRIPT_DIR}/../load-versions.sh"

# Use centralized version (fallback to hardcoded if not set)
# Note: macOS only has dynamic library (.dylib), not static (.a)
ONNX_VERSION="${ONNX_VERSION_MACOS:-1.23.2}"
DOWNLOAD_URL="https://github.com/microsoft/onnxruntime/releases/download/v${ONNX_VERSION}/onnxruntime-osx-universal2-${ONNX_VERSION}.tgz"

echo "=== Downloading ONNX Runtime v${ONNX_VERSION} for macOS ==="
echo "Note: macOS ONNX Runtime is a dynamic library (.dylib)"
echo ""

# Create temp directory for download
TEMP_DIR=$(mktemp -d)
TEMP_TGZ="${TEMP_DIR}/onnxruntime-macos.tgz"

# Download
echo "Downloading from ${DOWNLOAD_URL}..."
curl -L --progress-bar -o "${TEMP_TGZ}" "${DOWNLOAD_URL}"

# Verify download
if [ ! -f "${TEMP_TGZ}" ]; then
    echo "Error: Download failed"
    exit 1
fi

echo "Download complete. Size: $(du -h "${TEMP_TGZ}" | cut -f1)"

# Extract
echo "Extracting..."
rm -rf "${ONNX_DIR}"
mkdir -p "${ONNX_DIR}"

# Extract to temp first, then move contents
tar -xzf "${TEMP_TGZ}" -C "${TEMP_DIR}"

# Find the extracted directory (handles any version naming)
EXTRACTED_DIR=$(find "${TEMP_DIR}" -mindepth 1 -maxdepth 1 -type d -name "onnxruntime-*" | head -1)

if [ -z "${EXTRACTED_DIR}" ]; then
    echo "Error: Could not find extracted directory"
    ls -la "${TEMP_DIR}"
    rm -rf "${TEMP_DIR}"
    exit 1
fi

# Move contents to target directory
mv "${EXTRACTED_DIR}"/* "${ONNX_DIR}/"

# Clean up
rm -rf "${TEMP_DIR}"

# Verify structure
if [ ! -f "${ONNX_DIR}/lib/libonnxruntime.dylib" ]; then
    echo "Error: libonnxruntime.dylib not found after extraction"
    ls -la "${ONNX_DIR}"
    exit 1
fi

echo ""
echo "ONNX Runtime for macOS downloaded to: ${ONNX_DIR}"
echo ""
echo "Contents:"
ls -lh "${ONNX_DIR}/lib/"
echo ""
echo "Headers:"
ls "${ONNX_DIR}/include/" 2>/dev/null || echo "  (none at top level)"
echo ""
echo "Note: This is a DYNAMIC library. Your macOS app must embed libonnxruntime.dylib"
echo "      or have it installed via Homebrew (brew install onnxruntime)"
