#!/bin/bash

# =============================================================================
# build.sh - macOS
# Builds RunAnywhereCore static libraries for macOS (arm64 + x86_64)
# Usage: ./build.sh [--onnx] [--llamacpp] [--all]
#        Default: --all (includes all available backends)
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build/macos"
DIST_DIR="${ROOT_DIR}/dist"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
}

print_step() {
    echo -e "${YELLOW}-> $1${NC}"
}

print_success() {
    echo -e "${GREEN}[OK] $1${NC}"
}

print_error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}[WARN] $1${NC}"
}

# =============================================================================
# Parse Arguments
# =============================================================================

BUILD_ONNX=false
BUILD_LLAMACPP=false
BUILD_ALL=false

# If no arguments, default to --all
if [ $# -eq 0 ]; then
    BUILD_ALL=true
fi

# Parse flags
while [[ $# -gt 0 ]]; do
    case $1 in
        --onnx)
            BUILD_ONNX=true
            shift
            ;;
        --llamacpp)
            BUILD_LLAMACPP=true
            shift
            ;;
        --all)
            BUILD_ALL=true
            shift
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Usage: $0 [--onnx] [--llamacpp] [--all]"
            exit 1
            ;;
    esac
done

# If --all specified, enable all backends
if [ "$BUILD_ALL" = true ]; then
    BUILD_ONNX=true
    BUILD_LLAMACPP=true
fi

# Validate at least one backend selected
if [ "$BUILD_ONNX" = false ] && [ "$BUILD_LLAMACPP" = false ]; then
    print_error "No backends selected. Use --onnx, --llamacpp, or --all"
    exit 1
fi

print_header "Building RunAnywhereCore for macOS"

echo "Backends to include:"
[ "$BUILD_ONNX" = true ] && echo "  - ONNX Runtime (dynamic linking)"
[ "$BUILD_LLAMACPP" = true ] && echo "  - LlamaCPP (Metal GPU acceleration)"
echo ""

MACOS_DEPLOYMENT_TARGET="${MACOS_DEPLOYMENT_TARGET:-14.0}"
echo "macOS Deployment Target: ${MACOS_DEPLOYMENT_TARGET}"

# =============================================================================
# Prerequisites
# =============================================================================

print_step "Checking prerequisites..."

if ! command -v cmake &> /dev/null; then
    print_error "cmake not found. Install with: brew install cmake"
    exit 1
fi

if ! command -v xcodebuild &> /dev/null; then
    print_error "xcodebuild not found. Install Xcode from App Store."
    exit 1
fi

# Backend-specific checks
SHERPA_AVAILABLE=false

if [ "$BUILD_ONNX" = true ]; then
    ONNX_MACOS_DIR="${ROOT_DIR}/third_party/onnxruntime-macos"
    if [ ! -d "${ONNX_MACOS_DIR}" ] || [ ! -f "${ONNX_MACOS_DIR}/lib/libonnxruntime.dylib" ]; then
        print_warning "ONNX Runtime for macOS not found"
        echo "Downloading ONNX Runtime for macOS..."
        "${SCRIPT_DIR}/download-onnx.sh"
    fi
    print_success "Found ONNX Runtime for macOS"

    # Check for Sherpa-ONNX (for STT/TTS/VAD capabilities)
    SHERPA_MACOS_DIR="${ROOT_DIR}/third_party/sherpa-onnx-macos"
    if [ ! -d "${SHERPA_MACOS_DIR}" ] || [ ! -f "${SHERPA_MACOS_DIR}/lib/libsherpa-onnx-c-api.a" ]; then
        print_warning "Sherpa-ONNX for macOS not found"
        echo "Downloading Sherpa-ONNX for macOS (for STT/TTS/VAD)..."
        "${SCRIPT_DIR}/download-sherpa-onnx.sh"
    fi
    if [ -f "${SHERPA_MACOS_DIR}/lib/libsherpa-onnx-c-api.a" ]; then
        print_success "Found Sherpa-ONNX for macOS"
        SHERPA_AVAILABLE=true
    else
        print_warning "Sherpa-ONNX not available - STT/TTS/VAD disabled"
        SHERPA_AVAILABLE=false
    fi
fi

if [ "$BUILD_LLAMACPP" = true ]; then
    print_success "LlamaCPP will be fetched via CMake FetchContent"
fi

# =============================================================================
# Clean Previous Build
# =============================================================================

print_step "Cleaning previous build..."
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"
mkdir -p "${DIST_DIR}"

# =============================================================================
# Build CMake Flags
# =============================================================================

CMAKE_BACKEND_FLAGS=""
if [ "$BUILD_ONNX" = true ]; then
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_ONNX=ON"
else
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_ONNX=OFF"
fi

if [ "$BUILD_LLAMACPP" = true ]; then
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_LLAMACPP=ON"
else
    CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_LLAMACPP=OFF"
fi

# Always disable other backends for now
CMAKE_BACKEND_FLAGS="${CMAKE_BACKEND_FLAGS} -DRA_BUILD_COREML=OFF -DRA_BUILD_TFLITE=OFF"

# =============================================================================
# Build for macOS arm64 (Apple Silicon)
# =============================================================================

print_header "Building for macOS arm64 (Apple Silicon)"

cmake -B "${BUILD_DIR}/arm64" \
    -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=${MACOS_DEPLOYMENT_TARGET} \
    ${CMAKE_BACKEND_FLAGS} \
    -DRA_BUILD_TESTS=OFF \
    -DRA_BUILD_SHARED=OFF \
    "${ROOT_DIR}"

cmake --build "${BUILD_DIR}/arm64" --config Release -j$(sysctl -n hw.ncpu)

print_success "macOS arm64 build complete"

# =============================================================================
# Build for macOS x86_64 (Intel)
# =============================================================================

print_header "Building for macOS x86_64 (Intel)"

# When cross-compiling x86_64 on Apple Silicon, we must disable native CPU
# detection (-march=native) because it would try to use ARM CPU features.
# GGML_NATIVE=OFF disables this, allowing proper x86_64 cross-compilation.
cmake -B "${BUILD_DIR}/x86_64" \
    -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_OSX_ARCHITECTURES=x86_64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=${MACOS_DEPLOYMENT_TARGET} \
    -DGGML_NATIVE=OFF \
    ${CMAKE_BACKEND_FLAGS} \
    -DRA_BUILD_TESTS=OFF \
    -DRA_BUILD_SHARED=OFF \
    "${ROOT_DIR}"

cmake --build "${BUILD_DIR}/x86_64" --config Release -j$(sysctl -n hw.ncpu)

print_success "macOS x86_64 build complete"

# =============================================================================
# Locate and Combine Libraries
# =============================================================================

print_header "Combining Libraries"

# Arrays to hold all libraries for each architecture
ARM64_LIBS=()
X86_64_LIBS=()

# Bridge library (always present)
ARM64_BRIDGE_LIB="${BUILD_DIR}/arm64/librunanywhere_bridge.a"
X86_64_BRIDGE_LIB="${BUILD_DIR}/x86_64/librunanywhere_bridge.a"

if [ ! -f "${ARM64_BRIDGE_LIB}" ]; then
    print_error "Bridge library not found at ${ARM64_BRIDGE_LIB}"
    exit 1
fi

ARM64_LIBS+=("${ARM64_BRIDGE_LIB}")
X86_64_LIBS+=("${X86_64_BRIDGE_LIB}")

print_success "Found bridge libraries"

# =============================================================================
# ONNX Backend Libraries
# =============================================================================

if [ "$BUILD_ONNX" = true ]; then
    print_step "Collecting ONNX backend libraries..."

    ARM64_ONNX_BACKEND="${BUILD_DIR}/arm64/src/backends/onnx/librunanywhere_onnx.a"
    X86_64_ONNX_BACKEND="${BUILD_DIR}/x86_64/src/backends/onnx/librunanywhere_onnx.a"

    if [ ! -f "${ARM64_ONNX_BACKEND}" ]; then
        print_error "ONNX backend library not found at ${ARM64_ONNX_BACKEND}"
        exit 1
    fi

    ARM64_LIBS+=("${ARM64_ONNX_BACKEND}")
    X86_64_LIBS+=("${X86_64_ONNX_BACKEND}")

    print_success "Added ONNX backend libraries"
    print_warning "Note: ONNX Runtime dylib must be bundled with your app separately"

    # =========================================================================
    # Sherpa-ONNX Libraries (for STT/TTS/VAD)
    # =========================================================================
    if [ "$SHERPA_AVAILABLE" = true ]; then
        print_step "Collecting Sherpa-ONNX libraries (STT/TTS/VAD)..."

        SHERPA_MACOS_DIR="${ROOT_DIR}/third_party/sherpa-onnx-macos"
        SHERPA_THIN_DIR="${BUILD_DIR}/sherpa-thin"

        # Sherpa-ONNX libraries are universal (arm64 + x86_64)
        # We need to extract thin slices because libtool preserves all architectures
        # and we need separate arm64 and x86_64 libs for the final lipo step
        print_step "Extracting thin slices from Sherpa-ONNX universal libraries..."
        mkdir -p "${SHERPA_THIN_DIR}/arm64"
        mkdir -p "${SHERPA_THIN_DIR}/x86_64"

        SHERPA_LIBS=(
            "sherpa-onnx-c-api"
            "sherpa-onnx-core"
            "sherpa-onnx-fst"
            "sherpa-onnx-fstfar"
            "sherpa-onnx-kaldifst-core"
            "kaldi-decoder-core"
            "kaldi-native-fbank-core"
            "piper_phonemize"
            "espeak-ng"
            "ucd"
            "cppinyin_core"
            "ssentencepiece_core"
            "kissfft-float"
        )

        for lib in "${SHERPA_LIBS[@]}"; do
            SHERPA_LIB="${SHERPA_MACOS_DIR}/lib/lib${lib}.a"
            if [ -f "$SHERPA_LIB" ]; then
                # Extract arm64 thin slice
                lipo -thin arm64 "$SHERPA_LIB" -output "${SHERPA_THIN_DIR}/arm64/lib${lib}.a" 2>/dev/null || \
                    cp "$SHERPA_LIB" "${SHERPA_THIN_DIR}/arm64/lib${lib}.a"
                # Extract x86_64 thin slice
                lipo -thin x86_64 "$SHERPA_LIB" -output "${SHERPA_THIN_DIR}/x86_64/lib${lib}.a" 2>/dev/null || \
                    cp "$SHERPA_LIB" "${SHERPA_THIN_DIR}/x86_64/lib${lib}.a"

                ARM64_LIBS+=("${SHERPA_THIN_DIR}/arm64/lib${lib}.a")
                X86_64_LIBS+=("${SHERPA_THIN_DIR}/x86_64/lib${lib}.a")
                echo "  Added: ${lib}"
            else
                echo "  Skipped (not found): ${lib}"
            fi
        done

        print_success "Added Sherpa-ONNX libraries"
    else
        print_warning "Sherpa-ONNX not available - skipping STT/TTS/VAD libraries"
    fi
fi

# =============================================================================
# LlamaCPP Backend Libraries
# =============================================================================

if [ "$BUILD_LLAMACPP" = true ]; then
    print_step "Collecting LlamaCPP backend libraries..."

    ARM64_LLAMACPP_BACKEND="${BUILD_DIR}/arm64/src/backends/llamacpp/librunanywhere_llamacpp.a"
    X86_64_LLAMACPP_BACKEND="${BUILD_DIR}/x86_64/src/backends/llamacpp/librunanywhere_llamacpp.a"

    if [ ! -f "${ARM64_LLAMACPP_BACKEND}" ]; then
        print_error "LlamaCPP backend library not found at ${ARM64_LLAMACPP_BACKEND}"
        exit 1
    fi

    ARM64_LIBS+=("${ARM64_LLAMACPP_BACKEND}")
    X86_64_LIBS+=("${X86_64_LLAMACPP_BACKEND}")

    # llama.cpp libraries (built by FetchContent)
    LLAMA_LIBS=(
        "llama"
        "common"
        "ggml"
        "ggml-base"
        "ggml-cpu"
        "ggml-metal"
        "ggml-blas"
    )

    for lib in "${LLAMA_LIBS[@]}"; do
        ARM64_BASE="${BUILD_DIR}/arm64/_deps/llamacpp-build"
        X86_64_BASE="${BUILD_DIR}/x86_64/_deps/llamacpp-build"

        # Different paths for different libs (llama.cpp has complex directory structure)
        if [ "$lib" = "llama" ]; then
            ARM64_LIB="${ARM64_BASE}/src/lib${lib}.a"
            X86_64_LIB="${X86_64_BASE}/src/lib${lib}.a"
        elif [ "$lib" = "common" ]; then
            ARM64_LIB="${ARM64_BASE}/common/lib${lib}.a"
            X86_64_LIB="${X86_64_BASE}/common/lib${lib}.a"
        elif [ "$lib" = "ggml-metal" ]; then
            ARM64_LIB="${ARM64_BASE}/ggml/src/ggml-metal/lib${lib}.a"
            X86_64_LIB="${X86_64_BASE}/ggml/src/ggml-metal/lib${lib}.a"
        elif [ "$lib" = "ggml-blas" ]; then
            ARM64_LIB="${ARM64_BASE}/ggml/src/ggml-blas/lib${lib}.a"
            X86_64_LIB="${X86_64_BASE}/ggml/src/ggml-blas/lib${lib}.a"
        else
            # Core ggml libs (ggml, ggml-base, ggml-cpu) are in ggml/src/
            ARM64_LIB="${ARM64_BASE}/ggml/src/lib${lib}.a"
            X86_64_LIB="${X86_64_BASE}/ggml/src/lib${lib}.a"
        fi

        if [ -f "$ARM64_LIB" ]; then
            ARM64_LIBS+=("$ARM64_LIB")
            X86_64_LIBS+=("$X86_64_LIB")
            echo "  Added: ${lib}"
        else
            echo "  Skipped (not found): ${lib}"
        fi
    done

    print_success "Added LlamaCPP libraries"
fi

echo "arm64 libs to combine: ${#ARM64_LIBS[@]} files"
echo "x86_64 libs to combine: ${#X86_64_LIBS[@]} files"

# =============================================================================
# Create Combined Static Libraries per Architecture
# =============================================================================

print_step "Creating arm64 static library..."
libtool -static -o "${BUILD_DIR}/arm64/libRunAnywhereCore.a" "${ARM64_LIBS[@]}"
print_success "arm64 library created: $(du -sh ${BUILD_DIR}/arm64/libRunAnywhereCore.a | cut -f1)"

print_step "Creating x86_64 static library..."
libtool -static -o "${BUILD_DIR}/x86_64/libRunAnywhereCore.a" "${X86_64_LIBS[@]}"
print_success "x86_64 library created: $(du -sh ${BUILD_DIR}/x86_64/libRunAnywhereCore.a | cut -f1)"

# =============================================================================
# Create Universal Binary (arm64 + x86_64)
# =============================================================================

print_header "Creating Universal Binary"

UNIVERSAL_DIR="${BUILD_DIR}/universal"
mkdir -p "${UNIVERSAL_DIR}"

lipo -create \
    "${BUILD_DIR}/arm64/libRunAnywhereCore.a" \
    "${BUILD_DIR}/x86_64/libRunAnywhereCore.a" \
    -output "${UNIVERSAL_DIR}/libRunAnywhereCore.a"

print_success "Universal library created: $(du -sh ${UNIVERSAL_DIR}/libRunAnywhereCore.a | cut -f1)"

# Verify universal binary
echo "Architectures in universal binary:"
lipo -info "${UNIVERSAL_DIR}/libRunAnywhereCore.a"

# =============================================================================
# Prepare Headers
# =============================================================================

print_header "Preparing Headers"

HEADERS_PARENT="${BUILD_DIR}/Headers"
HEADERS_DIR="${HEADERS_PARENT}/RunAnywhereCore"
mkdir -p "${HEADERS_DIR}"

# 1. Create ra_types.h
print_step "Creating shared ra_types.h..."
sed -e "s/RUNANYWHERE_TYPES_H/RA_CORE_TYPES_H/g" \
    "${ROOT_DIR}/src/capabilities/types.h" > "${HEADERS_DIR}/ra_types.h"

# 2. Create backend-specific bridge headers
if [ "$BUILD_ONNX" = true ]; then
    print_step "Creating ra_onnx_bridge.h..."
    sed -e "s/RUNANYWHERE_BRIDGE_H/RA_ONNX_BRIDGE_H/g" \
        -e "s/#include \"types.h\"/#include \"ra_types.h\"/g" \
        -e "s/#include \"\.\.\/capabilities\/types\.h\"/#include \"ra_types.h\"/g" \
        "${ROOT_DIR}/src/bridge/runanywhere_bridge.h" > "${HEADERS_DIR}/ra_onnx_bridge.h"
fi

if [ "$BUILD_LLAMACPP" = true ]; then
    print_step "Creating ra_llamacpp_bridge.h..."
    sed -e "s/RUNANYWHERE_BRIDGE_H/RA_LLAMACPP_BRIDGE_H/g" \
        -e "s/#include \"types.h\"/#include \"ra_types.h\"/g" \
        -e "s/#include \"\.\.\/capabilities\/types\.h\"/#include \"ra_types.h\"/g" \
        "${ROOT_DIR}/src/bridge/runanywhere_bridge.h" > "${HEADERS_DIR}/ra_llamacpp_bridge.h"
fi

# 3. Create umbrella header ra_core.h
print_step "Creating umbrella header ra_core.h..."
cat > "${HEADERS_DIR}/ra_core.h" << 'EOF'
#ifndef RA_CORE_H
#define RA_CORE_H

/**
 * RunAnywhereCore - Unified ML Inference Library
 *
 * This umbrella header includes all available backend APIs.
 * Each backend provides the same capability-based C API.
 */

// Shared types used across all backends
#include "ra_types.h"

// Backend-specific APIs (same interface, different implementations)
EOF

if [ "$BUILD_ONNX" = true ]; then
    echo '#include "ra_onnx_bridge.h"' >> "${HEADERS_DIR}/ra_core.h"
fi

if [ "$BUILD_LLAMACPP" = true ]; then
    echo '#include "ra_llamacpp_bridge.h"' >> "${HEADERS_DIR}/ra_core.h"
fi

cat >> "${HEADERS_DIR}/ra_core.h" << 'EOF'

#endif // RA_CORE_H
EOF

print_success "Created umbrella header"

# 4. Create module.modulemap
print_step "Creating module.modulemap..."
cat > "${HEADERS_PARENT}/module.modulemap" << 'EOF'
module RunAnywhereCore {
    umbrella header "RunAnywhereCore/ra_core.h"

    export *
    module * { export * }
}
EOF

print_success "Headers structure created"

# =============================================================================
# Copy Universal Library to dist
# =============================================================================

print_step "Copying to dist directory..."
cp "${UNIVERSAL_DIR}/libRunAnywhereCore.a" "${DIST_DIR}/"
cp -R "${HEADERS_PARENT}" "${DIST_DIR}/Headers-macOS"

# Also copy ONNX Runtime dylib if ONNX backend enabled
if [ "$BUILD_ONNX" = true ]; then
    ONNX_MACOS_DIR="${ROOT_DIR}/third_party/onnxruntime-macos"
    mkdir -p "${DIST_DIR}/onnxruntime-macos"
    cp "${ONNX_MACOS_DIR}/lib/libonnxruntime"* "${DIST_DIR}/onnxruntime-macos/"
    print_success "Copied ONNX Runtime dylib to dist"
fi

# =============================================================================
# Summary
# =============================================================================

print_header "Build Complete!"

echo "macOS Build Output:"
echo "  Universal Library: ${DIST_DIR}/libRunAnywhereCore.a"
echo "  Headers:           ${DIST_DIR}/Headers-macOS/"
if [ "$BUILD_ONNX" = true ]; then
    echo "  ONNX Runtime:      ${DIST_DIR}/onnxruntime-macos/"
fi
echo ""

echo "Sizes:"
echo "  arm64:     $(du -sh ${BUILD_DIR}/arm64/libRunAnywhereCore.a | cut -f1)"
echo "  x86_64:    $(du -sh ${BUILD_DIR}/x86_64/libRunAnywhereCore.a | cut -f1)"
echo "  Universal: $(du -sh ${UNIVERSAL_DIR}/libRunAnywhereCore.a | cut -f1)"
echo ""

echo "Backends included:"
[ "$BUILD_ONNX" = true ] && echo "  - ONNX Runtime (dynamic linking to libonnxruntime.dylib)"
[ "$BUILD_LLAMACPP" = true ] && echo "  - LlamaCPP (Metal GPU acceleration)"
if [ "$BUILD_ONNX" = true ] && [ "$SHERPA_AVAILABLE" = true ]; then
    echo "  - Sherpa-ONNX (STT, TTS, VAD, Speaker Diarization)"
fi
echo ""

echo "Required frameworks to link in your macOS app:"
echo "  - Foundation.framework"
echo "  - CoreML.framework"
echo "  - Accelerate.framework"
[ "$BUILD_LLAMACPP" = true ] && echo "  - Metal.framework"
[ "$BUILD_LLAMACPP" = true ] && echo "  - MetalKit.framework"
if [ "$BUILD_ONNX" = true ]; then
    echo ""
    echo "IMPORTANT: For ONNX backend, you must also:"
    echo "  1. Embed libonnxruntime.dylib in your app bundle"
    echo "  2. Or install via: brew install onnxruntime"
fi
echo ""

echo -e "${GREEN}Done!${NC}"
