# macOS Build Scripts

Build scripts for creating RunAnywhereCore static libraries for macOS.

## Quick Start

```bash
# 1. Download ONNX Runtime for macOS (required for ONNX backend)
./scripts/macos/download-onnx.sh

# 2. Build for macOS (creates universal arm64 + x86_64 library)
./scripts/macos/build.sh

# 3. Create combined XCFramework (optional - includes iOS + macOS)
./scripts/build-xcframework.sh
```

## Scripts

### `download-onnx.sh`

Downloads ONNX Runtime v1.23.2 universal binary for macOS.

**Output:**
- `third_party/onnxruntime-macos/lib/libonnxruntime.dylib`
- `third_party/onnxruntime-macos/include/`

**Note:** ONNX Runtime for macOS is a **dynamic library** (`.dylib`), not static. Your macOS app must embed this dylib.

### `build.sh`

Builds RunAnywhereCore static libraries for macOS arm64 and x86_64.

**Usage:**
```bash
./scripts/macos/build.sh [--onnx] [--llamacpp] [--all]
```

**Options:**
- `--onnx` - Build with ONNX Runtime backend only
- `--llamacpp` - Build with LlamaCPP backend only
- `--all` - Build with all backends (default)

**Output:**
- `build/macos/arm64/libRunAnywhereCore.a` - Apple Silicon
- `build/macos/x86_64/libRunAnywhereCore.a` - Intel
- `build/macos/universal/libRunAnywhereCore.a` - Universal binary
- `dist/Headers-macOS/` - Headers for macOS

## Build Output Structure

```
dist/
├── libRunAnywhereCore.a          # macOS universal static library
├── Headers-macOS/
│   ├── module.modulemap
│   └── RunAnywhereCore/
│       ├── ra_core.h             # Umbrella header
│       ├── ra_types.h            # Shared types
│       ├── ra_onnx_bridge.h      # ONNX backend API
│       └── ra_llamacpp_bridge.h  # LlamaCPP backend API
└── onnxruntime-macos/
    └── libonnxruntime.dylib      # Must be embedded in app
```

## Integrating with macOS Apps

### Linking Requirements

Add these frameworks to your Xcode project:
- `Foundation.framework`
- `CoreML.framework`
- `Accelerate.framework`
- `Metal.framework` (for LlamaCPP GPU acceleration)
- `MetalKit.framework` (for LlamaCPP GPU acceleration)

### ONNX Runtime Embedding

For the ONNX backend, you must embed `libonnxruntime.dylib`:

1. Copy `dist/onnxruntime-macos/libonnxruntime*.dylib` to your app bundle
2. In Xcode: Target → General → Frameworks → Add → "Add Other"
3. Set "Embed & Sign" for the dylib

**Alternative:** Install via Homebrew:
```bash
brew install onnxruntime
```

### XCFramework (Recommended)

For Swift Package Manager or CocoaPods integration, use the combined XCFramework:

```bash
# Build iOS first
./scripts/ios/build.sh

# Build macOS
./scripts/macos/build.sh

# Create combined XCFramework
./scripts/build-xcframework.sh
```

This creates `dist/RunAnywhereCore.xcframework` with slices for:
- `ios-arm64` (iPhone device)
- `ios-arm64_x86_64-simulator` (iPhone simulator)
- `macos-arm64_x86_64` (macOS universal)

## Environment Variables

- `MACOS_DEPLOYMENT_TARGET` - Minimum macOS version (default: 14.0)

Example:
```bash
MACOS_DEPLOYMENT_TARGET=13.0 ./scripts/macos/build.sh
```

## Troubleshooting

### "ONNX Runtime not found"

Run the download script first:
```bash
./scripts/macos/download-onnx.sh
```

### "dyld: Library not loaded: libonnxruntime.dylib"

The ONNX Runtime dylib is not embedded in your app. See "ONNX Runtime Embedding" above.

### Build fails with architecture errors

Ensure you have Xcode Command Line Tools installed:
```bash
xcode-select --install
```

### Metal not found (x86_64)

Metal GPU acceleration may not be available on older Intel Macs. The library will still work but without GPU acceleration for LlamaCPP.
