# Building Unified RunAnywhereCore XCFramework

## Overview

The `build-ios-core.sh` script creates a unified RunAnywhereCore XCFramework that combines multiple ML backends (ONNX, LlamaCPP) into a single static library with a unified header structure.

## Problem Solved

**Before**: Separate xcframeworks (RunAnywhereONNX.xcframework, RunAnywhereLlamaCPP.xcframework) each had their own `module.modulemap` at the root, causing Xcode build conflicts when using multiple backends together.

**After**: Single unified RunAnywhereCore.xcframework with one modulemap and properly namespaced headers.

## Build Process

### 1. Separate Backend Builds

The script builds each backend separately using CMake:
- ONNX backend: Links with ONNX Runtime + optional Sherpa-ONNX
- LlamaCPP backend: Fetches llama.cpp via CMake, builds with Metal support

### 2. Library Combination

Uses `libtool -static` to combine all .a files into single static libraries:
- Device (arm64): All backend .a files → libRunAnywhereCore.a
- Simulator (arm64 + x86_64): All backend .a files → libRunAnywhereCore.a

Libraries combined:
- librunanywhere_bridge.a (always)
- librunanywhere_onnx.a (if --onnx)
- libonnxruntime.a (if --onnx)
- libsherpa-onnx.a (if --onnx and available)
- librunanywhere_llamacpp.a (if --llamacpp)
- libllama.a, libcommon.a (if --llamacpp)
- libggml*.a (if --llamacpp)

### 3. Header Structure Creation

Creates unified header directory:
```
Headers/
  module.modulemap          # Single modulemap, no conflicts
  RunAnywhereCore/
    ra_core.h              # Umbrella header (includes all)
    ra_types.h             # Shared types (single copy)
    ra_onnx_bridge.h       # ONNX backend API
    ra_llamacpp_bridge.h   # LlamaCPP backend API
```

**Key transformations**:
- `types.h` → `ra_types.h` with guard `RA_CORE_TYPES_H`
- `runanywhere_bridge.h` → `ra_onnx_bridge.h` with guard `RA_ONNX_BRIDGE_H`
- `runanywhere_bridge.h` → `ra_llamacpp_bridge.h` with guard `RA_LLAMACPP_BRIDGE_H`
- Each backend header includes `ra_types.h` instead of `types.h`

### 4. XCFramework Assembly

Uses `xcodebuild -create-xcframework` to package:
- Device library + headers
- Simulator library + headers
- Info.plist metadata

## Usage

```bash
# Build with all backends (default)
./scripts/build-ios-core.sh
./scripts/build-ios-core.sh --all

# Build with ONNX only
./scripts/build-ios-core.sh --onnx

# Build with LlamaCPP only
./scripts/build-ios-core.sh --llamacpp

# Build with multiple specific backends
./scripts/build-ios-core.sh --onnx --llamacpp
```

## Output

```
dist/RunAnywhereCore.xcframework/
  Info.plist
  ios-arm64/
    libRunAnywhereCore.a (81 MB)
    Headers/
      module.modulemap
      RunAnywhereCore/
        ra_core.h
        ra_types.h
        ra_onnx_bridge.h
        ra_llamacpp_bridge.h
  ios-arm64_x86_64-simulator/
    libRunAnywhereCore.a (164 MB)
    Headers/
      [same structure as device]
```

## Size Comparison

| Build Configuration | Device Size | Simulator Size | Total |
|---------------------|-------------|----------------|-------|
| --onnx only         | 78 MB       | 157 MB         | 235 MB |
| --llamacpp only     | 3.7 MB      | 7 MB           | 11 MB |
| --all (unified)     | 81 MB       | 164 MB         | 246 MB |

The unified build has zero duplication - it's exactly the sum of individual backends.

## Technical Details

### Why Single ra_types.h?

The types.h file is compiled into the bridge library, but each backend's static library references the same symbols. By having a single ra_types.h header, we ensure:
- No duplicate type definitions
- No ODR (One Definition Rule) violations
- Single source of truth for types

### Include Guards

- `RA_CORE_TYPES_H` - Shared types header
- `RA_ONNX_BRIDGE_H` - ONNX backend API
- `RA_LLAMACPP_BRIDGE_H` - LlamaCPP backend API
- `RA_CORE_H` - Umbrella header

All guards are unique to prevent conflicts.

### Module Map

```
module RunAnywhereCore {
    umbrella header "RunAnywhereCore/ra_core.h"
    export *
    module * { export * }
}
```

The umbrella header automatically includes all subheaders, giving Swift/Objective-C access to the entire unified API.

## Benefits

1. **No Modulemap Conflicts**: Single module.modulemap at root
2. **No Duplicate Symbols**: Shared ra_types.h compiled once
3. **Clean API**: Single umbrella header to import
4. **Flexible Builds**: Choose which backends to include
5. **Same Size**: No overhead from unification
6. **Future-Proof**: Easy to add CoreML, TFLite backends

## Adding New Backends

To add a new backend (e.g., CoreML):

1. Add `BUILD_COREML` flag parsing in script
2. Add CMake backend flag: `-DRA_BUILD_COREML=ON/OFF`
3. Collect CoreML backend libraries
4. Create `ra_coreml_bridge.h` from runanywhere_bridge.h
5. Add include to ra_core.h umbrella header
6. Update verification section

The structure is fully scalable for any number of backends.
