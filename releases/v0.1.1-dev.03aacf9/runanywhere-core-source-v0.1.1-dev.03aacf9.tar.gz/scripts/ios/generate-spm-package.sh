#!/bin/bash

# =============================================================================
# generate-spm-package.sh
# Generates Package.swift and podspec for the public binaries repo
#
# Usage: ./generate-spm-package.sh <version> <artifacts-dir>
#
# This script reads the checksums from the built artifacts and generates:
#   1. Package.swift - Swift Package Manager manifest with binary targets
#   2. *.podspec - CocoaPods podspec for each backend
#
# Each backend gets its own standalone package (e.g., RunAnywhereONNX)
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="${1:-0.0.0}"
ARTIFACTS_DIR="${2:-.}"
OUTPUT_DIR="${ARTIFACTS_DIR}"

# Configuration - Update these for your organization
GITHUB_ORG="${PUBLIC_REPO_OWNER:-RunanywhereAI}"
REPO_NAME="${PUBLIC_REPO_NAME:-runanywhere-binaries}"
BASE_URL="https://github.com/${GITHUB_ORG}/${REPO_NAME}/releases/download/v${VERSION}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}Generating SPM Package.swift and CocoaPods podspec${NC}"
echo "Version: ${VERSION}"
echo "Artifacts dir: ${ARTIFACTS_DIR}"
echo "Base URL: ${BASE_URL}"
echo ""

# =============================================================================
# Read checksums from .sha256 files
# =============================================================================

get_checksum() {
    local framework_name="$1"
    local sha_file="${ARTIFACTS_DIR}/${framework_name}.xcframework.zip.sha256"

    if [ -f "$sha_file" ]; then
        # SHA256 file format: <hash>  <filename> or <hash> <filename>
        awk '{print $1}' "$sha_file"
    else
        echo "CHECKSUM_NOT_FOUND"
    fi
}

# Detect unified framework (new approach - single RunAnywhereCore.xcframework)
CORE_CHECKSUM=$(get_checksum "RunAnywhereCore")

echo "Detected checksums:"
echo "  RunAnywhereCore: ${CORE_CHECKSUM:0:16}..."
echo ""

# Check if we have the unified framework
if [ "$CORE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
    BACKEND_COUNT=1
    USE_UNIFIED=true
    echo "Using unified RunAnywhereCore.xcframework"
else
    # Fallback: check for legacy per-backend frameworks
    USE_UNIFIED=false
    ONNX_CHECKSUM=$(get_checksum "RunAnywhereONNX")
    COREML_CHECKSUM=$(get_checksum "RunAnywhereCoreML")
    TFLITE_CHECKSUM=$(get_checksum "RunAnywhereTFLite")

    echo "Detected legacy checksums:"
    echo "  ONNX: ${ONNX_CHECKSUM:0:16}..."
    echo "  CoreML: ${COREML_CHECKSUM:0:16}..."
    echo "  TFLite: ${TFLITE_CHECKSUM:0:16}..."
    echo ""

    # Count available backends
    BACKEND_COUNT=0
    [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && BACKEND_COUNT=$((BACKEND_COUNT + 1)) || true
    [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && BACKEND_COUNT=$((BACKEND_COUNT + 1)) || true
    [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && BACKEND_COUNT=$((BACKEND_COUNT + 1)) || true
fi

# =============================================================================
# Generate Package.swift
# =============================================================================

if [ "$USE_UNIFIED" = true ]; then
    # New unified approach - single RunAnywhereCore framework
    PACKAGE_NAME="RunAnywhereCore"

    cat > "${OUTPUT_DIR}/Package.swift" << EOF
// swift-tools-version:5.9
// =============================================================================
// Package.swift
// ${PACKAGE_NAME} - On-device ML inference framework
// Version: ${VERSION}
//
// This package provides a unified XCFramework containing all backends:
//   - ONNX Runtime (Text Gen, Embeddings, STT, TTS, VAD, Diarization)
//   - LlamaCPP (Text Gen with Metal GPU acceleration)
//
// Usage (Swift Package Manager):
//   dependencies: [
//       .package(url: "https://github.com/${GITHUB_ORG}/${REPO_NAME}.git", from: "${VERSION}")
//   ]
//   targets: [
//       .target(name: "YourApp", dependencies: ["${PACKAGE_NAME}"])
//   ]
//
// Generated automatically - do not edit manually
// =============================================================================

import PackageDescription

let package = Package(
    name: "${PACKAGE_NAME}",
    platforms: [
        .iOS(.v15),
        .macOS(.v12)
    ],
    products: [
        .library(
            name: "RunAnywhereCore",
            targets: ["RunAnywhereCore"]
        ),
    ],
    targets: [
        .binaryTarget(
            name: "RunAnywhereCore",
            url: "${BASE_URL}/RunAnywhereCore.xcframework.zip",
            checksum: "${CORE_CHECKSUM}"
        ),
    ]
)
EOF

else
    # Legacy per-backend approach
    # Determine package name based on available backends
    if [ "$BACKEND_COUNT" -eq 1 ]; then
        if [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
            PACKAGE_NAME="RunAnywhereONNX"
        elif [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
            PACKAGE_NAME="RunAnywhereCoreML"
        elif [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
            PACKAGE_NAME="RunAnywhereTFLite"
        fi
    else
        PACKAGE_NAME="RunAnywhere"
    fi

    cat > "${OUTPUT_DIR}/Package.swift" << EOF
// swift-tools-version:5.9
// =============================================================================
// Package.swift
// ${PACKAGE_NAME} - On-device ML inference framework
// Version: ${VERSION}
//
// Usage (Swift Package Manager):
//   dependencies: [
//       .package(url: "https://github.com/${GITHUB_ORG}/${REPO_NAME}.git", from: "${VERSION}")
//   ]
//   targets: [
//       .target(name: "YourApp", dependencies: ["${PACKAGE_NAME}"])
//   ]
//
// Generated automatically - do not edit manually
// =============================================================================

import PackageDescription

let package = Package(
    name: "${PACKAGE_NAME}",
    platforms: [
        .iOS(.v15),
        .macOS(.v12)
    ],
    products: [
EOF

    # Add products based on available backends
    if [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << 'EOF'
        .library(
            name: "RunAnywhereONNX",
            targets: ["RunAnywhereONNX"]
        ),
EOF
    fi

    if [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << 'EOF'
        .library(
            name: "RunAnywhereCoreML",
            targets: ["RunAnywhereCoreML"]
        ),
EOF
    fi

    if [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << 'EOF'
        .library(
            name: "RunAnywhereTFLite",
            targets: ["RunAnywhereTFLite"]
        ),
EOF
    fi

    cat >> "${OUTPUT_DIR}/Package.swift" << 'EOF'
    ],
    targets: [
EOF

    # Add ONNX target
    if [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << EOF
        .binaryTarget(
            name: "RunAnywhereONNX",
            url: "${BASE_URL}/RunAnywhereONNX.xcframework.zip",
            checksum: "${ONNX_CHECKSUM}"
        ),
EOF
    fi

    # Add CoreML target
    if [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << EOF
        .binaryTarget(
            name: "RunAnywhereCoreML",
            url: "${BASE_URL}/RunAnywhereCoreML.xcframework.zip",
            checksum: "${COREML_CHECKSUM}"
        ),
EOF
    fi

    # Add TFLite target
    if [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat >> "${OUTPUT_DIR}/Package.swift" << EOF
        .binaryTarget(
            name: "RunAnywhereTFLite",
            url: "${BASE_URL}/RunAnywhereTFLite.xcframework.zip",
            checksum: "${TFLITE_CHECKSUM}"
        ),
EOF
    fi

    cat >> "${OUTPUT_DIR}/Package.swift" << 'EOF'
    ]
)
EOF

fi

echo -e "${GREEN}Generated: ${OUTPUT_DIR}/Package.swift${NC}"

# =============================================================================
# Generate CocoaPods Podspec
# =============================================================================

if [ "$USE_UNIFIED" = true ]; then
    # Generate unified RunAnywhereCore podspec
    cat > "${OUTPUT_DIR}/RunAnywhereCore.podspec" << EOF
# =============================================================================
# RunAnywhereCore.podspec
# On-device ML inference framework with all backends
# Version: ${VERSION}
#
# Usage:
#   pod 'RunAnywhereCore', '~> ${VERSION}'
#
# Generated automatically - do not edit manually
# =============================================================================

Pod::Spec.new do |s|
  s.name         = 'RunAnywhereCore'
  s.version      = '${VERSION}'
  s.summary      = 'On-device ML inference framework for iOS/macOS'
  s.description  = <<-DESC
    RunAnywhereCore provides on-device machine learning inference for iOS and macOS.
    This unified framework includes all backends in a single package.

    Capabilities:
    - Text Generation - Run LLMs locally on device (ONNX + LlamaCPP)
    - Embeddings - Generate text embeddings for semantic search
    - Speech-to-Text - Batch and real-time streaming transcription
    - Text-to-Speech - Natural voice synthesis
    - Voice Activity Detection - Detect speech in audio
    - Speaker Diarization - Identify different speakers
  DESC

  s.homepage     = 'https://github.com/${GITHUB_ORG}/${REPO_NAME}'
  s.license      = { :type => 'MIT', :file => 'LICENSE' }
  s.author       = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source       = {
    :http => '${BASE_URL}/RunAnywhereCore.xcframework.zip',
    :sha256 => '${CORE_CHECKSUM}'
  }

  s.ios.deployment_target = '15.0'
  s.osx.deployment_target = '12.0'

  s.vendored_frameworks = 'RunAnywhereCore.xcframework'
  s.frameworks = 'Foundation', 'CoreML', 'Accelerate', 'Metal', 'MetalKit'

  s.pod_target_xcconfig = {
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
EOF
    echo -e "${GREEN}Generated: ${OUTPUT_DIR}/RunAnywhereCore.podspec${NC}"

else
    # Generate legacy per-backend podspecs

    # Generate ONNX podspec
    if [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
        cat > "${OUTPUT_DIR}/RunAnywhereONNX.podspec" << EOF
# =============================================================================
# RunAnywhereONNX.podspec
# On-device ML inference framework with ONNX Runtime backend
# Version: ${VERSION}
#
# Usage:
#   pod 'RunAnywhereONNX', '~> ${VERSION}'
#
# Generated automatically - do not edit manually
# =============================================================================

Pod::Spec.new do |s|
  s.name         = 'RunAnywhereONNX'
  s.version      = '${VERSION}'
  s.summary      = 'On-device ML inference framework for iOS/macOS'
  s.description  = <<-DESC
    RunAnywhereONNX provides on-device machine learning inference for iOS and macOS.

    Capabilities:
    - Text Generation - Run LLMs locally on device
    - Embeddings - Generate text embeddings for semantic search
    - Speech-to-Text - Batch and real-time streaming transcription
    - Text-to-Speech - Natural voice synthesis
    - Voice Activity Detection - Detect speech in audio
    - Speaker Diarization - Identify different speakers
  DESC

  s.homepage     = 'https://github.com/${GITHUB_ORG}/${REPO_NAME}'
  s.license      = { :type => 'MIT', :file => 'LICENSE' }
  s.author       = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source       = {
    :http => '${BASE_URL}/RunAnywhereONNX.xcframework.zip',
    :sha256 => '${ONNX_CHECKSUM}'
  }

  s.ios.deployment_target = '15.0'
  s.osx.deployment_target = '12.0'

  s.vendored_frameworks = 'RunAnywhereONNX.xcframework'
  s.frameworks = 'Foundation', 'CoreML', 'Accelerate'

  s.pod_target_xcconfig = {
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
EOF
        echo -e "${GREEN}Generated: ${OUTPUT_DIR}/RunAnywhereONNX.podspec${NC}"
    fi

    # Generate CoreML podspec
    if [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
    cat > "${OUTPUT_DIR}/RunAnywhereCoreML.podspec" << EOF
# =============================================================================
# RunAnywhereCoreML.podspec
# On-device ML inference framework with CoreML backend
# Version: ${VERSION}
#
# Usage:
#   pod 'RunAnywhereCoreML', '~> ${VERSION}'
#
# Generated automatically - do not edit manually
# =============================================================================

Pod::Spec.new do |s|
  s.name         = 'RunAnywhereCoreML'
  s.version      = '${VERSION}'
  s.summary      = 'On-device ML inference with CoreML backend'
  s.description  = <<-DESC
    RunAnywhereCoreML provides on-device machine learning inference using Apple's CoreML.
    Optimized for Apple Neural Engine and Metal acceleration.
  DESC

  s.homepage     = 'https://github.com/${GITHUB_ORG}/${REPO_NAME}'
  s.license      = { :type => 'MIT', :file => 'LICENSE' }
  s.author       = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source       = {
    :http => '${BASE_URL}/RunAnywhereCoreML.xcframework.zip',
    :sha256 => '${COREML_CHECKSUM}'
  }

  s.ios.deployment_target = '15.0'
  s.osx.deployment_target = '12.0'

  s.vendored_frameworks = 'RunAnywhereCoreML.xcframework'
  s.frameworks = 'Foundation', 'CoreML', 'Accelerate', 'Metal'

  s.pod_target_xcconfig = {
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
EOF
        echo -e "${GREEN}Generated: ${OUTPUT_DIR}/RunAnywhereCoreML.podspec${NC}"
    fi

    # Generate TFLite podspec
    if [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
    cat > "${OUTPUT_DIR}/RunAnywhereTFLite.podspec" << EOF
# =============================================================================
# RunAnywhereTFLite.podspec
# On-device ML inference framework with TensorFlow Lite backend
# Version: ${VERSION}
#
# Usage:
#   pod 'RunAnywhereTFLite', '~> ${VERSION}'
#
# Generated automatically - do not edit manually
# =============================================================================

Pod::Spec.new do |s|
  s.name         = 'RunAnywhereTFLite'
  s.version      = '${VERSION}'
  s.summary      = 'On-device ML inference with TensorFlow Lite backend'
  s.description  = <<-DESC
    RunAnywhereTFLite provides on-device machine learning inference using TensorFlow Lite.
    Supports GPU and NNAPI delegates for acceleration.
  DESC

  s.homepage     = 'https://github.com/${GITHUB_ORG}/${REPO_NAME}'
  s.license      = { :type => 'MIT', :file => 'LICENSE' }
  s.author       = { 'RunAnywhere' => 'hello@runanywhere.ai' }
  s.source       = {
    :http => '${BASE_URL}/RunAnywhereTFLite.xcframework.zip',
    :sha256 => '${TFLITE_CHECKSUM}'
  }

  s.ios.deployment_target = '15.0'
  s.osx.deployment_target = '12.0'

  s.vendored_frameworks = 'RunAnywhereTFLite.xcframework'
  s.frameworks = 'Foundation', 'Accelerate', 'Metal'

  s.pod_target_xcconfig = {
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
EOF
        echo -e "${GREEN}Generated: ${OUTPUT_DIR}/RunAnywhereTFLite.podspec${NC}"
    fi

    # Remove the old combined podspec if it exists
    rm -f "${OUTPUT_DIR}/RunAnywhere.podspec"

fi  # End of USE_UNIFIED if/else block

# =============================================================================
# Check for Android artifacts
# =============================================================================

get_android_checksum() {
    local artifact_name="$1"
    local sha_file="${ARTIFACTS_DIR}/${artifact_name}-android.zip.sha256"

    if [ -f "$sha_file" ]; then
        awk '{print $1}' "$sha_file"
    else
        echo "CHECKSUM_NOT_FOUND"
    fi
}

ANDROID_ONNX_CHECKSUM=$(get_android_checksum "RunAnywhereONNX")
ANDROID_TFLITE_CHECKSUM=$(get_android_checksum "RunAnywhereTFLite")

echo "Android checksums:"
echo "  ONNX: ${ANDROID_ONNX_CHECKSUM:0:16}..."
echo "  TFLite: ${ANDROID_TFLITE_CHECKSUM:0:16}..."
echo ""

# Count Android backends
ANDROID_BACKEND_COUNT=0
[ "$ANDROID_ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && ANDROID_BACKEND_COUNT=$((ANDROID_BACKEND_COUNT + 1)) || true
[ "$ANDROID_TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && ANDROID_BACKEND_COUNT=$((ANDROID_BACKEND_COUNT + 1)) || true

# =============================================================================
# Summary
# =============================================================================

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Generation Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "Package name: ${PACKAGE_NAME}"
echo ""
echo "Generated files:"
echo "  - Package.swift (SPM manifest)"

if [ "$USE_UNIFIED" = true ]; then
    echo "  - RunAnywhereCore.podspec"
    echo ""
    echo "iOS XCFramework: Unified"
    echo "  - RunAnywhereCore.xcframework (contains ONNX Runtime + LlamaCPP)"
else
    [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - RunAnywhereONNX.podspec" || true
    [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - RunAnywhereCoreML.podspec" || true
    [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - RunAnywhereTFLite.podspec" || true
    echo ""
    echo "iOS Backends: ${BACKEND_COUNT}"
    [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - ONNX Runtime (XCFramework)" || true
    [ "$COREML_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - CoreML (XCFramework)" || true
    [ "$TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - TensorFlow Lite (XCFramework)" || true
fi

echo ""
echo "Android Backends: ${ANDROID_BACKEND_COUNT}"
[ "$ANDROID_ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - ONNX Runtime (Native .so)" || true
[ "$ANDROID_TFLITE_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  - TensorFlow Lite (Native .so)" || true
echo ""
echo "Consumer usage:"
echo ""
echo "  iOS - Swift Package Manager:"
echo "    dependencies: ["
echo "        .package(url: \"https://github.com/${GITHUB_ORG}/${REPO_NAME}.git\", from: \"${VERSION}\")"
echo "    ]"
echo "    targets: ["
echo "        .target(name: \"YourApp\", dependencies: [\"${PACKAGE_NAME}\"])"
echo "    ]"
echo ""

if [ "$USE_UNIFIED" = true ]; then
    echo "  iOS - CocoaPods:"
    echo "    pod 'RunAnywhereCore', '~> ${VERSION}'"
else
    [ "$ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ] && echo "  iOS - CocoaPods:" && echo "    pod 'RunAnywhereONNX', '~> ${VERSION}'" || true
fi

echo ""
if [ "$ANDROID_ONNX_CHECKSUM" != "CHECKSUM_NOT_FOUND" ]; then
    echo "  Android - Gradle (Kotlin SDK):"
    echo "    dependencies {"
    echo "        implementation(\"com.runanywhere:runanywhere-core-onnx:${VERSION}\")"
    echo "    }"
    echo ""
    echo "  Android - Direct Download:"
    echo "    https://github.com/${GITHUB_ORG}/${REPO_NAME}/releases/download/v${VERSION}/RunAnywhereONNX-android.zip"
fi
echo ""
