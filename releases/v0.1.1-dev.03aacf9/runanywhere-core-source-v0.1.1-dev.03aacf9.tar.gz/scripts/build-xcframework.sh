#!/bin/bash

# =============================================================================
# build-xcframework.sh
# Creates a combined XCFramework with iOS and macOS slices
# Usage: ./build-xcframework.sh [--ios-only] [--macos-only] [--rebuild]
#        Default: Combines existing iOS and macOS builds into single XCFramework
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
DIST_DIR="${ROOT_DIR}/dist"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
}

print_step() {
    echo -e "${YELLOW}-> $1${NC}"
}

print_success() {
    echo -e "${GREEN}[OK] $1${NC}"
}

print_error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}[WARN] $1${NC}"
}

# =============================================================================
# Parse Arguments
# =============================================================================

INCLUDE_IOS=true
INCLUDE_MACOS=true
REBUILD=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --ios-only)
            INCLUDE_MACOS=false
            shift
            ;;
        --macos-only)
            INCLUDE_IOS=false
            shift
            ;;
        --rebuild)
            REBUILD=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  --ios-only     Only include iOS slices"
            echo "  --macos-only   Only include macOS slice"
            echo "  --rebuild      Rebuild iOS and/or macOS before creating XCFramework"
            echo "  -h, --help     Show this help"
            echo ""
            echo "Default: Creates XCFramework with both iOS and macOS slices"
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Use -h for help"
            exit 1
            ;;
    esac
done

print_header "Creating Combined XCFramework"

echo "Configuration:"
echo "  Include iOS:   $INCLUDE_IOS"
echo "  Include macOS: $INCLUDE_MACOS"
echo "  Rebuild:       $REBUILD"
echo ""

# =============================================================================
# Build if requested
# =============================================================================

if [ "$REBUILD" = true ]; then
    if [ "$INCLUDE_IOS" = true ]; then
        print_header "Building iOS"
        "${SCRIPT_DIR}/ios/build.sh"
    fi

    if [ "$INCLUDE_MACOS" = true ]; then
        print_header "Building macOS"
        "${SCRIPT_DIR}/macos/build.sh"
    fi
fi

# =============================================================================
# Locate Build Artifacts
# =============================================================================

print_step "Locating build artifacts..."

# iOS build paths
IOS_BUILD_DIR="${ROOT_DIR}/build/ios-core"
IOS_DEVICE_LIB="${IOS_BUILD_DIR}/ios-arm64/libRunAnywhereCore.a"
IOS_SIM_LIB="${IOS_BUILD_DIR}/ios-simulator/libRunAnywhereCore.a"
IOS_HEADERS="${IOS_BUILD_DIR}/Headers"

# macOS build paths
MACOS_BUILD_DIR="${ROOT_DIR}/build/macos"
MACOS_UNIVERSAL_LIB="${MACOS_BUILD_DIR}/universal/libRunAnywhereCore.a"
MACOS_HEADERS="${MACOS_BUILD_DIR}/Headers"

# Validate required builds exist
XCODE_ARGS=()

if [ "$INCLUDE_IOS" = true ]; then
    if [ ! -f "${IOS_DEVICE_LIB}" ]; then
        print_error "iOS device library not found at ${IOS_DEVICE_LIB}"
        echo "Run: ./scripts/ios/build.sh"
        exit 1
    fi
    if [ ! -f "${IOS_SIM_LIB}" ]; then
        print_error "iOS simulator library not found at ${IOS_SIM_LIB}"
        echo "Run: ./scripts/ios/build.sh"
        exit 1
    fi
    if [ ! -d "${IOS_HEADERS}" ]; then
        print_error "iOS headers not found at ${IOS_HEADERS}"
        exit 1
    fi
    print_success "Found iOS build artifacts"

    XCODE_ARGS+=(
        -library "${IOS_DEVICE_LIB}"
        -headers "${IOS_HEADERS}"
        -library "${IOS_SIM_LIB}"
        -headers "${IOS_HEADERS}"
    )
fi

if [ "$INCLUDE_MACOS" = true ]; then
    if [ ! -f "${MACOS_UNIVERSAL_LIB}" ]; then
        print_error "macOS universal library not found at ${MACOS_UNIVERSAL_LIB}"
        echo "Run: ./scripts/macos/build.sh"
        exit 1
    fi
    if [ ! -d "${MACOS_HEADERS}" ]; then
        print_error "macOS headers not found at ${MACOS_HEADERS}"
        exit 1
    fi
    print_success "Found macOS build artifacts"

    XCODE_ARGS+=(
        -library "${MACOS_UNIVERSAL_LIB}"
        -headers "${MACOS_HEADERS}"
    )
fi

# =============================================================================
# Create XCFramework
# =============================================================================

print_header "Creating XCFramework"

XCFRAMEWORK_PATH="${DIST_DIR}/RunAnywhereCore.xcframework"

# Remove existing XCFramework
rm -rf "${XCFRAMEWORK_PATH}"
mkdir -p "${DIST_DIR}"

print_step "Running xcodebuild -create-xcframework..."

xcodebuild -create-xcframework \
    "${XCODE_ARGS[@]}" \
    -output "${XCFRAMEWORK_PATH}"

print_success "XCFramework created at: ${XCFRAMEWORK_PATH}"

# =============================================================================
# Copy ONNX Runtime (for macOS)
# =============================================================================

if [ "$INCLUDE_MACOS" = true ]; then
    ONNX_MACOS_DIR="${ROOT_DIR}/third_party/onnxruntime-macos"
    if [ -d "${ONNX_MACOS_DIR}/lib" ]; then
        print_step "Copying ONNX Runtime dylib for macOS..."
        ONNX_DIST_DIR="${DIST_DIR}/onnxruntime-macos"
        mkdir -p "${ONNX_DIST_DIR}"
        cp "${ONNX_MACOS_DIR}/lib/libonnxruntime"* "${ONNX_DIST_DIR}/"
        print_success "ONNX Runtime dylib copied to ${ONNX_DIST_DIR}"
    fi
fi

# =============================================================================
# Verification
# =============================================================================

print_header "Verification"

print_step "XCFramework structure:"
ls -la "${XCFRAMEWORK_PATH}/"

echo ""
print_step "Checking Info.plist..."
plutil -p "${XCFRAMEWORK_PATH}/Info.plist" | grep -E "LibraryIdentifier|SupportedPlatform|SupportedArchitectures" || true

# Check architectures in each slice
echo ""
print_step "Architecture verification:"

if [ "$INCLUDE_IOS" = true ]; then
    echo "iOS Device (arm64):"
    lipo -info "${XCFRAMEWORK_PATH}/ios-arm64/libRunAnywhereCore.a" 2>/dev/null || echo "  Not found"

    echo "iOS Simulator (arm64 + x86_64):"
    lipo -info "${XCFRAMEWORK_PATH}/ios-arm64_x86_64-simulator/libRunAnywhereCore.a" 2>/dev/null || \
    lipo -info "${XCFRAMEWORK_PATH}/ios-arm64-simulator/libRunAnywhereCore.a" 2>/dev/null || echo "  Not found"
fi

if [ "$INCLUDE_MACOS" = true ]; then
    echo "macOS Universal (arm64 + x86_64):"
    lipo -info "${XCFRAMEWORK_PATH}/macos-arm64_x86_64/libRunAnywhereCore.a" 2>/dev/null || \
    lipo -info "${XCFRAMEWORK_PATH}/macos-arm64/libRunAnywhereCore.a" 2>/dev/null || echo "  Not found"
fi

# =============================================================================
# Summary
# =============================================================================

print_header "Build Complete!"

echo "XCFramework: ${XCFRAMEWORK_PATH}"
echo ""

echo "Total size: $(du -sh "${XCFRAMEWORK_PATH}" | cut -f1)"
echo ""

echo "Slices included:"
for dir in "${XCFRAMEWORK_PATH}"/*/; do
    if [ -d "$dir" ] && [ "$(basename "$dir")" != "." ]; then
        slice_name=$(basename "$dir")
        if [ -f "${dir}libRunAnywhereCore.a" ]; then
            slice_size=$(du -sh "${dir}libRunAnywhereCore.a" | cut -f1)
            echo "  - ${slice_name}: ${slice_size}"
        fi
    fi
done
echo ""

if [ "$INCLUDE_MACOS" = true ]; then
    echo "IMPORTANT for macOS apps:"
    echo "  The ONNX Runtime dylib must be embedded in your app bundle."
    echo "  Copy from: ${DIST_DIR}/onnxruntime-macos/libonnxruntime*.dylib"
    echo "  To: YourApp.app/Contents/Frameworks/"
    echo ""
fi

echo "Required frameworks to link:"
echo "  - Foundation.framework"
echo "  - CoreML.framework"
echo "  - Accelerate.framework"
echo "  - Metal.framework (for LlamaCPP GPU acceleration)"
echo "  - MetalKit.framework (for LlamaCPP GPU acceleration)"
echo ""

echo -e "${GREEN}Done!${NC}"
